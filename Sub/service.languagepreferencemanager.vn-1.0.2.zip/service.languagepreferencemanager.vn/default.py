import os, sys, re
import xbmc, xbmcgui, xbmcaddon, xbmcvfs

import json as simplejson

__addon__ = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__ = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__addonPath__ = __addon__.getAddonInfo('path')
__addonResourcePath__ = xbmcvfs.translatePath(os.path.join(__addonPath__, 'resources', 'lib'))
__addonIconFile__ = xbmcvfs.translatePath(os.path.join(__addonPath__, 'icon.png'))
sys.path.append(__addonResourcePath__)

from langcodes import *
from prefsettings import settings

settings = settings()

LOG_NONE = 0
LOG_ERROR = 1
LOG_INFO = 2
LOG_DEBUG = 3
    
def log(level, msg):
    xbmc.log("[Language Preference Manager]: " + str(msg), xbmc.LOGINFO)

LANGUAGE_MAP = {
    # English
    "eng": "Tiếng Anh", "en": "Tiếng Anh", "english": "Tiếng Anh",
    # Japanese
    "jpn": "Tiếng Nhật", "ja": "Tiếng Nhật", "japanese": "Tiếng Nhật",
    # Chinese (Mandarin/Cantonese)
    "chi": "Tiếng Trung", "zho": "Tiếng Trung", "zh": "Tiếng Trung", "chinese": "Tiếng Trung",
    "yue": "Tiếng Quảng Đông", "cantonese": "Tiếng Quảng Đông",
    # Korean
    "kor": "Tiếng Hàn", "ko": "Tiếng Hàn", "korean": "Tiếng Hàn",
    # Vietnamese
    "vie": "Tiếng Việt", "vi": "Tiếng Việt", "vietnamese": "Tiếng Việt", "vtn": "Tiếng Việt",
    # French
    "fre": "Tiếng Pháp", "fra": "Tiếng Pháp", "fr": "Tiếng Pháp", "french": "Tiếng Pháp",
    # German
    "ger": "Tiếng Đức", "deu": "Tiếng Đức", "de": "Tiếng Đức", "german": "Tiếng Đức",
    # Russian
    "rus": "Tiếng Nga", "ru": "Tiếng Nga", "russian": "Tiếng Nga",
    # Spanish
    "spa": "Tiếng Tây Ban Nha", "es": "Tiếng Tây Ban Nha", "spanish": "Tiếng Tây Ban Nha",
    # Italian
    "ita": "Tiếng Ý", "it": "Tiếng Ý", "italian": "Tiếng Ý",
    # Thai
    "tha": "Tiếng Thái", "th": "Tiếng Thái", "thai": "Tiếng Thái",
    # Hindi / India
    "hin": "Tiếng Ấn Độ", "hi": "Tiếng Ấn Độ", "hindi": "Tiếng Ấn Độ",
    # Portuguese
    "por": "Tiếng Bồ Đào Nha", "pt": "Tiếng Bồ Đào Nha", "portuguese": "Tiếng Bồ Đào Nha",
}

def get_friendly_language_name(lang_code, stream_name=""):
    lang_code = (lang_code or "").lower().strip()
    stream_name = (stream_name or "").lower().strip()
    
    if lang_code in LANGUAGE_MAP:
        return LANGUAGE_MAP[lang_code]
        
    viet_keywords = ["viet", "vie", "vtn", "tiếng việt", "tieng viet", "lồng tiếng", "thuyết minh", "long tieng", "thuyet minh"]
    eng_keywords = ["eng", "en", "english", "tiếng anh", "tieng anh"]
    jpn_keywords = ["jpn", "ja", "japanese", "tiếng nhật", "tieng nhat", "japan"]
    chi_keywords = ["chi", "zho", "zh", "chinese", "tiếng trung", "tieng trung", "china", "cantonese", "yue", "quảng đông"]
    kor_keywords = ["kor", "ko", "korean", "tiếng hàn", "tieng han", "korea"]
    fre_keywords = ["fre", "fra", "fr", "french", "tiếng pháp", "tieng phap", "france"]
    ger_keywords = ["ger", "deu", "de", "german", "tiếng đức", "tieng duc", "germany"]
    rus_keywords = ["rus", "ru", "russian", "tiếng nga", "tieng nga", "russia"]
    spa_keywords = ["spa", "es", "spanish", "tiếng tây ban nha", "tieng tay ban nha", "spain"]
    ita_keywords = ["ita", "it", "italian", "tiếng ý", "tieng y", "italy"]
    tha_keywords = ["tha", "th", "thai", "tiếng thái", "tieng thai", "thailand"]
    
    for kw in viet_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Việt"
    for kw in eng_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Anh"
    for kw in jpn_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Nhật"
    for kw in chi_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Trung"
    for kw in kor_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Hàn"
    for kw in fre_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Pháp"
    for kw in ger_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Đức"
    for kw in rus_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Nga"
    for kw in spa_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Tây Ban Nha"
    for kw in ita_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Ý"
    for kw in tha_keywords:
        if kw in lang_code or kw in stream_name:
            return "Tiếng Thái"
            
    if lang_code and lang_code != "und":
        return lang_code.upper()
    if stream_name:
        return stream_name.title()
    return "Không rõ"


class LangPref_Monitor( xbmc.Monitor ):
  def __init__( self ):
      xbmc.Monitor.__init__( self )
        
  def onSettingsChanged( self ):
      settings.init()
      settings.readSettings()

class Main:
    def __init__( self ):
        self._init_vars()
        if (not settings.service_enabled):
            log(LOG_INFO, "Service not enabled")

        settings.readSettings()
        self._daemon()

    def _init_vars( self ):
        self.Monitor = LangPref_Monitor()
        self.Player = LangPrefMan_Player()

    def _daemon( self ):
        while (not self.Monitor.abortRequested()):
            self.Monitor.waitForAbort(1)
            

class LangPrefMan_Player(xbmc.Player) :
    
    def __init__ (self):
        self.LPM_initial_run_done = False
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self):
        log(LOG_DEBUG, 'New AV Playback initiated - Resetting LPM Initial Flag')
        self.LPM_initial_run_done = False
    
    def onAVStarted(self):
        if self.isPlayingVideo():
            log(LOG_DEBUG, 'Playback started')
            self.audio_changed = False
            # switching an audio track to early leads to a reopen -> start at the beginning
            if settings.delay > 0:
                log(LOG_DEBUG, "Delaying preferences evaluation by {0} ms".format(settings.delay))
                xbmc.sleep(settings.delay)
            
            playing_file = self.getPlayingFile().lower()
            if playing_file.startswith('http') or playing_file.startswith('plugin'):
                log(LOG_DEBUG, "Streaming file detected. Adding an extra 1500 ms delay for player to stabilize.")
                xbmc.sleep(1500)

            log(LOG_DEBUG, 'Getting video properties')
            self.getDetails()
            self.evalPrefs()
            self.LPM_initial_run_done = True

    def onAVChange(self):
        if self.LPM_initial_run_done and self.isPlayingVideo():
            log(LOG_DEBUG, 'AVChange detected - Checking possible change of audio track...')
            self.audio_changed = False
            if settings.delay > 0:
                log(LOG_DEBUG, "Delaying preferences evaluation by {0} ms".format(settings.delay))
                xbmc.sleep(settings.delay)
            previous_audio_index = self.selected_audio_stream['index']
            previous_audio_language = self.selected_audio_stream['language']
            log(LOG_DEBUG, 'Getting video properties')
            self.getDetails()
            if (self.selected_audio_stream['index'] != previous_audio_index):
                log(LOG_INFO, 'Audio track changed from {0} to {1}. Reviewing Conditional Subtitles rules...'.format(previous_audio_language, self.selected_audio_stream['language']))
                self.evalPrefs()
    
    def evalPrefs(self):
        # recognized filename audio or filename subtitle
        fa = False
        fs = False
        
        # Track selected streams dynamically
        chosen_audio_idx = self.selected_audio_stream.get('index') if (self.selected_audio_stream and isinstance(self.selected_audio_stream, dict)) else 0
        chosen_sub_idx = self.selected_sub.get('index') if (self.selected_sub and isinstance(self.selected_sub, dict)) else -1
        sub_enabled = self.selected_sub_enabled
        
        has_vi_audio = False
        non_vi_track = -1
        
        # Always force original audio (non-Vietnamese) if multiple tracks exist and one is Vietnamese
        # Skip if this is a TVB movie/drama (traditionally uses classic Vietnamese lồng tiếng)
        # Check if we should bypass forcing original audio (keep Vietnamese/dubbed audio)
        bypass_keywords = [
            'tvb', 'atv', 'uslt', 'ffvn', 'lồng tiếng', 'long tieng', 'longtieng', 'lồngtiếng',
            'thuyết minh', 'thuyet minh', 'thuyetminh', 'thuyếtminh', 'sanyang', 
            'chau tinh tri', 'châu tinh trì', 'stephen chow', 'phim bo', 'phimbo', 'phim bộ'
        ]
        playing_file = self.getPlayingFile().lower()
        bypass_force_original = any(kw in playing_file for kw in bypass_keywords) or bool(re.search(r'\b(lt|tm)\b', playing_file))
        
        if not bypass_force_original:
            for stream in self.audiostreams:
                stream_lang = stream.get('language', '').lower()
                stream_name = stream.get('name', '').lower()
                if any(kw in stream_name for kw in bypass_keywords) or bool(re.search(r'\b(lt|tm)\b', stream_name)):
                    bypass_force_original = True
                    break
                if stream_lang in ['chi', 'zho', 'yue'] or any(kw in stream_name for kw in ['cantonese', 'mandarin', 'chinese', 'tiếng trung', 'quảng đông', 'tiếng hoa']):
                    bypass_force_original = True
                    break
                    
        # Let's find the Vietnamese audio track index (including 'und' if we bypassed original audio forcing)
        vi_audio_track = -1
        for stream in self.audiostreams:
            stream_lang = stream.get('language', '').lower()
            stream_name = stream.get('name', '').lower()
            if stream_lang in ['vie', 'vi', 'vtn'] or any(kw in stream_name for kw in ['thuyết minh', 'lồng tiếng', 'thuyet minh', 'long tieng', 'uslt', 'ffvn', 'viet']):
                vi_audio_track = stream.get('index')
                break
        
        if vi_audio_track == -1 and bypass_force_original:
            # 1. Try to find any track whose name contains 'mp3' or 'stereo' and is NOT Chinese
            for stream in self.audiostreams:
                stream_lang = stream.get('language', '').lower()
                stream_name = stream.get('name', '').lower()
                is_chinese = stream_lang in ['chi', 'zho', 'yue'] or any(kw in stream_name for kw in ['cantonese', 'mandarin', 'chinese', 'tiếng trung', 'quảng đông', 'tiếng hoa'])
                if not is_chinese and any(kw in stream_name for kw in ['mp3', 'stereo']):
                    vi_audio_track = stream.get('index')
                    break
            
            # 2. Fall back to any 'und' or empty language track that is NOT Chinese
            if vi_audio_track == -1:
                for stream in self.audiostreams:
                    stream_lang = stream.get('language', '').lower()
                    stream_name = stream.get('name', '').lower()
                    is_chinese = stream_lang in ['chi', 'zho', 'yue'] or any(kw in stream_name for kw in ['cantonese', 'mandarin', 'chinese', 'tiếng trung', 'quảng đông', 'tiếng hoa'])
                    if not is_chinese and stream_lang in ['und', '']:
                        vi_audio_track = stream.get('index')
                        break

            # 3. Fall back to any track with index > 0 that is not Chinese
            if vi_audio_track == -1:
                for stream in self.audiostreams:
                    stream_lang = stream.get('language', '').lower()
                    stream_name = stream.get('name', '').lower()
                    is_chinese = stream_lang in ['chi', 'zho', 'yue'] or any(kw in stream_name for kw in ['cantonese', 'mandarin', 'chinese', 'tiếng trung', 'quảng đông', 'tiếng hoa'])
                    if not is_chinese and stream.get('index', 0) > 0:
                        vi_audio_track = stream.get('index')
                        break

        if bypass_force_original and vi_audio_track >= 0:
            log(LOG_INFO, 'Bypassed original audio forcing. Forcing Vietnamese/undetermined dubbed track {0}'.format(vi_audio_track))
            self.setAudioStream(vi_audio_track)
            chosen_audio_idx = vi_audio_track
            fa = True
        elif len(self.audiostreams) > 1 and not bypass_force_original:
            for stream in self.audiostreams:
                stream_lang = stream.get('language', '').lower()
                stream_name = stream.get('name', '').lower()
                if stream_lang in ['vie', 'vi', 'vtn'] or 'thuyết minh' in stream_name or 'lồng tiếng' in stream_name or 'thuyet minh' in stream_name or 'long tieng' in stream_name:
                    has_vi_audio = True
                    break
            
            if has_vi_audio:
                for stream in self.audiostreams:
                    stream_lang = stream.get('language', '').lower()
                    stream_name = stream.get('name', '').lower()
                    is_vi = stream_lang in ['vie', 'vi', 'vtn'] or 'thuyết minh' in stream_name or 'lồng tiếng' in stream_name or 'thuyet minh' in stream_name or 'long tieng' in stream_name
                    if not is_vi and stream_lang != 'und':
                        non_vi_track = stream.get('index')
                        break
                if non_vi_track == -1:
                    for stream in self.audiostreams:
                        stream_lang = stream.get('language', '').lower()
                        stream_name = stream.get('name', '').lower()
                        is_vi = stream_lang in ['vie', 'vi', 'vtn'] or 'thuyết minh' in stream_name or 'lồng tiếng' in stream_name or 'thuyet minh' in stream_name or 'long tieng' in stream_name
                        if not is_vi:
                            non_vi_track = stream.get('index')
                            break
                if non_vi_track >= 0:
                    log(LOG_INFO, 'Forcing original audio track {0} ({1})'.format(non_vi_track, self.audiostreams[non_vi_track].get('name')))
                    self.setAudioStream(non_vi_track)
                    chosen_audio_idx = non_vi_track
                    fa = True
                    
        # Always force Vietnamese subtitle if available
        vi_track = -1
        for sub in self.subtitles:
            sub_lang = sub.get('language', '').lower()
            sub_name = sub.get('name', '').lower()
            is_vi = sub_lang in ['vie', 'vi', 'vietnamese', 'vtn'] or 'viet' in sub_lang or 'viet' in sub_name or 'tiếng việt' in sub_name or 'tieng viet' in sub_name
            if is_vi and ('forced' in sub_name or 'force' in sub_name or 'default' in sub_name):
                vi_track = sub.get('index')
                break
        if vi_track == -1:
            for sub in self.subtitles:
                sub_lang = sub.get('language', '').lower()
                sub_name = sub.get('name', '').lower()
                is_vi = sub_lang in ['vie', 'vi', 'vietnamese', 'vtn'] or 'viet' in sub_lang or 'viet' in sub_name or 'tiếng việt' in sub_name or 'tieng viet' in sub_name
                if is_vi:
                    vi_track = sub.get('index')
                    break
                    
        en_track = -1
        if vi_track >= 0:
            log(LOG_INFO, 'Forcing Vietnamese subtitle track {0} ({1})'.format(vi_track, self.subtitles[vi_track].get('name')))
            self.setSubtitleStream(vi_track)
            chosen_sub_idx = vi_track
            self.showSubtitles(True)
            sub_enabled = True
            fs = True
        else:
            # No Vietnamese subtitle, look for English
            for sub in self.subtitles:
                sub_lang = sub.get('language', '').lower()
                sub_name = sub.get('name', '').lower()
                is_en = sub_lang in ['eng', 'en', 'english'] or 'eng' in sub_lang or 'english' in sub_name
                if is_en and ('forced' in sub_name or 'force' in sub_name or 'default' in sub_name):
                    en_track = sub.get('index')
                    break
            if en_track == -1:
                for sub in self.subtitles:
                    sub_lang = sub.get('language', '').lower()
                    sub_name = sub.get('name', '').lower()
                    is_en = sub_lang in ['eng', 'en', 'english'] or 'eng' in sub_lang or 'english' in sub_name
                    if is_en:
                        en_track = sub.get('index')
                        break
            
            if en_track >= 0:
                log(LOG_INFO, 'No Vietnamese subtitle found. Forcing English track {0} ({1})'.format(en_track, self.subtitles[en_track].get('name')))
                self.setSubtitleStream(en_track)
                chosen_sub_idx = en_track
                self.showSubtitles(True)
                sub_enabled = True
                fs = True
            else:
                log(LOG_INFO, 'No Vietnamese or English subtitles found.')
                
        if settings.useFilename and not self.LPM_initial_run_done:
            audio, sub = self.evalFilenamePrefs()
            if (audio >= 0) and audio < len(self.audiostreams):
                log(LOG_INFO, 'Filename preference: Match, selecting audio track {0}'.format(audio))
                self.setAudioStream(audio)
                chosen_audio_idx = audio
                self.audio_changed = True
                fa = True
                
            if (sub >= 0) and sub < len(self.subtitles):
                self.setSubtitleStream(sub)
                chosen_sub_idx = sub
                fs = True
                log(LOG_INFO, 'Filename preference: Match, selecting subtitle track {0}'.format(sub))
                if settings.turn_subs_on:
                    log(LOG_DEBUG, 'Subtitle: enabling subs' )
                    self.showSubtitles(True)
                    sub_enabled = True
            else:
                log(LOG_INFO, 'Filename preference: No match found for subtitle track ({0})'.format(self.getPlayingFile()))
                if settings.turn_subs_off:
                    log(LOG_INFO, 'Subtitle: disabling subs' )
                    self.showSubtitles(False)
                    sub_enabled = False
                    
        if settings.audio_prefs_on and not fa and not self.LPM_initial_run_done:
            if settings.custom_audio_prefs_on:
                trackIndex = self.evalAudioPrefs(settings.custom_audio)
            else:
                trackIndex = self.evalAudioPrefs(settings.AudioPrefs)
                
            if trackIndex == -2:
                log(LOG_INFO, 'Audio: None of the preferred languages is available' )
            elif trackIndex >= 0:
                self.setAudioStream(trackIndex)
                chosen_audio_idx = trackIndex
                self.audio_changed = True
            
        if settings.sub_prefs_on and not fs and not self.LPM_initial_run_done:
            if settings.custom_sub_prefs_on:
                trackIndex = self.evalSubPrefs(settings.custom_subs)
            else:
                trackIndex = self.evalSubPrefs(settings.SubtitlePrefs)
                
            if trackIndex == -2:
                log(LOG_INFO, 'Subtitle: None of the preferred languages is available' )
                if settings.turn_subs_off:
                    log(LOG_INFO, 'Subtitle: disabling subs' )
                    self.showSubtitles(False)
                    sub_enabled = False
            if trackIndex == -1:
                log(LOG_INFO, 'Subtitle: Preferred subtitle is selected but might not be enabled' )
                if settings.turn_subs_on and not self.selected_sub_enabled:
                    log(LOG_INFO, 'Subtitle: enabling subs because selected sub is not enabled' )
                    self.showSubtitles(True)
                    sub_enabled = True
            elif trackIndex >= 0:
                self.setSubtitleStream(trackIndex)
                chosen_sub_idx = trackIndex
                if settings.turn_subs_on:
                    log(LOG_INFO, 'Subtitle: enabling subs' )
                    self.showSubtitles(True)
                    sub_enabled = True
                
        if settings.condsub_prefs_on and not fs:
            if settings.custom_condsub_prefs_on:
                trackIndex = self.evalCondSubPrefs(settings.custom_condsub)
            else:
                trackIndex = self.evalCondSubPrefs(settings.CondSubtitlePrefs)
 
            if trackIndex == -1:
                log(LOG_INFO, 'Conditional subtitle: disabling subs' )
                self.showSubtitles(False)
                sub_enabled = False
            if trackIndex == -2:
                log(LOG_INFO, 'Conditional subtitle: No matching preferences found for current audio stream. Doing nothing.')
            elif trackIndex >= 0:
                self.setSubtitleStream(trackIndex)
                chosen_sub_idx = trackIndex
                if settings.turn_subs_on:
                    log(LOG_DEBUG, 'Subtitle: enabling subs' )
                    self.showSubtitles(True)
                    sub_enabled = True

        # --- Professional Notification Formatting (Only on initial run) ---
        if not self.LPM_initial_run_done:
            # 1. Determine final audio language
            audio_lang_display = "Không rõ"
            if chosen_audio_idx >= 0 and chosen_audio_idx < len(self.audiostreams):
                stream = self.audiostreams[chosen_audio_idx]
                audio_lang_display = get_friendly_language_name(stream.get('language'), stream.get('name'))
                if bypass_force_original and chosen_audio_idx == vi_audio_track:
                    audio_lang_display = "Tiếng Việt (Lồng tiếng)"
            
            # 2. Determine final subtitle language
            sub_lang_display = "Tắt / Không có"
            if sub_enabled and chosen_sub_idx >= 0 and chosen_sub_idx < len(self.subtitles):
                stream = self.subtitles[chosen_sub_idx]
                sub_lang_display = get_friendly_language_name(stream.get('language'), stream.get('name'))
            
            # 3. Trigger professional centered popup notification (Auto-close after 2.5s)
            header_text = "[COLOR gold][B]TỰ ĐỘNG CHỌN NGÔN NGỮ[/B][/COLOR]"
            msg_text = "[COLOR lightgrey]Âm thanh gốc:[/COLOR] [COLOR white][B]{0}[/B][/COLOR]\n[COLOR lightgrey]Phụ đề:[/COLOR] [COLOR white][B]{1}[/B][/COLOR]".format(audio_lang_display, sub_lang_display)
            
            import threading
            def auto_close_popup():
                xbmc.sleep(2500)  # Sleep for 2.5 seconds (2500 ms)
                # Send click to the OK button (Control ID 1) of the OK Dialog (Window ID 10100)
                xbmc.executebuiltin('SendClick(okdialog, 1)')
                # Force close okdialog just in case
                xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                
            threading.Thread(target=auto_close_popup).start()
            xbmcgui.Dialog().ok(header_text, msg_text)

    def evalFilenamePrefs(self):
        log(LOG_DEBUG, 'Evaluating filename preferences' )
        audio = -1
        sub = -1
        filename = self.getPlayingFile()
        matches = settings.reg.findall(filename)
        fileprefs = []
        for m in matches:
            sp = settings.split.split(m)
            fileprefs.append(sp)

        for pref in fileprefs:
            if len(pref) == 2:
                if (pref[0].lower() == 'audiostream'):
                    audio = int(pref[1])
                    log(LOG_INFO, 'audio track extracted from filename: {0}'.format(audio))
                elif(pref[0].lower() == 'subtitle'):
                    sub = int(pref[1])
                    log(LOG_INFO, 'subtitle track extracted from filename: {0}'.format(sub))
        log(LOG_DEBUG, 'filename: audio: {0}, sub: {1} ({2})'.format(audio, sub, filename))
        return audio, sub
    
    def evalAudioPrefs(self, audio_prefs):
        log(LOG_DEBUG, 'Evaluating audio preferences' )
        i = 0
        for pref in audio_prefs:
            i += 1
            g_t, preferences = pref
            # genre or tags are given (g_t not empty) but none of them matches the video's tags/genres
            if g_t and (not (self.genres_and_tags & g_t)):
                continue

            log(LOG_INFO,'Audio: genre/tag preference {0} met with intersection {1}'.format(g_t, (self.genres_and_tags & g_t)))
            for pref in preferences:
                name, codes = pref
                codes = codes.split(r',')
                for code in codes:
                    if (code is None):
                        log(LOG_DEBUG,'continue')
                        continue                
                    if (self.selected_audio_stream and
                        'language' in self.selected_audio_stream and
                        (code == self.selected_audio_stream['language'] or name == self.selected_audio_stream['language'])):
                            log(LOG_INFO, 'Selected audio language matches preference {0} ({1})'.format(i, name) )
                            return -1
                    else:
                        for stream in self.audiostreams:
                            if ((code == stream['language']) or (name == stream['language'])):
                                log(LOG_INFO, 'Audio language of stream {0} matches preference {1} ({2})'.format(stream['index'], i, name) )
                                return stream['index']
                        log(LOG_INFO, 'Audio: preference {0} ({1}:{2}) not available'.format(i, name, code) )
                i += 1
        return -2
                
    def evalSubPrefs(self, sub_prefs):
        log(LOG_DEBUG, 'Evaluating subtitle preferences' )
        i = 0
        for pref in sub_prefs:
            i += 1
            g_t, preferences = pref
            # genre or tags are given (g_t not empty) but none of them matches the video's tags/genres
            if g_t and (not (self.genres_and_tags & g_t)):
                continue

            log(LOG_INFO,'Subtitle: genre/tag preference {0} met with intersection {1}'.format(g_t, (self.genres_and_tags & g_t)))
            for pref in preferences:
                name, codes, forced = pref
                codes = codes.split(r',')
                for code in codes:
                    if (code is None):
                        log(LOG_DEBUG,'continue')
                        continue 
                    if (self.selected_sub and
                        'language' in self.selected_sub and
                        ((code == self.selected_sub['language'] or name == self.selected_sub['language']) and self.testForcedFlag(forced, self.selected_sub['name']))):
                            log(LOG_INFO, 'Selected subtitle language matches preference {0} ({1})'.format(i, name) )
                            return -1
                    else:
                        for sub in self.subtitles:
                            if (settings.ignore_signs_on and self.isSignsSub(sub['name'])):
                                log(LOG_INFO,'SubPrefs : ignore_signs toggle is on and one such subtitle track is found. Skipping it.')
                                continue
                            if ((code == sub['language'] or name == sub['language']) and self.testForcedFlag(forced, sub['name'])):
                                log(LOG_INFO, 'Subtitle language of subtitle {0} matches preference {1} ({2})'.format(sub['index'], i, name) )
                                return sub['index']
                        log(LOG_INFO, 'Subtitle: preference {0} ({1}:{2}) not available'.format(i, name, code) )
                i += 1
        return -2

    def evalCondSubPrefs(self, condsub_prefs):
        log(LOG_DEBUG, 'Evaluating conditional subtitle preferences' )
        # if the audio track has been changed wait some time
        if (self.audio_changed and settings.delay > 0):
            log(LOG_DEBUG, "Delaying preferences evaluation by {0} ms".format(4*settings.delay))
            xbmc.sleep(4*settings.delay)
        log(LOG_DEBUG, 'Getting video properties')
        self.getDetails()
        i = 0
        for pref in condsub_prefs:
            i += 1
            g_t, preferences = pref
            # genre or tags are given (g_t not empty) but none of them matches the video's tags/genres
            if g_t and (not (self.genres_and_tags & g_t)):
                continue

            log(LOG_INFO,'Cond Sub: genre/tag preference {0} met with intersection {1}'.format(g_t, (self.genres_and_tags & g_t)))
            for pref in preferences:
                audio_name, audio_code, sub_name, sub_code, forced = pref
                if (audio_code is None):
                    log(LOG_DEBUG,'continue')
                    continue 

                if (self.selected_audio_stream and
                    'language' in self.selected_audio_stream and
                    (audio_code == self.selected_audio_stream['language'] or audio_name == self.selected_audio_stream['language'] or audio_code == "any")):
                        log(LOG_INFO, 'Selected audio language matches conditional preference {0} ({1}:{2}), force tag is {3}'.format(i, audio_name, sub_name, forced) )
                        if (sub_code == "non"):
                            if (forced == 'true'):
                                log(LOG_INFO, 'Subtitle condition is None but forced is true, searching a forced subtitle matching selected audio...')
                                for sub in self.subtitles:
                                    log(LOG_DEBUG, 'Looping subtitles...')
                                    if ((audio_code == sub['language']) or (audio_name == sub['language'])):
                                        log(LOG_DEBUG, 'One potential match found...')
                                        if (self.testForcedFlag(forced, sub['name'])):
                                            log(LOG_DEBUG, 'One forced match found...')
                                            log(LOG_INFO, 'Language of subtitle {0} matches audio preference {1} ({2}:{3}) with forced overriding rule {4}'.format(sub['index'], i, audio_name, sub_name, forced) )
                                            return sub['index']
                                log(LOG_INFO, 'Conditional subtitle: no match found for preference {0} ({1}:{2}) with forced overriding rule {3}'.format(i, audio_name, sub_name, forced) )
                            return -1
                        else:
                            for sub in self.subtitles:
                                if (settings.ignore_signs_on and self.isSignsSub(sub['name'])):
                                    log(LOG_INFO,'CondSubs : ignore_signs toggle is on and one such subtitle track is found. Skipping it.')
                                    continue
                                if ((sub_code == sub['language']) or (sub_name == sub['language'])):
                                    if (self.testForcedFlag(forced, sub['name'])):
                                        log(LOG_INFO, 'Language of subtitle {0} matches conditional preference {1} ({2}:{3}) forced {4}'.format(sub['index'], i, audio_name, sub_name, forced) )
                                        return sub['index']
                            log(LOG_INFO, 'Conditional subtitle: no match found for preference {0} ({1}:{2})'.format(i, audio_name, sub_name) )
                i += 1
        return -2

    def isSignsSub(self, subName):
        test = subName.lower()
        matches = ['signs']
        return any(x in test for x in matches)
    
    def testForcedFlag(self, forced, subName):
        test = subName.lower()
        matches = ['forced', 'forcés']
        found = any(x in test for x in matches)
        return ((forced == 'false') and not found) or ((forced == 'true') and found)

    def isExternalSub(self, subName):
        test = subName.lower()
        matches = ['ext']
        return any(x in test for x in matches)
    
    def getDetails(self):
        activePlayers ='{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
        json_query = xbmc.executeJSONRPC(activePlayers)
        #json_query = unicode(json_query, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_query)
        activePlayerID = json_response['result'][0]['playerid']
        details_query_dict = {  "jsonrpc": "2.0",
                                "method": "Player.GetProperties",
                                "params": { "properties": 
                                            ["currentaudiostream", "audiostreams", "subtitleenabled",
                                             "currentsubtitle", "subtitles" ],
                                            "playerid": activePlayerID },
                                "id": 1}
        details_query_string = simplejson.dumps(details_query_dict)
        json_query = xbmc.executeJSONRPC(details_query_string)
        #json_query = unicode(json_query, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_query)
        
        if 'result' in json_response and json_response['result'] != None:
            self.selected_audio_stream = json_response['result']['currentaudiostream']
            self.selected_sub = json_response['result']['currentsubtitle']
            self.selected_sub_enabled = json_response['result']['subtitleenabled']
            self.audiostreams = json_response['result']['audiostreams']
            self.subtitles = json_response['result']['subtitles']
        log(LOG_DEBUG, json_response )
        
        if (not settings.custom_condsub_prefs_on and not settings.custom_audio_prefs_on and not settings.custom_sub_prefs_on):
            log(LOG_DEBUG, 'No custom prefs used at all, skipping extra Video tags/genres JSON query.')
            self.genres_and_tags = set()
            return        
        
        genre_tags_query_dict = {"jsonrpc": "2.0",
                                 "method": "Player.GetItem",
                                 "params": { "properties":
                                            ["genre", "tag"],
                                            "playerid": activePlayerID },
                                 "id": 1}
        genre_tags_query_string = simplejson.dumps(genre_tags_query_dict)
        json_query = xbmc.executeJSONRPC(genre_tags_query_string)
        #json_query = unicode(json_query, 'utf-8', errors='ignore')
        json_response = simplejson.loads(json_query)
        if 'result' in json_response and json_response['result'] != None:
            gt = []
            if 'genre' in json_response['result']['item']:
                gt = json_response['result']['item']['genre']
            if 'tag' in json_response['result']['item']:
                gt.extend(json_response['result']['item']['tag'])
            self.genres_and_tags = set(map(lambda x:x.lower(), gt))
        log(LOG_DEBUG, 'Video tags/genres: {0}'.format(self.genres_and_tags))
        log(LOG_DEBUG, json_response )

if ( __name__ == "__main__" ):
    log(LOG_INFO, 'service {0} version {1} started'.format(__addonname__, __addonversion__))
    main = Main()
    log(LOG_INFO, 'service {0} version {1} stopped'.format(__addonname__, __addonversion__))
