#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import xbmcaddon
import xbmcvfs

def setup_dns_bypass():
    import socket
    import urllib.request
    import json
    import ssl
    import threading
    import xbmcaddon

    if hasattr(socket, '_orig_getaddrinfo'):
        return
        
    socket._orig_getaddrinfo = socket.getaddrinfo
    
    try:
        addon = xbmcaddon.Addon()
        cine_host = addon.getSetting('thuviencine_domain')
        hd_host = addon.getSetting('thuvienhd_domain')
    except Exception:
        cine_host = ''
        hd_host = ''

    if not cine_host or not cine_host.strip():
        cine_host = 'thuviencine.live'
    else:
        cine_host = cine_host.strip().replace('https://', '').replace('http://', '').split('/')[0]

    if not hd_host or not hd_host.strip():
        hd_host = 'thuvienhd.top'
    else:
        hd_host = hd_host.strip().replace('https://', '').replace('http://', '').split('/')[0]

    dns_cache = {
        cine_host: ['104.21.25.250', '172.67.134.243'],
        'thuviencine.live': ['104.21.25.250', '172.67.134.243'],
        'thuviencine.com': ['104.21.25.250', '172.67.134.243'],
        hd_host: ['104.21.74.114', '172.67.168.22'],
        'thuvienhd.top': ['104.21.74.114', '172.67.168.22']
    }
    
    queried_hosts = set()
    dns_lock = threading.Lock()
    
    def resolve_doh_lazy(host):
        with dns_lock:
            if host in queried_hosts:
                return
            queried_hosts.add(host)
            
        ctx = ssl._create_unverified_context()
        try:
            req = urllib.request.Request(
                f'https://cloudflare-dns.com/dns-query?name={host}&type=A',
                headers={'Accept': 'application/dns-json'}
            )
            with urllib.request.urlopen(req, context=ctx, timeout=2) as r:
                res = json.loads(r.read().decode('utf-8'))
                if res.get('Status') == 0 and res.get('Answer'):
                    ips = []
                    for ans in res['Answer']:
                        if ans.get('type') == 1:
                            ips.append(ans['data'])
                    if ips:
                        with dns_lock:
                            dns_cache[host] = ips
        except Exception:
            pass
            
    def custom_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        if host in dns_cache:
            resolve_doh_lazy(host)
            with dns_lock:
                ips = dns_cache[host]
            results = []
            for ip in ips:
                try:
                    res = socket._orig_getaddrinfo(ip, port, family, type, proto, flags)
                    results.extend(res)
                except Exception:
                    pass
            if results:
                return results
        return socket._orig_getaddrinfo(host, port, family, type, proto, flags)
        
    socket.getaddrinfo = custom_getaddrinfo

try:
    setup_dns_bypass()
except Exception:
    pass

addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
lib_path = os.path.join(addon_path, 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import urlquick
import getlink, loadlistitem
import xbmcplugin
from six.moves import urllib_parse
from config import CLOUDSHARE_HOST
from resources.addon import *
from resources import fshare, cloudshare_update, search, download, iptv, speedfs, resetfs, cache_utils, gsheet, advanced_settings_menu, quick_account, skin_installer, source_installer
from resources.utils import *

try:
    _addon_init = xbmcaddon.Addon()
    _cine_h = _addon_init.getSetting('thuviencine_domain')
    _hd_h = _addon_init.getSetting('thuvienhd_domain')
except Exception:
    _cine_h = ''
    _hd_h = ''

if not _cine_h or not _cine_h.strip():
    CINE_HOST = 'thuviencine.live'
else:
    CINE_HOST = _cine_h.strip().replace('https://', '').replace('http://', '').split('/')[0]

if not _hd_h or not _hd_h.strip():
    HD_HOST = 'thuvienhd.top'
else:
    HD_HOST = _hd_h.strip().replace('https://', '').replace('http://', '').split('/')[0]

CINE_DOMAIN = f"https://{CINE_HOST}"
HD_DOMAIN = f"https://{HD_HOST}"

from resources.fshare import mobileScan
from resources.history_utils import search_history, fshare_history, watched_history
from resources.cache_manager import check_and_clear_cache
HANDLE = int(sys.argv[1])

# Tự động xóa cache khi nâng cấp phiên bản để tránh xung đột dữ liệu cũ
try:
    saved_version = ADDON.getSetting("version")
    if saved_version != VERSION:
        cache_utils.clear_all_addon_cache()
        ADDON.setSetting("version", VERSION)
except Exception as e:
    xbmc.log(f"[CloudShare] Lỗi khi tự động xóa cache nâng cấp: {e}", xbmc.LOGERROR)

# Định nghĩa biến disclaimer với chuỗi Unicode
disclaimer = """Addon CLOUDSHARE cung cấp nội dung từ nhiều nguồn khác nhau trên Internet.
Tuy nhiên, tác giả không chịu trách nhiệm về tính hợp pháp hoặc bản quyền của nội dung được cung cấp bởi addon này.
Người dùng phải tự chịu trách nhiệm khi sử dụng nội dung từ addon và đảm bảo rằng việc sử dụng nội dung đó tuân thủ các quy định bản quyền và luật pháp áp dụng."""

def check_history():
    return search_history.check_history()

def get_search_history():
    return search_history.get_history()

def save_search_history(query):
    search_history.save_history(query)

def delete_search_history():
    search_history.delete_history()


def check_fshare_history():
    return fshare_history.check_history()

def get_fshare_history():
    return fshare_history.get_history()

def save_fshare_history(query):
    fshare_history.save_history(query)

def delete_fshare_history():
    fshare_history.delete_history()

def check_hdvn_history():
    return False

def get_hdvn_history():
    return []

def save_hdvn_history(query):
    pass

def delete_hdvn_history():
    pass


def check_tvcine_history():
    return False

def get_tvcine_history():
    return []

def save_tvcine_history(query):
    pass

def delete_tvcine_history():
    pass


def check_watched_history():
    return watched_history.check_history()

def get_watched_history():
    return watched_history.get_history()

def save_watched_history(name, link, size):
    entry = f"{name},{link},{size}"
    watched_history.save_history(entry)

def delete_watched_history():
    watched_history.delete_history()


disclaimer_ = "[COLOR yellow]Addon CloudShare[/COLOR]: là addon cho chương trình KODI, mã nguồn mở, dùng để thu thập các link của các tệp được chia sẻ trên Internet. Addon CloudShare không tổ chức sản xuất, lưu trữ bất kỳ nội dung nào mà addon hiển thị trong chương trình của nó. Để dùng được người sử dụng cần có tài khoản vip của Fshare.\n[COLOR yellow]Fshare[/COLOR]: là các dịch vụ cung cấp khả năng lưu trữ dữ liệu trực tuyến và có thể chia sẻ dữ liệu cho người khác.\n\n[B]Các nguồn nội dung addon sử dụng:[/B]\n[COLOR yellow]Cộng đồng chia sẻ[/COLOR]: là các nội dung do những người sử dụng dịch vụ cung cấp bởi Fshare chia sẻ trực tuyến cho mọi người.\n[COLOR yellow]thuviencine.com[/COLOR], [COLOR yellow]thuvienhd.xyz[/COLOR], [COLOR yellow]hdvietnam.xyz[/COLOR]...\nTrong quá trình sử dụng, các vấn đề liên quan đến các file chia sẻ, xin vui lòng liên hệ người chia sẻ hoặc các chủ sở hữu website trên."


ADDON.setSettingBool('disclaimer_agreed', True)

ADDON.setSettingBool('v11_36_update_seen', True)

def urlencode(url):
    return urllib.parse.quote_plus(url)

def fetch_data_default(url, headers=None):
    if '?action=menu' in url:
        data = getMenu()
        OnOffHistoryWatching = ADDON.getSettingBool("OnOffHistoryWatching")
        if not OnOffHistoryWatching:
            for item in data['items']:
                if 'Lịch sử xem phim' in item['label']:
                    data['items'].remove(item)
                    break
        return data
    elif 'FshareMenu' in url:
        return getFshareMenu()
    elif 'FshareHost' in url:
        return FshareHost()
    elif 'getTienich' in url:
        return getTienich()
    elif 'getAccFshare' in url:
        return getAccFshare()
    else:

        return fetch_data(url, headers)

def getTinyCC(url):
    import requests
    from requests.structures import CaseInsensitiveDict
    shorten_host = ADDON.getSetting('shorten_host')
    headers = CaseInsensitiveDict()
    headers["authority"] = shorten_host
    headers["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36"
    if "gg.gg" in url:
        url = url.replace("https","http")
    resp = requests.get(url, headers=headers)
    return(resp.status_code,resp.url)
def fshare_top_follow():
    return fshare.fshare_top_follow()

def fshare_favourite(url):
    return fshare.fshare_favourite(url)
def add_remove_favourite(url,status):
    fshare.add_remove_favourite(url,status)
def process_url_input(url_input):
    import requests
    url_input = url_input.replace("&", "[]")
    url_input = url_input.replace("+", "[]")
    links = url_input.split('[]')
    if len(links) == 2:
        url_input = links[0]
        subs = links[1]
    else:
        subs = ''

    if 'fshare' in url_input:
        if 'token' in url_input:
            match = re.search(r"(\?.+?\d+)", url_input)
            _token = match.group(1)
            url_input = url_input.replace(_token, '')
        name, file_type, file_size = fshare.get_fshare_file_info(url_input)

        thumbnail = 'fshare.png'
        if 'folder' in url_input:
            regex = r"folder\/(.+)"
        else:
            regex = r"file\/(.+)"
        match = re.search(regex, url_input)
        f_id = match.group(1)

        if "folder" in url_input:
            file = 'plugin://plugin.video.cloudshare?action=play&url=https://www.fshare.vn/folder/' + f_id
            playable = False
            if len(name) == 0:
                name = 'Folder to play'
        else:
            file = 'plugin://plugin.video.cloudshare?action=play&url=https://www.fshare.vn/file/' + f_id + '[]' + subs
            playable = True
            if len(name) == 0:
                name = 'File to play'

    elif 'drive.google.com' in url_input:
        file = 'plugin://plugin.video.cloudshare?action=play&url=' + url_input
        playable = True

    elif "docs.google.com" in url_input:
        r = requests.get(url_input)
        regex = r"title\" content=\"(.*?)\""
        d = re.search(regex, r.text)
        if d:
            name = d.group(1)
            if "|" in name:
                t = name.split("|")
                name = t[0]
                thumbnail = t[1]
            else:
                thumbnail = "https://i.imgur.com/ib5f09u.png"
        else:
            name = "Chia sẻ Google Sheet"
        file = 'plugin://plugin.video.cloudshare?action=play&url=' + url_input
        playable = False
        file_size = ''


    else:
        try:

            if "tinyurl.com/app/nospam" in url_input:
                alert("URL đã bị xóa hoặc không tồn tại")

                data = getMenu()
                loadlistitem.list_item_main(data)
                return data
            import requests
            try:
                r = requests.head(url_input, timeout=5, verify=False)
                if r.status_code != 200:
                    alert(f"URL không hợp lệ hoặc không tồn tại (Mã lỗi: {r.status_code})")

                    data = getMenu()
                    loadlistitem.list_item_main(data)
                    return data
            except requests.exceptions.RequestException as e:
                alert(f"Lỗi kết nối: {str(e)}")

                data = getMenu()
                loadlistitem.list_item_main(data)
                return data


            data = list_link(url_input)
            loadlistitem.list_item(data)
        except Exception as e:
            alert(f"Lỗi khi xử lý URL: {str(e)}")

            data = getMenu()
            loadlistitem.list_item_main(data)

    items = []
    item = {}
    item["label"] = '[COLOR yellow]' + name + '[/COLOR]'
    item["is_playable"] = playable
    item["path"] = file
    item["thumbnail"] = play_icon
    item["icon"] = play_icon
    item["label2"] = ""
    item["info"] = {'plot': '', 'size': file_size}
    items = [item]

    if 'fshare.vn' in url_input:
        SaveNumberHistory(name, url_input, thumbnail)
    else:
        SaveNumberHistory(name, file, thumbnail)

    data = {"content_type": "episodes", "items": ""}
    data.update({"items": items})
    return data

def PlayCode():
    """Hàm xử lý nhập code từ các dịch vụ rút gọn link"""

    history_file = os.path.join(PROFILE_PATH, 'history.dat')
    history = []

    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as file:
                history = [line.strip() for line in file.readlines() if line.strip()]
        except Exception as e:
            logError(f"Error reading history file: {e}")

    shorten_host = ADDON.getSetting('shorten_host')
    if not shorten_host:
        alert("Vui lòng thiết lập dịch vụ làm ngắn link trong Addon Setting")
        ADDON.openSettings()
        return {"content_type": "episodes", "items": []}

    if not history:
        return input_code_and_process(shorten_host)

    options = ["[Nhập code mới]", "[Xoá lịch sử nhập code]"] + [line.split(',')[0] for line in history if ',' in line]
    dialog = xbmcgui.Dialog()
    selected = dialog.select("Chọn code hoặc nhập code mới", options)

    if selected == -1:
        notify("Thao tác bị hủy")

        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "episodes", "items": []}
    elif selected == 0:
        return input_code_and_process(shorten_host)
    elif selected == 1:
        confirm = dialog.yesno("Xác nhận", "Bạn có chắc chắn muốn xoá lịch sử nhập code không?")
        if confirm:
            if os.path.exists(history_file):
                open(history_file, 'w').close()
                notify("Đã xoá lịch sử nhập code")

                xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "episodes", "items": []}
    else:
        selected_history = history[selected - 2]
        parts = selected_history.split(',')
        if len(parts) >= 2:
            link = parts[1].strip()
            if link.startswith('plugin://plugin.video.cloudshare?action=play&url='):
                real_url = link.replace('plugin://plugin.video.cloudshare?action=play&url=', '')
                return process_url_input(real_url)
            else:
                return process_url_input(link)
        else:
            notify("Lịch sử không hợp lệ")
            return {"content_type": "episodes", "items": []}

def input_code_and_process(shorten_host):
    """Hàm nhập code và xử lý"""
    keyboardHandle = xbmc.Keyboard('', 'Dịch vụ rút gọn link [COLOR yellow]' + shorten_host + '[/COLOR] đang được sử dụng')
    keyboardHandle.doModal()

    if not keyboardHandle.isConfirmed() or not keyboardHandle.getText().strip():
        notify("Không có dữ liệu được nhập")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "episodes", "items": []}

    code = keyboardHandle.getText().strip()
    shortern_site = 'https://' + shorten_host + '/'
    shortern_link = shortern_site + code
    status_code, url_final = getTinyCC(shortern_link)

    if status_code != 200:
        alert("Xin vui lòng kiểm tra lại link hoặc thiết lập đúng dịch vụ rút gọn link trong Addon Setting")
        ADDON.openSettings()
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "episodes", "items": []}

    if "tinyurl.com/app/nospam" in url_final:
        alert("URL đã bị xóa hoặc không tồn tại")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "episodes", "items": []}

    return process_url_input(url_final)
def SaveNumberHistory(name, link, thumb):
    """Lưu lịch sử nhập code với xử lý trùng lặp tốt hơn"""

    if link.startswith('plugin://plugin.video.cloudshare?action=play&url='):
        link = link.replace('plugin://plugin.video.cloudshare?action=play&url=', '')


    entry = name + ',' + link

    if thumb and thumb.strip():
        entry += ',' + thumb

    filename = os.path.join(PROFILE_PATH, 'history.dat')
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(entry)
        return
    try:
        with open(filename, "r", encoding="utf-8") as file:
            lines = file.readlines()


        lines = [line.strip() for line in lines if line.strip()]
        base_link = link.split('[]')[0] if '[]' in link else link
        updated_lines = []
        for line in lines:
            parts = line.split(',')
            if len(parts) >= 2:
                line_link = parts[1].strip()
                line_base_link = line_link.split('[]')[0] if '[]' in line_link else line_link
                if line_base_link == base_link:
                    continue

            updated_lines.append(line)
        updated_lines.insert(0, entry)


        with open(filename, "w", encoding="utf-8") as f:
            f.write('\n'.join(updated_lines))

    except Exception as e:
        logError(f"Error in SaveNumberHistory: {e}")

def search_content(search_type, query=None):

    try:
        if search_type == 'fshare':

            if query:
                data = search.searchcloudshare(query)
                save_search_history(query)
                loadlistitem.list_item_main(data)
            else:
                FshareSearchQuery()
                return

        elif search_type == 'tvhd':

            if query:
                search.searchtvhd(query)
            else:
                keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    query = keyboard.getText()
                    search.searchtvhd(query)
                else:
                    notify("Đã hủy tìm kiếm")
                    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                return
        else:
            notify("Loại tìm kiếm không hợp lệ")
            return
    except Exception as e:
        notify(f"Lỗi khi tìm kiếm: {str(e)}")
        return None

def timkiemMenu():
    search_icon = ADDON_PATH + "/resources/images/search.png"
    top_icon = ADDON_PATH + "/resources/images/top.png"

    menu_items = [
        {
            "label": "[COLOR yellow]Tìm kiếm[/COLOR]",
            "path": "plugin://plugin.video.cloudshare?action=_timtrenfshare_",
            "icon": search_icon,
            "plot": "Tìm kiếm nội dung trên Fshare"
        },
        {
            "label": "[COLOR yellow]timfshare.com[/COLOR]",
            "path": "plugin://plugin.video.cloudshare?action=browse&url=__TIMFSHARE__",
            "icon": search_icon,
            "plot": "Tìm kiếm nội dung trên timfshare.com"
        },
        {
            "label": "Top 100 link tìm kiếm",
            "path": "plugin://plugin.video.cloudshare?action=_topsearch100_",
            "icon": top_icon,
            "plot": "Xem danh sách 100 link Fshare được xem nhiều nhất"

        },
        {
            "label": "Addon Timfshare",
            "path": "plugin://plugin.video.timfshare/",
            "icon": search_icon,
            "plot": "Mở addon Timfshare"
        }
    ]


    for item in menu_items:
        list_item = xbmcgui.ListItem(label=item["label"])
        list_item.setArt({"icon": item["icon"], "thumb": item["icon"]})
        info_tag = list_item.getVideoInfoTag()
        info_tag.setPlot(item["plot"])
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=item["path"],
            listitem=list_item,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)

def watchedHistoryList():
    if not check_watched_history():
        notify("Chưa có lịch sử xem phim")
        return {"content_type": "episodes", "items": []}

    items = []
    try:
        history = get_watched_history()

        for entry in history:
            parts = entry.strip().split(",")
            if len(parts) < 2:
                continue

            if len(parts) >= 3:
                name, link, size = map(str.strip, parts[:3])

            else:
                name, link = map(str.strip, parts[:2])
                size = "0"


            if "File không tồn tại" in name:
                continue

            link = 'plugin://plugin.video.cloudshare?action=play&url=%s' % link
            playable = True


            item = {
                "label": name,
                "is_playable": playable,
                "path": link,
                "thumbnail": "",
                "icon": xbmcvfs.translatePath(os.path.join(ADDON_PATH, 'resources', 'images', 'fsvideo.png')),
                "label2": "",
                "info": {'plot': 'Giữ nút OK 2s trên điều khiển để xoá lịch sử xem', 'size': size}

            }

            items.append(item)
    except Exception as e:

        logError(f"Error in watchedHistoryList: {e}")

    return {"content_type": "files", "items": items}
def watchingHistory(link):
    """Lưu lịch sử xem phim"""
    if "fshare.vn" in link:
        try:

            name, file_type, size_file = fshare.get_fshare_file_info(link)


            save_watched_history(name, link, size_file)
        except Exception as e:
            logError(f"Error in watchingHistory: {e}")
            alert(f"Error in watchingHistory: {e}")

def list_link(url_input):
    """
    Phân tích nội dung từ URL và trả về danh sách các mục
    """
    import requests
    from six.moves import urllib_parse

    try:
        useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
        headers = {'User-Agent': useragent}
        r = requests.get(url_input, headers=headers, verify=False, timeout=10)


        if r.status_code != 200:
            alert(f"URL không hợp lệ hoặc không tồn tại (Mã lỗi: {r.status_code})")
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
            return {"content_type": "movies", "items": []}

        r = r.text
        r = r.replace('\n', '').replace('\r', '')
        lines = r.split('*')


        if len(lines) <= 1:
            alert("URL không chứa nội dung hợp lệ")
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
            return {"content_type": "movies", "items": []}

        t = len(lines)
        items = []
        name = ''

        for i in range(1, t):
            item = {}
            line = (lines[i])
            line = line.split("|")


            if len(line) < 1:
                continue

            name = line[0]
            try: href = line[1]
            except: href = ''
            sub = ''
            try: sub = line[2]
            except: sub = ''
            href = href+'[]'+sub
            thumb = ''
            if len(line) > 3: thumb = line[3]
            info = ''
            if len(line) > 4: info = line[4].strip()


            name = urllib_parse.unquote_plus(name)

            if '@' in name or 'folder' in href or "pastebin.com" in href or '"docs.google.com"' in href:
                playable = False
                link = 'plugin://plugin.video.cloudshare?action=play&url=%s' % href
            else:
                playable = True
                link = 'plugin://plugin.video.cloudshare?action=play&url=%s' % href


            item["label"] = name
            item["is_playable"] = playable
            item["path"] = link
            item["thumbnail"] = thumb
            item["icon"] = "https://i.imgur.com/8wyaJKv.png"
            item["label2"] = ""
            item["info"] = {'plot': info}
            items.append(item)


        if not items:
            alert("Không tìm thấy nội dung hợp lệ trong URL")
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
            return {"content_type": "movies", "items": []}

        data = {"content_type": "movies", "items": ""}
        data.update({"items": items})
        return data

    except requests.exceptions.RequestException as e:

        alert(f"Lỗi kết nối: {str(e)}")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "movies", "items": []}
    except Exception as e:

        alert(f"Lỗi khi xử lý URL: {str(e)}")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.cloudshare, replace)")
        return {"content_type": "movies", "items": []}


def updateAcc():
    fshare.updateAcc()

def fsharegetFolder(url):
    return fshare.fsharegetFolder(url)
def FshareSearchQuery():


    history = get_search_history()


    if not history:
        keyboard = xbmc.Keyboard("", "Nhập từ khóa để tìm kiếm")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
        else:
            notify("Đã hủy tìm kiếm")
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            return
    else:
        options = ["[Nhập từ khóa mới]", "[Xóa lịch sử tìm kiếm]"] + history
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Chọn từ khóa tìm kiếm", options)

        if selected == -1:
            notify("Đã hủy tìm kiếm")
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            return
        elif selected == 0:
            keyboard = xbmc.Keyboard("", "Nhập từ khóa để tìm kiếm")
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                query = keyboard.getText()
            else:
                notify("Đã hủy tìm kiếm")
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                return
        elif selected == 1:
            confirm = dialog.yesno("Xác nhận", "Bạn có chắc chắn muốn xóa lịch sử tìm kiếm không?")
            if confirm:
                delete_search_history()
                xbmc.executebuiltin("Container.Refresh")
            return
        else:
            query = options[selected]


    save_search_history(query)


    try:
        data = search.searchcloudshare(query)
        loadlistitem.list_item_search_history(data)
    except Exception as e:
        notify(f"Lỗi khi tìm kiếm: {str(e)}")


def searchHistory():

    if not check_history():
        FshareSearchQuery()
    else:
        items = []
        items1 = [{
            'label': '[COLOR yellow]Tìm kiếm Fshare[/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.cloudshare?action=_timtrenfshare1_',
            'thumbnail': 'https://i.imgur.com/F5582QW.png',
            'icon': 'https://i.imgur.com/F5582QW.png',
            'label2': '',
            'info': {
                'plot': 'Tìm kiếm nên gõ tiếng Anh để được kết quả chính xác nhất'},
            }]
        items2 = [{
            'label': '[COLOR yellow][I]Xoá lịch sử tìm kiếm[/I][/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.cloudshare?action=__removeAllSearchHistory__',
            'thumbnail': 'https://i.imgur.com/oS0Humg.png',
            'icon': 'https://i.imgur.com/oS0Humg.png',
            'label2': '',
            'info': {
                'plot': 'Xoá toàn bộ lịch sử tìm kiếm'}
            }]


        history = get_search_history()
        t = len(history)

        if t > 60:
            notify("Có vẻ danh sách tìm kiếm quá nhiều. Xoá đê")

        for name in history:
            item={}
            keyword = urllib_parse.quote_plus(name)
            playable = False
            item["label"] = "[I]"+name+"[/I]"
            item["is_playable"] = playable
            item["path"] = 'plugin://plugin.video.cloudshare?action=_timtrenfshare1_&keyword=%s' % keyword
            item["thumbnail"] = "https://i.imgur.com/lwX6Kup.png"
            item["icon"] = "https://i.imgur.com/lwX6Kup.png"
            item["label2"] = ""
            item["info"] = {'plot': 'Kết quả tìm kiếm [COLOR yellow]'+name+'[/COLOR]'}
            items += [item]

        items=items1+items2+items
        data = {"content_type": "", "items": ""}
        data.update({"items": items})

        return data
def search4sHistory():

    if not check_fshare_history():
        FourshareSearchQuery(page=1)
    else:
        items = []
        items1 = [{
            'label': '[COLOR yellow]Tìm kiếm 4share[/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.cloudshare?action=_timtren4share1_',
            'thumbnail': 'https://i.imgur.com/F5582QW.png',
            'icon': 'https://i.imgur.com/F5582QW.png',
            'label2': '',
            'info': {
                'plot': 'Tìm kiếm nên gõ tiếng Anh để được kết quả chính xác nhất'},
            }]
        items2 = [{
            'label': '[COLOR yellow][I]Xoá lịch sử tìm kiếm[/I][/COLOR]',
            'is_playable': False,
            'path': 'plugin://plugin.video.cloudshare?action=__removeAllSearchHistory4share__',
            'thumbnail': 'https://i.imgur.com/WE9wi4n.png',
            'icon': 'https://i.imgur.com/WE9wi4n.png',
            'label2': '',
            'info': {
                'plot': 'Xoá toàn bộ lịch sử tìm kiếm'}
            }]


        history = get_fshare_history()
        t = len(history)

        if t > 60:
            notify("Có vẻ danh sách tìm kiếm quá nhiều. Xoá đê")

        for name in history:
            item={}
            keyword = urllib_parse.quote_plus(name)
            playable = False
            item["label"] = "[I]"+name+"[/I]"
            item["is_playable"] = playable
            item["path"] = 'plugin://plugin.video.cloudshare?action=_timtren4share1_&keyword=%s' % keyword
            item["thumbnail"] = "https://i.imgur.com/lwX6Kup.png"
            item["icon"] = "https://i.imgur.com/lwX6Kup.png"
            item["label2"] = ""
            item["info"] = {'plot': 'Kết quả tìm kiếm [COLOR yellow]'+name+'[/COLOR]'}
            items += [item]

        items=items1+items2+items
        data = {"content_type": "", "items": ""}
        data.update({"items": items})

        return data

def FourshareSearchQuery(page):

    history = get_fshare_history()

    if not history:
        keyboard = xbmc.Keyboard("", "Nhập từ khóa tìm kiếm")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
        else:
            notify("Đã hủy tìm kiếm")
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            return
    else:
        options = ["[Nhập từ khóa mới]", "[Xóa lịch sử tìm kiếm]"] + history
        dialog = xbmcgui.Dialog()
        selected = dialog.select("Chọn từ khóa tìm kiếm", options)

        if selected == -1:
            notify("Đã hủy tìm kiếm")
            xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            return
        elif selected == 0:
            keyboard = xbmc.Keyboard("", "Nhập từ khóa tìm kiếm")
            keyboard.doModal()
            if keyboard.isConfirmed() and keyboard.getText():
                query = keyboard.getText()
            else:
                notify("Đã hủy tìm kiếm")
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                return
        elif selected == 1:
            confirm = dialog.yesno("Xác nhận", "Bạn có chắc chắn muốn xóa lịch sử tìm kiếm không?")
            if confirm:
                delete_fshare_history()
                notify("Đã xóa lịch sử tìm kiếm")
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
            return
        else:
            query = options[selected]

    save_fshare_history(query)

    try:
        data = search.searchFourshare(query, page)
        loadlistitem.list_item_search_history(data)
    except Exception as e:
        notify(f"Lỗi khi tìm kiếm: {str(e)}")


def backup():
    import zipfile
    username_backup,password_backup = fshare.getBackupAcc()

    USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')
    favourite_file = xbmcvfs.translatePath(USERDATA+"/favourites.xml")
    sources_file=xbmcvfs.translatePath(USERDATA+"/sources.xml")

    backup_file = os.path.join(USERDATA, "backup.zip")
    progress = xbmcgui.DialogProgress()
    progress.create('Backup', 'Starting backup...')

    backup_zip = zipfile.ZipFile(backup_file, 'w', zipfile.ZIP_DEFLATED)
    try:

        for root, dirs, files in os.walk(USERDATA):
            for file in files:
                if file.endswith('.xml'):
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, USERDATA)
                    backup_zip.write(file_path, arcname=arcname)

        for root, dirs, files in os.walk(PROFILE_PATH):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, USERDATA)
                backup_zip.write(file_path, arcname=arcname)

        backup_zip.close()

    except Exception as e:
        alert(f'Error while creating backup zip: {e}')


    filesize = os.path.getsize(backup_file)
    filename = os.path.basename(backup_file)
    backup_service = ADDON.getSetting('service.backup')

    if "fshare" in backup_service:
        payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"'+username_backup+'","password":"'+password_backup+'"}'
        headers = {'cache-control': "no-cache", 'User-Agent': 'kodicloudshare-K58W6U'}
        response = requests.post('https://api.fshare.vn/api/user/login', data=payload, headers=headers)
        if response.status_code == 200:
            progress.update(10, 'Uploading backup file to Fshare...')
            jStr = json.loads(response.content)
            token = jStr['token']
            session_id = jStr['session_id']
            headers = {'accept': 'application/json','User-Agent': 'kodicloudshare-K58W6U','Cookie': 'session_id='+session_id,'Content-Type': 'application/json; charset=UTF-8'}
            json_data = {'name': filename,'size': str(filesize),'path': '/','token': token,'secured': 1}
            cookies = {'session_id':session_id}

            r = requests.get('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60', headers=headers, verify=False)
            jdata = json.loads(r.content)

            for i in jdata:
                if i["name"] == "backup.zip":

                    linkcode = i["linkcode"]
                    delete_api = "https://api.fshare.vn/api/fileops/delete"
                    payload = {"token": token,"items": [linkcode]}
                    cookies = {'session_id': session_id}
                    headers = {
                      'Content-Type': 'application/json; charset=UTF-8',
                      'User-Agent': 'kodicloudshare-K58W6U',
                      'Fshare-Session-ID': session_id
                    }
                    r = requests.post(delete_api, cookies=cookies, headers=headers, json=payload)
                    '''
                    if r.status_code == 200:
                        notify("Đã xoá file cũ")
                    '''
                    break
            progress.update(80, 'Uploading backup file to Fshare...')
            response = requests.post('https://api.fshare.vn/api/session/upload', cookies=cookies, headers=headers, json=json_data)
            r = json.loads(response.content)
            upload_link = r["location"]

            with open(backup_file, 'rb') as f:
                binary_data = f.read()
            r = requests.post(upload_link, data=binary_data, headers=headers)
            if r.status_code == 200:
                os.remove(backup_file)
                headers = {'Cookie': 'session_id=' + session_id}
                r = urlquick.get("https://api.fshare.vn//api/user/logout", headers=headers)
                if response.status_code == 200:
                    progress.update(100, 'Lưu trữ thành công...')

        elif response.status_code == 424:
            alert("Bạn đăng nhập sai quá 3 lần. Vui lòng đăng nhập lại")
        elif response.status_code == 409:
            alert("Account đã bị khoá login")
        else:
            alert("Kiểm tra lại tài khoản của bạn")

    progress.close()
def restore():
    import zipfile
    username_backup,password_backup = fshare.getBackupAcc()

    USERDATA = os.path.join(xbmcvfs.translatePath('special://home/'), 'userdata')

    if len(username_backup) > 0 and len(username_backup) > 0:
        progress = xbmcgui.DialogProgress()
        progress.create('Restore', 'Starting restore...')
        payload = '{"app_key":"L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn","user_email":"'+username_backup+'","password":"'+password_backup+'"}'
        headers = {'cache-control': "no-cache", 'User-Agent': 'kodicloudshare-K58W6U'}
        response = requests.post('https://api.fshare.vn/api/user/login', data=payload, headers=headers)
        if response.status_code == 200:
            progress.update(0, 'Đang login tài khoản...')
            jStr = json.loads(response.content)
            token = jStr['token']
            session_id = jStr['session_id']
            headers = {'accept': 'application/json','User-Agent': 'kodicloudshare-K58W6U','Cookie': 'session_id='+session_id,'Content-Type': 'application/json; charset=UTF-8'}
            cookies = {'session_id':session_id}

            r = requests.get('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60', headers=headers, verify=False)
            jdata = json.loads(r.content)

            progress.update(1, 'Đang tìm kiếm file backup...')
            for i in jdata:

                if i["name"] == "backup.zip":
                    progress.update(20, 'Đã tìm thấy file backup...')
                    linkcode = i["linkcode"]

                    get_link = 'https://api2.fshare.vn/api/session/download'
                    link_backup = "https://www.fshare.vn/file/"+linkcode

                    data   = '{"token" : "%s", "url" : "%s", "password" : ""}'
                    data   = data % (token, link_backup)
                    header = {'Cookie' : 'session_id=' + session_id}
                    result = requests.post(get_link, headers=header, data=data)
                    jStr = json.loads(result.content)
                    backup_url = jStr['location']
                    backup_file_path = xbmcvfs.translatePath(USERDATA+"/backup.zip")
                    progress.update(40, 'Tải file backup...')
                    urllib.request.urlretrieve(backup_url, backup_file_path)
                    progress.update(60, 'Extract đữ liệu...')
                    with zipfile.ZipFile(backup_file_path, 'r') as backup_zip:
                        for item in backup_zip.infolist():
                            try:
                                if item.filename.endswith('.xml') or 'addon_data' in item.filename:
                                    backup_zip.extract(item, path=USERDATA)
                            except PermissionError:
                                if item.filename == 'guisettings.xml':
                                    continue
                                else:
                                    raise
                    progress.update(90, 'Xoá file tải về...')
                    os.remove(backup_file_path)

                    backup_file_temp = xbmcvfs.translatePath(PROFILE_PATH+"/backup.zip")
                    if os.path.exists(backup_file_temp):os.remove(backup_file_temp)

                    r = urlquick.get("https://api.fshare.vn//api/user/logout", headers=headers)
                    if response.status_code == 200:
                        progress.update(100, 'Phục hồi thành công...')
                        progress.close()
                        cloudshare_update.exit_kodi()
    else:
        alert("Bạn chưa nhập tài khoản để lưu trữ dữ liệu")

def downloadfile(url):
    download.downloadfile(url)
def showDownload():
    try:
        download_path = xbmcvfs.translatePath(ADDON.getSetting("download_path"))
        if not download_path:
            dialog = xbmcgui.Dialog()
            choice = dialog.yesno('Thiết lập đường dẫn', 'Đường dẫn lưu trữ chưa được thiết lập. Bạn có muốn thiết lập ngay bây giờ?')
            if choice:
                download_path = dialog.browse(3, 'Chọn đường dẫn lưu trữ', 'files')
                if not download_path:
                    return
                ADDON.setSetting("download_path", download_path)
            else:
                return

        items = os.listdir(download_path)
        for item in items:
            item_path = os.path.join(download_path, item)
            if os.path.isfile(item_path):
                # Hiển thị tất cả các file, không giới hạn định dạng
                file_size = os.path.getsize(item_path)
                list_item = xbmcgui.ListItem(label=item, path=item_path)
                list_item.setProperty("size", str(file_size))
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_path, listitem=list_item)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except Exception as e:
        xbmc.log("Lỗi: " + str(e), level=xbmc.LOGERROR)

def delete_settings_file():
    addon_id = xbmcaddon.Addon().getAddonInfo('id')
    user_data_path = xbmcvfs.translatePath('special://userdata')
    addon_data_path = os.path.join(user_data_path, 'addon_data', addon_id)
    settings_file_path = os.path.join(addon_data_path, 'settings.xml')

    if os.path.exists(settings_file_path):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Xoá Thông Tin Setting', 'Bạn có muốn xoá thông tin liên quan đến tài khoản cài đặt addon không?')
        if ret:
            try:
                os.remove(settings_file_path)
                return True
            except Exception as e:
                alert("Lỗi xoá file setting:", str(e))
                return False
        else:
            alert("Bạn đã huỷ xoá file")
            return False
    else:
        alert("File setting.xml không tồn tại")
        return False

def play(data):
    link = data["url"]

    if link is None or len(link) == 0:
        notify('Không lấy được link')
        return

    if 'text' in link or 'Text' in link:
        content = str(link).replace("text", "")
        TextBoxes(ADDON_NAME, content)
        return

    if 'vtvgo' in link:
        link = getlink.get(link)
        item = xbmcgui.ListItem(path=link)
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return


    from_history = False
    if "fshare.vn" in link and check_watched_history():

        history = get_watched_history()

        for entry in history:
            parts = entry.strip().split(",")
            if len(parts) >= 2 and link in parts[1]:
                from_history = True
                break

    try:
        if "fshare.vn" in link:
            OnOffHistoryWatching = xbmcaddon.Addon().getSettingBool("OnOffHistoryWatching")
            if OnOffHistoryWatching and not from_history:
                watchingHistory(link)


            if from_history:
                for entry in history:
                    parts = entry.strip().split(",")
                    if len(parts) >= 2 and link in parts[1]:
                        name = parts[0]
                        size = parts[2] if len(parts) > 2 else 0
                        break

            else:
                name, file_type, size = fshare.get_fshare_file_info(link)

                # Không kiểm tra loại file để cho phép phát tất cả các định dạng mà Kodi hỗ trợ
                # Bao gồm cả file .ts và .flac



        link = getlink.get(link)
        if not link:
            # Nếu Fshare chết, kích hoạt phao cứu sinh Ophim
            from resources import smart_resolver
            xbmc.log(f"[CloudShare] Fshare link dead. Trying Ophim fallback for: {name}", xbmc.LOGINFO)
            ophim_link = smart_resolver.find_ophim_fallback(name)
            if ophim_link:
                xbmcgui.Dialog().notification("Smart Resolver", "Đang phát qua máy chủ dự phòng Ophim", xbmcgui.NOTIFICATION_INFO)
                link = ophim_link
                
                # Cập nhật thông tin cho player
                item = xbmcgui.ListItem(path=link)
                item.setMimeType('application/vnd.apple.mpegurl')
                xbmcplugin.setResolvedUrl(HANDLE, True, item)
                return
            else:
                alert("Không lấy được link và máy chủ dự phòng cũng không có phim này. Thử lại sau.")
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return

        subtitle = ''
        links = link.split('[]')

        if len(links) == 2:
            subtitle = links[1]
        elif data.get('subtitle'):
            subtitle = data.get('subtitle')

        if "qc" in subtitle:
            subtitle = ''

        link = links[0]

        def check_and_get_subtitle(name):
            subtitle_file_path = xbmcvfs.translatePath('special://userdata/phude.cloudshare')
            if not xbmcvfs.exists(subtitle_file_path):
                subtitle_file_path = xbmcvfs.translatePath('special://userdata/phude.vmf')

            with xbmcvfs.File(subtitle_file_path, 'r') as file:
                content = file.read()
                lines = content.splitlines()

                for line in lines:
                    parts = line.split('|')

                    if len(parts) >= 2:
                        subtitle_name = parts[0].strip()
                        subtitle_name = os.path.splitext(subtitle_name)[0]
                        subtitle_link = parts[1].strip()

                        if subtitle_name == name:
                            return True, subtitle_link
                            break

            return False, None

        def download_and_set_subtitle(subtitle_url):
            useragent = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0")
            headers = {'User-Agent': useragent}
            xbmc_temp = xbmcvfs.translatePath('special://temp')
            tempdir = os.path.join(xbmc_temp, 'phudeCloudShare')
            tmp_file = os.path.join(tempdir, "phude.srt")

            r = requests.get(subtitle_url, headers=headers)
            writesub(r.text)

            xbmc.sleep(500)
            filename = os.path.join(PROFILE_PATH, 'phude.srt')
            xbmc.Player().setSubtitles(filename)

        def resolve_and_notify(link, subtitle_url=None):
            try:

                use_external_player = ADDON.getSetting("external_player_enabled") == "true"

                if use_external_player:



                    dummy_item = xbmcgui.ListItem(path="special://home/addons/plugin.video.cloudshare/resources/dummy.mp4")

                    xbmcplugin.setResolvedUrl(HANDLE, True, dummy_item)


                    success = advanced_settings_menu.launch_external_player(link, name)
                    exit()
                    if not success:
                        notify("Lỗi khi mở external player")
                        return
                    return


                item = xbmcgui.ListItem(path=link)
                if "fshare.vn" in link:
                    item.setMimeType('video/mp4')
                    item.setContentLookup(False)
                    info = {
                        'title': name,
                        'size': size,
                        'mediatype': 'video'
                    }
                    item.setInfo('video', info)

                xbmcplugin.setResolvedUrl(HANDLE, True, item)

                if subtitle_url:
                    download_and_set_subtitle(subtitle_url)
                elif "fshare.vn" in link:
                    found_subtitle, subtitle_link = check_and_get_subtitle(name)
                    if found_subtitle:
                        token, session_id = fshare.check_session()
                        subtitle_link = fshare.get_download_link(token, session_id, subtitle_link)
                        download_and_set_subtitle(subtitle_link)
                        notify("Đã tải phụ đề thành công.")
            except Exception as e:
                alert(f"Lỗi khi play video: {str(e)}")
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return

        if "fshare.vn" in link:
            resolve_and_notify(link, subtitle if len(subtitle) > 0 else None)

    except Exception as e:
        alert(f"Lỗi khi xử lý video: {str(e)}")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
def phim_list(url):
        response = requests.get(url)
        data = response.text

        start_index = data.index('{')
        end_index = data.rindex('}') + 1
        json_data = data[start_index:end_index]
        data = json.loads(json_data)
        items = []
        for row in data["table"]["rows"]:
            label = row["c"][0]["v"]
            url_value = row["c"][1]["v"]
            if isinstance(url_value, str):
                url_value = url_value.replace('plugin.video.vietmediaF', ADDON_ID).replace('plugin.video.vietmediaf', ADDON_ID)
            items.append((label, url_value))
        return items
def install_repo(url):
    """
    Cài đặt addon từ repository

    Args:
        url (str): URL của repository hoặc addon cần cài đặt
    """
    try:

        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create("Đang cài đặt addon", "Đang cài đặt addon từ repository...")
        progress_dialog.update(50)


        xbmc.executebuiltin(f'InstallAddon({url})')


        xbmc.sleep(2000)

        progress_dialog.update(100, "Hoàn tất cài đặt addon!")
        progress_dialog.close()


        notify("Đã cài đặt addon thành công")

        return True

    except Exception as e:
        xbmc.log(f"[CloudShare] Lỗi khi cài đặt addon: {str(e)}", xbmc.LOGERROR)
        alert(f"Lỗi khi cài đặt addon: {str(e)}")
        return False

def select_source(setting_key):
    sources = {
        'phimle_url': ('https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=0&headers=1', 'Chọn một nguồn phim lẻ'),
        'phimbo_url': ('https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=1057024371&headers=1', 'Chọn một nguồn phim bộ')
    }

    if setting_key not in sources:
        raise ValueError("Invalid setting key")

    url, dialog_title = sources[setting_key]

    response = requests.get(url)
    data = response.text

    start_index = data.index('{')
    end_index = data.rindex('}') + 1
    json_data = data[start_index:end_index]
    data = json.loads(json_data)
    items = [(row["c"][0]["v"], row["c"][1]["v"]) for row in data["table"]["rows"]]
    choices = [item[0] for item in items]

    selected = xbmcgui.Dialog().select(dialog_title, choices)

    if selected != -1:
        phim_url = items[selected][1]
        ADDON.setSetting(setting_key, phim_url)
        alert("Đã thiết lập thành công nguồn. Đợi một lúc để cập nhật mới danh sách.")
        if xbmcvfs.exists(CACHE_PATH):
            cache_utils.clean_old_json_files()


def parse_menu_data(data):

    hotsale_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'hotsale.png')
    search_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'search_.png')
    watch_history_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'history.png')
    speedtest_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'speedtest_.png')
    codeplay_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'codeplay_.png')
    utility_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png')
    account_profile_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'account_.png')
    iptv_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'iptv.png')
    share_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'sharing.png')

    web_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'web_fshare.png')
    theloai_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
    hot_movie_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png')
    source1_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png')
    source2_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'series.png')


    icon_map = {
        'promotion_icon': hotsale_icon,
        'search_icon': search_icon,
        'watch_history_icon': watch_history_icon,
        'speedtest_icon': speedtest_icon,
        'codeplay_icon': codeplay_icon,
        'utility_icon': utility_icon,
        'account_profile_icon': account_profile_icon,
        'iptv_icon': iptv_icon,
        'share_icon': share_icon,
        'fourshare_icon': fourshare_icon,
        'web_icon': web_icon,
        'theloai_icon': theloai_icon,
        'hot_movie_icon': hot_movie_icon,
        'source1_icon': source1_icon,
        'source2_icon': source2_icon
    }

    start_index = data.index('{')
    end_index = data.rindex('}') + 1
    json_data = data[start_index:end_index]
    parsed_data = json.loads(json_data)

    items = []
    for row in parsed_data['table']['rows']:
        label = row['c'][0]['v']
        path = row['c'][1]['v']
        
        blacklist_labels = [
            "linh huynh", "hieuit", "datcine", "sharehdxx", 
            "kamenrider1997", "huỳnh phước pháp", "kphung", 
            "sontho22", "yampleigame", "imbahaha", 
            "hutapa", "meo meo"
        ]
        blacklist_urls = [
            "1-2rcg28cil-Hlw0gpvLp7J-CVhLu3rHGhukjvNfBSZI",
            "1l6TcaMsEINocqUPyLF0mhSBUW5y36tDwVDXpXImx4eY",
            "1mf4wyf59BA6rOHFii0fVCZSj4itWtu6kCMAgpo1DPtA",
            "1gSh8hZIG_z5GVia-86QnisZLGsaq5DYtO0Gj4IXy0bI",
            "1i2_cgLiSmyY3q1RB4axBid_4jM29HBw3C7rZI9QK2J8",
            "1uI8ZwdS_WbSdOLGORPsFhQUgHyUBZbXeGryjTqt4Yyo",
            "1tvD0F6l7Vm7LI9SDFDrnqKYg0G6cgppyxywAGR59C0o",
            "1WX7r75gIW8-sX72x5uzXLtam0Wruz9bMqtp5xcVPptI",
            "1pv63S_iuQCGWSSvahs-6jmehi6Ra_ka-0IIoVaQ3B4w",
            "1rsE246_ISm3LPc0H6tQw_n4iXHZRNTPZ7FVecsQdE3k",
            "1xbJ7Ia6pN0Xmvk3MXoVMWfmW18ss6MPeA3XSqySkOT8",
            "gid=1332456136"
        ]
        
        label_lower = label.lower() if isinstance(label, str) else ""
        path_lower = path.lower() if isinstance(path, str) else ""
        
        is_blacklisted = False
        for b_lbl in blacklist_labels:
            if b_lbl in label_lower:
                is_blacklisted = True
                break
        for b_url in blacklist_urls:
            if b_url.lower() in path_lower:
                is_blacklisted = True
                break
                
        if is_blacklisted:
            continue
        if isinstance(path, str):
            path = path.replace('plugin.video.vietmediaF', ADDON_ID).replace('plugin.video.vietmediaf', ADDON_ID)
            if path.startswith("http"):
                path = f"plugin://{ADDON_ID}/?url={urllib_parse.quote_plus(path)}"
        playable = row['c'][2]['v'] if len(row['c']) > 2 and row['c'][2] else False
        thumbnail_key = row['c'][3].get('v', '') if len(row['c']) > 3 and row['c'][3] else ''
        icon_key = row['c'][4].get('v', '') if len(row['c']) > 4 and row['c'][4] else ''
        label2 = row['c'][5].get('v', '') if len(row['c']) > 5 and row['c'][5] else ''
        plot = row['c'][6].get('v', '') if len(row['c']) > 6 and row['c'][6] else ''
        visible = row['c'][7]['v'] if len(row['c']) > 7 and row['c'][7] else "On"


        thumbnail = icon_map.get(thumbnail_key, '')
        icon = icon_map.get(icon_key, '')


        if not thumbnail:
            thumbnail = search_icon
        if not icon:
            icon = search_icon

        if visible == "On":
            item = {
                "label": label,
                "is_playable": False,
                "path": path,
                "thumbnail": thumbnail,
                "icon": icon,
                "label2": label2,
                "info": {"plot": plot},
                "art": {
                    "fanart": ''
                }
            }
            items.append(item)

    return items

def getMenu():
    items = [
        {
            "label": "[COLOR gold][B]Xu Hướng Phim (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=fshare_trending_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
            "label2": "Phim mới và hot nhất từ Google Sheets"
        },
        {
            "label": "[COLOR lightskyblue][B]Thể Loại Phim (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=fshare_genre_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
            "label2": "Danh sách các thể loại phim Fshare"
        },
        {
            "label": "[COLOR springgreen][B]Phim Nguồn Web (PhimAPI)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=web_source_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'web_fshare.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'web_fshare.png'),
            "label2": "Nguồn phim từ web cập nhật liên tục"
        },
        {
            "label": "[COLOR gold][B]Thư Viện Cine (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg'),
            "label2": f"Kho phim Fshare khổng lồ từ {CINE_HOST}"
        },
        {
            "label": "[COLOR gold][B]Thư Viện HD (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg'),
            "label2": f"Kho phim Fshare chất lượng cao từ {HD_HOST}"
        },
        {
            "label": "[COLOR orchid][B]Cộng Đồng Chia Sẻ[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=community_menu",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
            "label2": "Kho phim Fshare do cộng đồng đóng góp"
        },
        {
            "label": "[COLOR yellow]Lịch Sử Đã Xem[/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=play&url=__watchedHistoryList__",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'history.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'history.png'),
            "label2": "Tiếp tục xem phim dang dở"
        },
        {
            "label": "Account Profile",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=getAccFshare",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'account_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'account_.png'),
            "label2": "Thiết lập tài khoản VIP"
        },
        {
            "label": "Cài Đặt Tiện Ích",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=getTienich",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "label2": "Các tiện ích khác liên quan đến KODI"
        }
    ]
    
    if ADDON.getSetting('show_personal_collection') != 'false':
        items.append({
            "label": "[COLOR lime][B]Thêm Fshare vào Bộ sưu tập (.STRM)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=add_to_collection_dialog",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "label2": "Tạo thư mục & tệp .strm tự động từ link Fshare"
        })
        items.append({
            "label": "[COLOR yellowgreen][B]Bộ sưu tập cá nhân (.STRM)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=browse_collection",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'utilities_.png'),
            "label2": "Duyệt thư mục & tệp .strm đã lưu cục bộ"
        })
        
    items.extend([
        {
            "label": "Đo Tốc Độ Fshare",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=__speedtest__",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'speedtest_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'speedtest_.png'),
            "label2": "Đo tốc độ mạng Fshare"
        },
        {
            "label": "[COLOR yellow][B]Tìm Kiếm Phim Fshare[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=_timtrenfshare_",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'search_.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'search_.png'),
            "label2": "Tìm kiếm phim chia sẻ trên Fshare"
        }
    ])
    return {"content_type": "", "items": items}

def clean_html_plot(text):
    if not text:
        return ""
    text = text.replace('&quote;', '"').replace('&quote', '"').replace('&quot;', '"').replace('&quot', '"')
    import html
    text = html.unescape(text)
    text = re.sub(r'(?i)<br\s*/?>', '\n', text)
    text = re.sub(r'(?i)</p\s*>', '\n', text)
    text = re.sub(r'(?i)<p\s*>', '', text)
    text = re.sub(r'<[^>]*>', '', text)
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n\s*\n+', '\n\n', text)
    return text.strip()

def get_image_url(url, cdn, width=None):
    if not url:
        return ""
    if url.startswith("http://") or url.startswith("https://"):
        full_url = url
    else:
        if not cdn:
            cdn = "https://phimimg.com/"
        elif not cdn.endswith("/"):
            cdn += "/"
        if url.startswith("upload/") or url.startswith("uploads/"):
            full_url = cdn + url
        else:
            full_url = cdn + "uploads/movies/" + url
            
    try:
        w = width if width else 300
        if full_url.startswith('http'):
            if "phimimg.com" in full_url:
                full_url = full_url.replace("phimimg.com", "img.phimapi.com")
            
            clean_url = full_url.replace("https://", "").replace("http://", "")
            shard = sum(ord(c) for c in clean_url) % 4
            full_url = f"https://i{shard}.wp.com/{clean_url}?w={w}"
    except Exception:
        pass
    return full_url

_metadata_db = None

def get_metadata_db():
    global _metadata_db
    if _metadata_db is None:
        import json
        import os
        db_path = os.path.join(ADDON_PATH, "resources", "fshare_metadata_db.json")
        try:
            with open(db_path, "r", encoding="utf-8") as f:
                _metadata_db = json.load(f)
        except Exception:
            _metadata_db = {}
    return _metadata_db

def clean_title_simple(title):
    if not title:
        return ""
    from remove_accents import remove_accents
    import re
    t = remove_accents(title.lower())
    t = re.sub(r'[^a-z0-9\s]', ' ', t)
    return " ".join(t.split())

def lookup_local_rating(name, origin_name, year=None):
    db = get_metadata_db()
    if not db:
        return None
    c_name = clean_title_simple(name)
    c_origin = clean_title_simple(origin_name)
    best_match = None
    best_score = 0
    
    for db_key, meta in db.items():
        db_rating = meta.get("rating", 0.0)
        if not db_rating or db_rating == 0.0:
            continue
            
        db_year = meta.get("year")
        if year and db_year and str(year) != str(db_year):
            continue
            
        c_db_key = clean_title_simple(db_key)
        score = 0
        if c_name and c_name in c_db_key:
            score += 10
        if c_origin and c_origin in c_db_key:
            score += 10
            
        words_db = set(c_db_key.split())
        words_query = set(c_name.split())
        if c_origin:
            words_query.update(c_origin.split())
            
        intersection = words_db.intersection(words_query)
        if len(intersection) > 0:
            score += len(intersection)
            
        if score > best_score:
            best_score = score
            best_match = (db_key, db_rating, db_year)
            
    if best_match and best_score >= 11:
        return best_match[1]
    return None

TMDB_KEYS = [
    "8cf43ad9c085135b9479ad5cf6bbcbda",
    "ae4bd1b6fce2a5648671bfc171d15ba4",
    "29a551a65eef108dd01b46e27eb0554a"
]

def query_tmdb_api(path, params=None):
    import urllib.parse
    import urlquick
    import random
    
    if params is None:
        params = {}
    params['api_key'] = random.choice(TMDB_KEYS)
    
    query_str = urllib.parse.urlencode(params)
    url = f"https://api.themoviedb.org/3{path}?{query_str}"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    try:
        # Cache TMDb API responses for 30 days
        resp = urlquick.get(url, headers=headers, max_age=2592000, timeout=5)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return None

def clean_name_for_search(name):
    if not name:
        return ""
    import re
    # Remove bracketed content like (Lồng Tiếng), [Thuyết Minh], Tap 10, etc.
    n = re.sub(r'\(.*?\)', '', name)
    n = re.sub(r'\[.*?\]', '', n)
    n = re.sub(r'\s+', ' ', n)
    return n.strip()

def search_tmdb_rating(name, origin_name, year=None, is_series=False):
    search_queries = []
    if origin_name:
        search_queries.append(clean_name_for_search(origin_name))
    if name:
        search_queries.append(clean_name_for_search(name))
        
    for q in search_queries:
        if not q:
            continue
        params = {"query": q}
        path = "/search/tv" if is_series else "/search/movie"
        data = query_tmdb_api(path, params)
        if data and "results" in data:
            results = data["results"]
            for res in results:
                res_year = ""
                date_str = res.get("release_date") or res.get("first_air_date") or ""
                if date_str:
                    res_year = date_str.split("-")[0]
                    
                year_match = True
                if year and res_year:
                    try:
                        year_match = abs(int(year) - int(res_year)) <= 1
                    except:
                        pass
                        
                if year_match:
                    vote = res.get("vote_average")
                    if vote and float(vote) > 0:
                        return float(vote)
    return None

def resolve_movie_rating(name, origin_name, year=None, tmdb_id=None, tmdb_type=None, is_series=False):
    if not name and not origin_name and not tmdb_id:
        return None
        
    # Tier 1: Local DB Lookup
    try:
        rating = lookup_local_rating(name, origin_name, year)
        if rating:
            return rating
    except Exception:
        pass
        
    # Tier 2: Direct Lookup by TMDB ID
    if tmdb_id:
        media_type = tmdb_type
        if not media_type:
            media_type = "tv" if is_series else "movie"
        data = query_tmdb_api(f"/{media_type}/{tmdb_id}")
        if data:
            vote = data.get("vote_average")
            if vote and float(vote) > 0:
                return float(vote)
                
    # Tier 3: TMDb Search API
    try:
        rating = search_tmdb_rating(name, origin_name, year, is_series)
        if rating:
            return rating
    except Exception:
        pass
        
    return None

def fetch_movie_detail_parallel(items):
    if not items:
        return {}
    from resources import ophim_api
    import concurrent.futures
    import urlquick
    import xbmc
    
    enriched_items = {}
    
    def fetch_one(item):
        slug = item.get("slug")
        if not slug:
            return None
        source = item.get("source", "ophim")
        if source == "nguonc":
            api_url = f"https://phim.nguonc.com/api/film/{slug}"
            try:
                response = urlquick.get(api_url, max_age=43200, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    raw_movie = data.get("movie", {})
                    
                    casts_str = raw_movie.get("casts", "")
                    actors = [c.strip() for c in casts_str.split(",") if c.strip()] if casts_str else []
                    
                    dir_str = raw_movie.get("director", "")
                    directors = [d.strip() for d in dir_str.split(",") if d.strip()] if dir_str else []
                    
                    category_dict = raw_movie.get("category", {})
                    genres = []
                    countries = []
                    year = ""
                    for cat_id, cat_info in category_dict.items():
                        group_name = cat_info.get("group", {}).get("name", "")
                        cat_list = cat_info.get("list", [])
                        if group_name == "Thể loại":
                            genres = [{"name": c.get("name", "")} for c in cat_list]
                        elif group_name == "Quốc gia":
                            countries = [{"name": c.get("name", "")} for c in cat_list]
                        elif group_name == "Năm":
                            if cat_list:
                                year = str(cat_list[0].get("name", ""))
                                
                    movie = {
                        "content": raw_movie.get("description", ""),
                        "actor": actors,
                        "director": directors,
                        "time": raw_movie.get("time", ""),
                        "episode_current": item.get("episode_current") or raw_movie.get("current_episode", ""),
                        "category": genres,
                        "country": countries,
                        "year": year
                    }
                    
                    try:
                        name_val = raw_movie.get("name", item.get("name", ""))
                        origin_val = raw_movie.get("original_name", item.get("original_name", ""))
                        item_type = raw_movie.get("type") or item.get("type") or "single"
                        ep_current = str(item.get("episode_current") or raw_movie.get("current_episode", "")).lower()
                        is_series = item_type in ['series', 'tvshows', 'hoathinh_bo', 'grouped_series'] or (item_type == 'hoathinh' and 'full' not in ep_current)
                        rating = resolve_movie_rating(name_val, origin_val, year, is_series=is_series)
                        if rating:
                            movie["tmdb"] = {"vote_average": rating}
                    except Exception:
                        pass
                        
                    return slug, movie
            except Exception as e:
                xbmc.log(f"[CloudShare] fetch_one NguonC Error: {e}", xbmc.LOGERROR)
            
            movie = {
                "content": item.get("description", ""),
                "actor": [],
                "director": [],
                "time": "",
                "episode_current": item.get("episode_current", "")
            }
            try:
                name_val = item.get("name", "")
                origin_val = item.get("origin_name", "")
                year_val = item.get("year", "")
                item_type = item.get("type") or "single"
                ep_current = str(item.get("episode_current", "")).lower()
                is_series = item_type in ['series', 'tvshows', 'hoathinh_bo', 'grouped_series'] or (item_type == 'hoathinh' and 'full' not in ep_current)
                rating = resolve_movie_rating(name_val, origin_val, year_val, is_series=is_series)
                if rating:
                    movie["tmdb"] = {"vote_average": rating}
            except Exception:
                pass
            return slug, movie
        else:
            movie, _ = ophim_api.get_movie_detail(slug)
            if movie:
                tmdb_vote = movie.get("tmdb", {}).get("vote_average")
                imdb_vote = movie.get("imdb", {}).get("vote_average")
                has_rating = False
                if tmdb_vote and float(tmdb_vote) > 0:
                    has_rating = True
                if imdb_vote and float(imdb_vote) > 0:
                    has_rating = True
                    
                if not has_rating:
                    try:
                        name_val = movie.get("name", item.get("name", ""))
                        origin_val = movie.get("original_name", item.get("original_name", ""))
                        year_val = movie.get("year", item.get("year", ""))
                        tmdb_info = movie.get("tmdb", {})
                        tmdb_id = tmdb_info.get("id")
                        tmdb_type = tmdb_info.get("type")
                        item_type = movie.get("type") or item.get("type") or "single"
                        ep_current = str(movie.get("episode_current") or item.get("episode_current") or "").lower()
                        is_series = item_type in ['series', 'tvshows', 'hoathinh_bo', 'grouped_series'] or (item_type == 'hoathinh' and 'full' not in ep_current)
                        rating = resolve_movie_rating(name_val, origin_val, year_val, tmdb_id=tmdb_id, tmdb_type=tmdb_type, is_series=is_series)
                        if rating:
                            movie["tmdb"] = {"vote_average": rating}
                    except Exception:
                        pass
                return slug, movie
        return None
        
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(items), 30)) as executor:
        results = executor.map(fetch_one, items)
        for res in results:
            if res:
                slug, movie = res
                enriched_items[slug] = movie
                
    return enriched_items

def build_ophim_menu(items, cdn_url, endpoint, page, type_filter=None):
    list_items = []
    
    # Add Refresh button
    li_refresh = xbmcgui.ListItem(label="[COLOR springgreen][B]↺ LÀM MỚI DANH SÁCH[/B][/COLOR]")
    ref_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png')
    li_refresh.setArt({'thumb': ref_icon, 'icon': ref_icon, 'poster': ref_icon})
    li_refresh.setInfo('video', {
        'title': "Làm mới danh sách",
        'plot': "Làm mới và xóa bộ nhớ đệm danh sách phim từ web."
    })
    li_refresh.setProperty('IsPlayable', 'false')
    u_refresh = "plugin://plugin.video.cloudshare?action=fshare_refresh&type=web"
    list_items.append((u_refresh, li_refresh, False))
    
    # Previous Page (only if page > 1)
    if page > 1:
        li_prev = xbmcgui.ListItem(label="[COLOR yellow][B]<< Trang Trước[/B][/COLOR]")
        prev_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
        li_prev.setArt({'thumb': prev_icon, 'icon': prev_icon, 'poster': prev_icon})
        li_prev.setInfo('video', {
            'title': "Trang trước",
            'plot': "Quay lại trang trước"
        })
        li_prev.setProperty('IsPlayable', 'false')
        u_prev = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={endpoint}&page={page - 1}"
        if type_filter:
            u_prev += f"&type={type_filter}"
        list_items.append((u_prev, li_prev, True))
        
    # Fetch details in parallel to get plot, director, actor, duration, etc. (Always enabled for complete metadata)
    enriched_details = fetch_movie_detail_parallel(items)
        
    for item in items:
        name = item.get("name", "")
        origin_name = item.get("origin_name", "")
        slug = item.get("slug", "")
        
        # Get enriched details if available
        detail = enriched_details.get(slug, {})
        plot = clean_html_plot(detail.get("content", ""))
        actors = detail.get("actor", [])
        directors = detail.get("director", [])
        duration_str = detail.get("time") or item.get("time", "")
        
        # Parse duration to seconds
        duration_seconds = 0
        if duration_str:
            dur_match = re.search(r'(\d+)', duration_str)
            if dur_match:
                duration_seconds = int(dur_match.group(1)) * 60
        
        thumb_list = get_image_url(item.get("thumb_url", ""), cdn_url, width=300)
        poster = get_image_url(item.get("poster_url", ""), cdn_url, width=300)
        fanart = get_image_url(item.get("thumb_url", ""), cdn_url, width=1000)
        
        # Parse categories (genres) from item or detail
        categories = item.get("category") or detail.get("category") or []
        genre_names = [cat.get("name", "") for cat in categories if isinstance(cat, dict)]
        genre_str = ", ".join(genre_names)

        # Parse countries from detail
        country_str = ""
        countries = detail.get("country", [])
        if countries:
            country_names = [c.get("name", "") for c in countries if isinstance(c, dict)]
            country_str = ", ".join(country_names)

        # Parse year from item or detail
        year = str(item.get("year") or detail.get("year") or "")

        display_name = f"{name} ({year})" if year else name
        
        # Parse ratings (IMDb and TMDb)
        rating = None
        try:
            rating = item.get("tmdb", {}).get("vote_average") or detail.get("tmdb", {}).get("vote_average")
            if not rating:
                rating = item.get("imdb", {}).get("vote_average") or detail.get("imdb", {}).get("vote_average")
            if rating:
                rating = float(rating)
        except:
            rating = None
            
        episode_current = str(item.get("episode_current") or detail.get("episode_current") or "").strip()
        status = detail.get("status", "")
        episode_total = str(detail.get("episode_total", "")).strip()
        
        cur_ep = ""
        if episode_current:
            cur_match = re.search(r'(?:Tập|Tap|Ep|Episode)\s*(\d+)', episode_current, re.IGNORECASE)
            if cur_match:
                cur_ep = cur_match.group(1)
                
        # Determine movie type category (Phim Lẻ vs Phim Bộ)
        item_type = item.get("type") or detail.get("type") or "single"
        is_series = item_type in ['series', 'tvshows', 'hoathinh_bo', 'grouped_series'] or (item_type == 'hoathinh' and 'full' not in episode_current.lower())
        
        if is_series:
            status_text = "Đang chiếu"
            if status == "completed" or "hoàn tất" in episode_current.lower() or "hoantat" in episode_current.lower():
                status_text = "Hoàn tất"
            elif cur_ep and episode_total and episode_total.isdigit() and int(cur_ep) >= int(episode_total):
                status_text = "Hoàn tất"
                
            status_color = "orange" if status_text == "Đang chiếu" else "springgreen"
            status_labeled = f"[COLOR {status_color}]{status_text}[/COLOR]"
            
            if item_type == "grouped_series":
                prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {episode_current}"
            elif cur_ep and episode_total and episode_total.isdigit():
                prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled} ({cur_ep}/{episode_total})"
            elif episode_current:
                prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled} ({episode_current})"
            else:
                prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled}"
        else:
            if episode_current:
                prefix = f"[COLOR gold]Phim Lẻ[/COLOR] - [COLOR yellow]{episode_current}[/COLOR]"
            else:
                prefix = "[COLOR gold]Phim Lẻ[/COLOR]"
                
        if prefix:
            display_name = f"[{prefix}] {display_name}"
        
        plot_desc = plot if plot else name
        
        rating_str = ""
        tmdb_vote = detail.get("tmdb", {}).get("vote_average") or item.get("tmdb", {}).get("vote_average")
        if tmdb_vote and float(tmdb_vote) > 0:
            rating_str += f"TMDb {tmdb_vote}"
        imdb_vote = detail.get("imdb", {}).get("vote_average") or item.get("imdb", {}).get("vote_average")
        if imdb_vote and float(imdb_vote) > 0:
            if rating_str:
                rating_str += " | "
            rating_str += f"IMDb {imdb_vote}"
            
        if not rating_str:
            rating_str = "Chưa đánh giá"
            
        list_item = xbmcgui.ListItem(label=display_name)
        list_item.setArt({
            'thumb': thumb_list,
            'icon': poster,
            'poster': poster,
            'fanart': fanart
        })
        info = {
            'title': display_name,
            'originaltitle': origin_name,
            'mediatype': 'movie',
            'genre': genre_str,
            'plot': plot_desc,
            'rating_str': rating_str
        }
        if rating and rating > 0:
            info['rating'] = rating
            
        if duration_seconds > 0:
            info['duration'] = duration_seconds
            
        if directors:
            info['director'] = ", ".join(directors)
            
        if actors:
            info['cast'] = actors
            
        if country_str:
            info['country'] = country_str
            
        list_item.setInfo('video', loadlistitem.format_info(info))
        
        source = item.get("source", "ophim")
        episode_current_lower = episode_current.lower()
        if item_type == "grouped_series":
            group_slugs = item.get("group_slugs", "")
            play_url = f"plugin://plugin.video.cloudshare?action=ophim_show_group&title={urllib_parse.quote(name)}&slugs={urllib_parse.quote(group_slugs)}"
            is_folder = True
            list_item.setProperty('IsPlayable', 'false')
        elif item_type in ["series", "tvshows"] or (item_type == "hoathinh" and "full" not in episode_current_lower):
            play_url = f"plugin://plugin.video.cloudshare?action=ophim_episodes&title={urllib_parse.quote(name)}&slug={slug}&source={source}"
            is_folder = True
            list_item.setProperty('IsPlayable', 'false')
        else:
            play_url = f"plugin://plugin.video.cloudshare?action=smart_play&title={urllib_parse.quote(name)}&slug={slug}&source={source}"
            is_folder = False
            list_item.setProperty('IsPlayable', 'true')
            
        list_items.append((play_url, list_item, is_folder))
        
    if len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Trang Tiếp Theo >>[/B][/COLOR]")
        next_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'top.png')
        li.setArt({'thumb': next_icon, 'icon': next_icon, 'poster': next_icon})
        
        u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={endpoint}&page={next_page}"
        if type_filter:
            u += f"&type={type_filter}"
        list_items.append((u, li, True))
        
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
    xbmcplugin.endOfDirectory(HANDLE)

def getFshareMenu():
    max_age = 60 * 60
    max_retry = 3
    retry_count = 0

    while retry_count < max_retry:
        try:
            response = urlquick.get('https://docs.google.com/spreadsheets/d/1yCyQ1ZqIaeEkh5TYiXqPkTkRtrlbWkc6mL5jA2s6VqM/gviz/tq?gid=0&headers=1', max_age=max_age)
            data = response.text
            items = parse_menu_data(data)
            return {"content_type": "episodes", "items": items}
        except Exception as e:
            retry_count += 1
            xbmc.log("GoogleSheet Error:" + str(e), xbmc.LOGERROR)
            xbmc.sleep(500)
    return {"content_type": "episodes", "items": []}



def FshareHost():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    hdvn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'hdvn.jpeg')

    items = [
        {
            "label": CINE_HOST,
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=browse&url={urllib_parse.quote_plus(CINE_DOMAIN + '/menu')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": CINE_HOST,
            "info": {"plot": f"Dữ liệu được lấy từ {CINE_HOST}"},
            "art": {
                "thumb": tvcn_icon,
                "icon": tvcn_icon,
                "poster": tvcn_icon
            },
            "properties": {}
        },
        {
            "label": HD_HOST,
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=browse&url={urllib_parse.quote_plus(HD_DOMAIN + '/menu')}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": HD_HOST,
            "info": {"plot": f"Dữ liệu được lấy từ {HD_HOST}"},
            "art": {
                "thumb": tvhd_icon,
                "icon": tvhd_icon,
                "poster": tvhd_icon
            },
            "properties": {}
        },
        {
            "label": "hdvietnam.xyz",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=browse&url=https://hdvietnam/menu",
            "thumbnail": hdvn_icon,
            "icon": hdvn_icon,
            "label2": "hdvietnam.xyz",
            "info": {"plot": "Phim trên hdvietnam.xyz"},
            "art": {
                "thumb": hdvn_icon,
                "icon": hdvn_icon,
                "poster": hdvn_icon
            },
            "properties": {}
        }
    ]

    return {"content_type": "episodes", "items": items}
def getTienich():

    from resources.utils import get_tienich_data
    return get_tienich_data()
def getAccFshare():
    items = []

    password_icon = ADDON_PATH + '/resources/images/password_.png'
    settings_icon = ADDON_PATH + '/resources/images/setting_.png'
    refresh_icon = ADDON_PATH + '/resources/images/refresh_.png'
    favourite_icon = ADDON_PATH + '/resources/images/favourite_.png'
    top_icon = ADDON_PATH + '/resources/images/top_.png'
    home_icon = ADDON_PATH + '/resources/images/home_.png'



    menu_items = [
        {
            "label": "Nhập tài khoản",
            "path": "plugin://plugin.video.cloudshare?action=quick_account_menu",
            "icon": password_icon,
            "info": {"plot": "Nhập nhanh tài khoản Fshare bằng mã QR hoặc Code"}
        },
        {
            "label": "Account Settings",
            "path": "plugin://plugin.video.cloudshare?action=__settings__",
            "icon": settings_icon,
            "info": {"plot": "Truy cập Addon settings"}
        },
        {
            "label": "Cập nhập thông tin tài khoản",
            "path": "plugin://plugin.video.cloudshare?action=account_fshare",
            "icon": refresh_icon,
            "info": {"plot": "Kiểm tra và xem trạng thái tài khoản"}
        },
        {
            "label": "Fshare Favourites",
            "path": "plugin://plugin.video.cloudshare?action=action=folderxxx",
            "icon": favourite_icon,
            "info": {"plot": "Xem thông tin các thư mục yêu thích"}
        },
        {
            "label": "Fshare Top Follow",
            "path": "plugin://plugin.video.cloudshare?action=top_follow_share",
            "icon": top_icon,
            "info": {"plot": "Danh sách các file được follow nhiều nhất."}
        },
        {
            "label": "Home Fshare Acc",
            "path": "plugin://plugin.video.cloudshare?action=home_fshare",
            "icon": home_icon,
            "info": {"plot": "Xem danh sách các file trong thư mục Home"}
        },

    ]


    for i, item in enumerate(menu_items):
        menu_item = {
            "label": item["label"],
            "is_playable": False,
            "path": item["path"],
            "thumbnail": item["icon"],
            "icon": item["icon"],
            "label2": "",
            "info": item["info"]
        }
        items.append(menu_item)

    return {"content_type": "", "items": items}
def handle_google_docs_url(url):
    data = cache_utils.cache_data(url)
    if data is not None:
        if isinstance(data, dict) and "error" in data:
            xbmcgui.Dialog().ok("Lỗi Truy Cập", data["error"])
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        loadlistitem.list_item_main(data)

def extract_base_name(name):
    name = re.sub(r'\s+', ' ', name).strip()
    patterns = [
        r'\s*-\s*(?:Tập|Tap|Ep|Episode|Phần|Phan|P\.?)\s*(?:\d+|cuối|cuoi|final)\b.*$',
        r'\s+(?:Tập|Tap|Ep|Episode|Phần|Phan|P\.?)\s*(?:\d+|cuối|cuoi|final)\b.*$',
        r'\s*\((?:Tập|Tap|Ep|Episode|Phần|Phan|P\.?)\s*(?:\d+|cuối|cuoi|final)\).*$',
        r'\s*(?:-|\()?s*\d+\s*/\s*\d+\s*\)?\s*$',
        r'\s*-\s*T[aâ]p\s*(?:\d+|cuối|cuoi)\s*$',
        r'\s*-\s*(?:Phần|Phan|P)\s*\d+\s*$',
        r'\s+T[aâ]p\s+cuối\s*$',
        r'\s*-\s*(?:Tập|Tap|Ep|Episode|Phần|Phan|P\.?)\s*(?:\d+|cuối|cuoi).+$',
    ]
    base_name = name
    episode_info = ""
    for pat in patterns:
        match = re.search(pat, name, re.IGNORECASE)
        if match:
            start, end = match.span()
            base_name = name[:start].strip()
            episode_info = name[start:].strip()
            base_name = re.sub(r'[\s\-:,]+$', '', base_name).strip()
            break
    return base_name, episode_info

def is_item_tvb(label, info):
    label_lower = label.lower()
    if "tvb" in label_lower or "sctv" in label_lower:
        return True
    if info:
        country = info.get("country", "")
        if "hồng kông" in country.lower() or "hong kong" in country.lower():
            if any(kw in label_lower for kw in ["lồng tiếng", "uslt", "ffvn", "remux"]) and not "atv" in label_lower:
                return True
    return False

def is_item_atv(label, info):
    label_lower = label.lower()
    return "atv" in label_lower

def is_item_anime(label, info):
    label_lower = label.lower()
    if any(kw in label_lower for kw in ["anime", "manga", "hoạt hình nhật", "hoathinh nhat"]):
        return True
    if info:
        country = info.get("country", "")
        genre = info.get("genre", "")
        if "nhật bản" in country.lower() or "japan" in country.lower():
            if "hoạt hình" in genre.lower() or "anime" in genre.lower():
                return True
    return False

def find_web_stream_for_item(item):
    label = item.get("label", "")
    import re
    
    # Smart splitting candidate names
    candidates = []
    parentheses = re.findall(r'\((.*?)\)', label)
    cleaned_label = re.sub(r'\(.*?\)', '', label)
    parts = re.split(r'[-–—:]', cleaned_label)
    
    if parts:
        candidates.append(parts[0])
    for p in parentheses:
        p_lower = p.lower()
        if not any(tag in p_lower for tag in ["sctv", "ffvn", "uslt", "tvb", "htv", "vtv", "lồng tiếng", "thuyết minh", "remux", "phần"]):
            candidates.append(p)
    for part in parts[1:]:
        candidates.append(part)
        
    from resources import gsheet
    cleaned_candidates = []
    for c in candidates:
        # Clean TVB/ATV specific keywords before name cleaning
        c_clean = re.sub(r'\b(tvb\d*|atv\d*|sctv\d*|uslt|ffvnlt|ffvn|lt|remux|lồng tiếng|thuyết minh|trọn bộ|\d+\s*tập)\b', '', c, flags=re.IGNORECASE)
        clean = gsheet.clean_title(c_clean).strip()
        if clean and not clean.isdigit() and len(clean) > 2:
            if clean not in cleaned_candidates:
                cleaned_candidates.append(clean)
                
    if not cleaned_candidates:
        return None, None
        
    year = gsheet.extract_year(label)
    from resources import ophim_api
    
    for candidate in cleaned_candidates:
        try:
            results, cdn = ophim_api.search_movies(candidate, page=1)
            if results:
                for movie in results:
                    m_title = gsheet.clean_title(movie.get("name", ""))
                    m_orig = gsheet.clean_title(movie.get("origin_name", ""))
                    m_year = 0
                    try:
                        m_year = int(movie.get("year", 0))
                    except:
                        pass
                    
                    name_match = (candidate in m_title) or (candidate in m_orig) or (m_title in candidate) or (m_orig in candidate)
                    if name_match:
                        # Year check (allow +/- 2 years or if year is unspecified)
                        if year == 0 or m_year == 0 or abs(m_year - year) <= 2:
                            return movie, cdn
        except Exception:
            pass
            
    return None, None

_known_tvb_names = None
_known_atv_names = None

def get_known_dramas_sets():
    global _known_tvb_names, _known_atv_names
    if _known_tvb_names is None or _known_atv_names is None:
        try:
            from resources import gsheet
            data_bo = gsheet.get_aggregated_phimbo()
            items = data_bo.get("items", [])
            
            tvb_names = set()
            atv_names = set()
            
            for item in items:
                label = item.get("label", "")
                info = item.get("info", {})
                
                clean_name = gsheet.clean_title(label)
                if not clean_name:
                    continue
                    
                if is_item_atv(label, info):
                    atv_names.add(clean_name)
                elif is_item_tvb(label, info):
                    tvb_names.add(clean_name)
                    
            _known_tvb_names = tvb_names
            _known_atv_names = atv_names
        except Exception:
            _known_tvb_names = set()
            _known_atv_names = set()
    return _known_tvb_names, _known_atv_names

def matches_decade(year, decade):
    if not year:
        return False
    try:
        y = int(year)
    except:
        return False
    if decade == "2020":
        return 2020 <= y
    elif decade == "2010":
        return 2010 <= y <= 2019
    elif decade == "2000":
        return 2000 <= y <= 2009
    elif decade == "1990":
        return 1990 <= y <= 1999
    elif decade == "1980":
        return y <= 1989
    return False

def go():
    import xbmcplugin
    url = sys.argv[0]+ sys.argv[2]
    xbmc.log(f"[CloudShare] Processing URL in go(): {url}", xbmc.LOGINFO)

    if not "thread_id" in url:
        url = urllib_parse.unquote_plus(url)
        xbmc.log(f"[CloudShare] Unquoted URL: {url}", xbmc.LOGINFO)


    if 'action=thuviencine_top' in url:
        from resources import thuviencine
        data = thuviencine.tvcine_browse("https://thuviencine.live/top/")
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_menu' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_browse' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        tvcine_url = args.get('url', [''])[0]
        page = int(args.get('page', ['1'])[0])
        filter_type = args.get('filter_type', [None])[0]
        data = thuviencine.tvcine_browse(tvcine_url, page, filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_tvb_menu' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_tvb_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_phimle_menu' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_phimle_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_phimbo_menu' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_phimbo_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_phimbo_countries_menu' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_phimbo_countries_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_genres_menu' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        filter_type = args.get('filter_type', [None])[0]
        data = thuviencine.get_tvcine_genres_menu(filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_kim_dung' in url:
        from resources import thuviencine
        data = thuviencine.get_tvcine_kim_dung_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_search' in url:
        from resources import thuviencine
        thuviencine.tvcine_search()
        return

    if 'action=tvcine_play' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        tvcine_url = args.get('url', [''])[0]
        title = args.get('title', [None])[0]
        is_series_param = args.get('is_series', ['false'])[0].lower() == 'true'
        thuviencine.tvcine_play_or_add(tvcine_url, action='play', title=title, is_series=is_series_param)
        return

    if 'action=tvcine_add_collection' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        tvcine_url = args.get('url', [''])[0]
        title = args.get('title', [None])[0]
        thuviencine.tvcine_play_or_add(tvcine_url, action='add', title=title)
        return

    if 'action=tvcine_years_menu' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        filter_type = args.get('filter_type', [None])[0]
        data = thuviencine.get_tvcine_years_menu(filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=tvcine_decade_menu' in url:
        from resources import thuviencine
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        decade = args.get('decade', [''])[0]
        filter_type = args.get('filter_type', [None])[0]
        data = thuviencine.get_tvcine_decade_menu(decade, filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_menu' in url:
        from resources import thuvienhd
        data = thuvienhd.get_thuvienhd_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_tvb_menu' in url:
        from resources import thuvienhd
        data = thuvienhd.get_thuvienhd_tvb_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_phimle_menu' in url:
        from resources import thuvienhd
        data = thuvienhd.get_thuvienhd_phimle_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_phimbo_menu' in url:
        from resources import thuvienhd
        data = thuvienhd.get_thuvienhd_phimbo_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_phimbo_countries_menu' in url:
        from resources import thuvienhd
        data = thuvienhd.get_thuvienhd_phimbo_countries_menu()
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_genres_menu' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        filter_type = args.get('filter_type', [None])[0]
        data = thuvienhd.get_thuvienhd_genres_menu(filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_browse' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        thuvienhd_url = args.get('url', [''])[0]
        page = int(args.get('page', ['1'])[0])
        filter_type = args.get('filter_type', [None])[0]
        data = thuvienhd.thuvienhd_browse(thuvienhd_url, page, filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_search' in url:
        from resources import thuvienhd
        thuvienhd.thuvienhd_search()
        return

    if 'action=thuvienhd_play' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        thuvienhd_url = args.get('url', [''])[0]
        title = args.get('title', [None])[0]
        is_series_param = args.get('is_series', ['false'])[0].lower() == 'true'
        thuvienhd.thuvienhd_play_or_add(thuvienhd_url, action='play', title=title, is_series=is_series_param)
        return

    if 'action=thuvienhd_add_collection' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        thuvienhd_url = args.get('url', [''])[0]
        title = args.get('title', [None])[0]
        thuvienhd.thuvienhd_play_or_add(thuvienhd_url, action='add', title=title)
        return

    if 'action=thuvienhd_years_menu' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        filter_type = args.get('filter_type', [None])[0]
        data = thuvienhd.get_thuvienhd_years_menu(filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=thuvienhd_decade_menu' in url:
        from resources import thuvienhd
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        decade = args.get('decade', [''])[0]
        filter_type = args.get('filter_type', [None])[0]
        data = thuvienhd.get_thuvienhd_decade_menu(decade, filter_type)
        loadlistitem.list_item_main(data)
        return

    if 'action=add_to_collection_dialog' in url:
        from resources.collection_utils import add_to_collection_dialog
        add_to_collection_dialog()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'action=browse_collection' in url:
        from resources.collection_utils import browse_collection
        browse_collection(url)
        return

    if 'action=delete_from_collection' in url:
        from resources.collection_utils import delete_from_collection
        delete_from_collection(url)
        return

    if 'action=move_in_collection' in url:
        from resources.collection_utils import move_in_collection
        move_in_collection(url)
        return

    if url == 'plugin://plugin.video.cloudshare/':
        url += '?action=menu'

    if 'action=fshare_refresh' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        ref_type = args.get('type', [''])[0]
        from resources.lib.constants import CACHE_PATH, PROFILE_PATH
        
        if ref_type == 'phimle':
            try:
                p = os.path.join(CACHE_PATH, "aggregated_phimle.json")
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass
        elif ref_type == 'phimbo':
            try:
                p = os.path.join(CACHE_PATH, "aggregated_phimbo.json")
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass
        elif ref_type == 'web':
            try:
                p = os.path.join(PROFILE_PATH, ".urlquick.slite3")
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass
                
        xbmcgui.Dialog().notification("CloudShare", "Đã làm mới dữ liệu thành công!", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        xbmc.executebuiltin("Container.Refresh")
        return

    if 'action=community_menu' in url:
        data = getFshareMenu()
        loadlistitem.list_item_main(data)
        return
        
    if 'action=fshare_trending_menu' in url:
        items = [
            {
                "label": "[COLOR gold][B]Phim Lẻ (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_trending_phimle",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "label2": "Phim lẻ Fshare mới nhất"
            },
            {
                "label": "[COLOR gold][B]Phim Bộ (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_trending_phimbo",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Phim bộ Fshare mới nhất"
            },
            {
                "label": "[COLOR yellow][B]Bộ Sưu Tập Đặc Biệt[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_special_menu",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "label2": "Tuyển tập phim Kiếm hiệp Kim Dung TVB và Hoạt hình/Cổ tích lồng tiếng"
            },
            {
                "label": "[COLOR yellow][B]Tìm Kiếm Phim Fshare[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=_timtrenfshare_",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'search_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'search_.png'),
                "label2": "Tìm kiếm phim chia sẻ trên Fshare"
            }
        ]
        loadlistitem.list_item_main({"content_type": "", "items": items})
        return

    if 'action=fshare_special_menu' in url:
        items = [
            {
                "label": "[COLOR gold][B]Kiếm Hiệp Kim Dung TVB (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_special_json_list&file=fshare_kim_dung_matches.json&page=1",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "label2": "Trọn bộ Kiếm Hiệp Kim Dung do đài TVB sản xuất chơi nguồn Fshare"
            },
            {
                "label": "[COLOR gold][B]Tuyển Tập Phim TVB (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_special_year_menu&file=fshare_tvb_matches.json",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Tuyển tập phim truyền hình đài TVB Hồng Kông chơi nguồn Fshare"
            },
            {
                "label": "[COLOR gold][B]Tuyển Tập Phim ATV (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_special_year_menu&file=fshare_atv_matches.json",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Tuyển tập phim truyền hình đài ATV Hồng Kông chơi nguồn Fshare"
            },
            {
                "label": "[COLOR gold][B]Hoạt Hình & Cổ Tích (Fshare)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=fshare_special_json_list&file=fshare_anime_matches.json&page=1",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "label2": "Tuyển tập hoạt hình lồng tiếng kinh điển chơi nguồn Fshare"
            }
        ]
        loadlistitem.list_item_main({"content_type": "", "items": items})
        return

    if 'action=fshare_special_year_menu' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        json_file = args.get('file', [''])[0]
        
        json_path = os.path.join(addon_path, 'resources', json_file)
        if not os.path.exists(json_path):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
            
        with open(json_path, 'r', encoding='utf-8') as f:
            matched_items = json.load(f)
            
        groups_present = set()
        for item in matched_items:
            year = int(item.get("year", 0))
            if year >= 2020:
                groups_present.add(str(year))
            elif 2010 <= year <= 2019:
                groups_present.add("2010s")
            elif 2000 <= year <= 2009:
                groups_present.add("2000s")
            elif 1990 <= year <= 1999:
                groups_present.add("1990s")
            elif 1980 <= year <= 1989:
                groups_present.add("1980s")
            elif 0 < year < 1980:
                groups_present.add("pre1980")
                
        all_groups = [
            ("2026", "[COLOR gold][B]Năm 2026[/B][/COLOR]", "Phim phát hành năm 2026"),
            ("2025", "[COLOR gold][B]Năm 2025[/B][/COLOR]", "Phim phát hành năm 2025"),
            ("2024", "[COLOR gold][B]Năm 2024[/B][/COLOR]", "Phim phát hành năm 2024"),
            ("2023", "[COLOR gold][B]Năm 2023[/B][/COLOR]", "Phim phát hành năm 2023"),
            ("2022", "[COLOR gold][B]Năm 2022[/B][/COLOR]", "Phim phát hành năm 2022"),
            ("2021", "[COLOR gold][B]Năm 2021[/B][/COLOR]", "Phim phát hành năm 2021"),
            ("2020", "[COLOR gold][B]Năm 2020[/B][/COLOR]", "Phim phát hành năm 2020"),
            ("2010s", "[COLOR orange][B]Thập niên 2010 (2010 - 2019)[/B][/COLOR]", "Phim phát hành từ năm 2010 đến 2019"),
            ("2000s", "[COLOR orange][B]Thập niên 2000 (2000 - 2009)[/B][/COLOR]", "Phim phát hành từ năm 2000 đến 2009"),
            ("1990s", "[COLOR orange][B]Thập niên 1990 (1990 - 1999)[/B][/COLOR]", "Phim phát hành từ năm 1990 đến 1999"),
            ("1980s", "[COLOR orange][B]Thập niên 1980 (1980 - 1989)[/B][/COLOR]", "Phim phát hành từ năm 1980 đến 1989"),
            ("pre1980", "[COLOR orange][B]Trước năm 1980[/B][/COLOR]", "Phim phát hành trước năm 1980")
        ]
        
        list_items = []
        for g_id, g_label, g_desc in all_groups:
            if g_id in groups_present:
                li = xbmcgui.ListItem(label=g_label)
                li.setInfo('video', {
                    'title': g_label,
                    'plot': g_desc
                })
                icon_path = os.path.join(addon_path, 'resources', 'images', 'series.png')
                li.setArt({'thumb': icon_path, 'icon': icon_path, 'poster': icon_path})
                li.setProperty('IsPlayable', 'false')
                u = f"plugin://plugin.video.cloudshare?action=fshare_special_json_list&file={json_file}&year_group={g_id}&page=1"
                list_items.append((u, li, True))
                
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=fshare_special_json_list' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        json_file = args.get('file', [''])[0]
        page = int(args.get('page', ['1'])[0])
        year_group = args.get('year_group', [''])[0]
        
        json_path = os.path.join(addon_path, 'resources', json_file)
        if not os.path.exists(json_path):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
            
        with open(json_path, 'r', encoding='utf-8') as f:
            matched_items = json.load(f)
        try:
            matched_items.sort(key=lambda x: (-int(x.get("year", 0)) if str(x.get("year", "")).isdigit() else 0, x.get("name", "").lower()))
        except Exception:
            pass
            
        if year_group:
            filtered_items = []
            for item in matched_items:
                year = int(item.get("year", 0))
                if year_group.isdigit():
                    if year == int(year_group):
                        filtered_items.append(item)
                elif year_group == "2010s":
                    if 2010 <= year <= 2019:
                        filtered_items.append(item)
                elif year_group == "2000s":
                    if 2000 <= year <= 2009:
                        filtered_items.append(item)
                elif year_group == "1990s":
                    if 1990 <= year <= 1999:
                        filtered_items.append(item)
                elif year_group == "1980s":
                    if 1980 <= year <= 1989:
                        filtered_items.append(item)
                elif year_group == "pre1980":
                    if 0 < year < 1980:
                        filtered_items.append(item)
            matched_items = filtered_items
            
        items_per_page = 20
        total_items = len(matched_items)
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paginated_items = matched_items[start_idx:end_idx]
        
        list_items = []
        
        if page > 1:
            li_prev = xbmcgui.ListItem(label="[COLOR yellow][B]<< Trang Trước[/B][/COLOR]")
            prev_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_prev.setArt({'thumb': prev_icon, 'icon': prev_icon, 'poster': prev_icon})
            li_prev.setInfo('video', {
                'title': "Trang trước",
                'plot': "Quay lại trang trước"
            })
            li_prev.setProperty('IsPlayable', 'false')
            u_prev = f"plugin://plugin.video.cloudshare?action=fshare_special_json_list&file={json_file}&year_group={year_group}&page={page - 1}"
            list_items.append((u_prev, li_prev, True))
            
        for item in paginated_items:
            name = item.get("name")
            year = str(item.get("year", ""))
            thumb = item.get("thumb", "")
            poster = item.get("poster", "")
            fshare_url = item.get("path", "")
            plot = item.get("plot", "")
            
            display_name = f"{name} ({year})" if year else name
            
            info = {
                'title': name,
                'year': int(year) if year else 0,
                'plot': plot,
                'mediatype': 'tvshow'
            }
            
            li = xbmcgui.ListItem(label=display_name)
            li.setInfo('video', loadlistitem.format_info(info))
            
            thumb_resolved = get_image_url(thumb, "https://phimimg.com/", width=300) if thumb else os.path.join(ADDON_PATH, 'resources', 'images', 'series.png')
            poster_resolved = get_image_url(poster, "https://phimimg.com/", width=300) if poster else os.path.join(ADDON_PATH, 'resources', 'images', 'series.png')
            li.setArt({'thumb': thumb_resolved, 'icon': thumb_resolved, 'poster': poster_resolved, 'fanart': thumb_resolved})
            
            u = f"plugin://plugin.video.cloudshare/?url={urllib_parse.quote_plus(fshare_url)}"
            is_folder = True
            if "file" in fshare_url.lower() and "folder" not in fshare_url.lower():
                is_folder = False
                li.setProperty('IsPlayable', 'true')
            else:
                li.setProperty('IsPlayable', 'false')
                
            list_items.append((u, li, is_folder))
            
        if end_idx < total_items:
            li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Trang Tiếp Theo >>[/B][/COLOR]")
            next_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_next.setArt({'thumb': next_icon, 'icon': next_icon, 'poster': next_icon})
            li_next.setInfo('video', {
                'title': "Trang tiếp theo",
                'plot': "Đi tới trang tiếp theo"
            })
            li_next.setProperty('IsPlayable', 'false')
            u_next = f"plugin://plugin.video.cloudshare?action=fshare_special_json_list&file={json_file}&year_group={year_group}&page={page + 1}"
            list_items.append((u_next, li_next, True))
            
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=kim_dung_wuxia_menu' in url:
        wuxia_items = [
            {
                "slug": "anh-hung-xa-dieu",
                "name": "Anh Hùng Xạ Điêu (1994) - TVB Lồng Tiếng",
                "origin_name": "The Legend of the Condor Heroes",
                "year": 1994,
                "thumb": "https://phimimg.com/upload/vod/20251012-1/446b505b420e00b10c36e0ac6d380fd8.jpg",
                "poster": "https://phimimg.com/upload/vod/20251012-1/c31e1603efb3023cf68a43d99bcfcde2.jpg",
                "content": "Hoàng Dung là con gái của đảo chủ đảo Đào Hoa, Đông Tà Hoàng Dược Sư và Phùng Thị Mai Hương. Nàng mồ côi mẹ từ nhỏ và được cha nuôi nẵng, truyền thụ võ nghệ. Tính cách Hoàng Dung khá giống với cha mình."
            },
            {
                "slug": "than-dieu-dai-hiep",
                "name": "Thần Điêu Đại Hiệp (1995) - TVB Lồng Tiếng",
                "origin_name": "Return of The Condor Heroes",
                "year": 1995,
                "thumb": "https://phimimg.com/upload/vod/20230911-1/6529643631bdf3a314dd006ea0bb6055.jpg",
                "poster": "https://phimimg.com/upload/vod/20230911-1/991875626a4e975c95a989e9d04d280d.jpg",
                "content": "Thần điêu đại hiệp là bộ phim truyền hình do đài truyền hình TVB - Hồng Kông phát hành dựa trên tiểu thuyết cùng tên của nhà văn Kim Dung."
            },
            {
                "slug": "thien-long-bat-bo-1997",
                "name": "Thiên Long Bát Bộ (1997) - TVB Lồng Tiếng",
                "origin_name": "The Demi-Gods and Semi-Devils",
                "year": 1997,
                "thumb": "https://phimimg.com/upload/vod/20241005-1/59727cd8a7cd1e325abfcd053dcd9194.jpg",
                "poster": "https://phimimg.com/upload/vod/20241005-1/ad09f95f117c2fabbf3bea4eca4fd1aa.jpg",
                "content": "Được đánh giá là bản chuyển thể hay nhất, sát nguyên bản nhất của tiểu thuyết Thiên Long Bát Bộ của nhà văn Kim Dung. Kiều Phong, Đoàn Dự, Hư Trúc, ba người ba hoàn cảnh kết nghĩa huynh đệ."
            },
            {
                "slug": "loc-dinh-ky-1998",
                "name": "Lộc Đỉnh Ký (1998) - TVB Lồng Tiếng",
                "origin_name": "The Duke Of Mount Deer",
                "year": 1998,
                "thumb": "https://phimimg.com/upload/vod/20250303-1/cf45da6077b41ec232380e107d58fc72.jpg",
                "poster": "https://phimimg.com/upload/vod/20250303-1/c40b8085ed2236458b98ca8ed94a24e2.jpg",
                "content": "Vi Tiểu Bảo từ nhỏ theo mẹ sống trong kỷ viện ở Dương Châu; bởi tình cờ biết được bí mật trong cung, nên anh ta bị ép ở lại làm thái giám giả. Sau đó Tiểu Bảo giúp sức tiểu hoàng đế Khang Hy."
            },
            {
                "slug": "bich-huyet-kiem",
                "name": "Bích Huyết Kiếm (1985) - TVB Lồng Tiếng",
                "origin_name": "The Sword Stained With Royal Blood",
                "year": 1985,
                "thumb": "https://phimimg.com/upload/vod/20251014-1/b3353e69171fd5977440dfd5ccc08dab.jpg",
                "poster": "https://phimimg.com/upload/vod/20251014-1/c3bfaf5ac47bb77117871454b4910f5e.jpg",
                "content": "Thanh kiếm nhuộm máu hoàng gia là một bộ phim truyền hình Hồng Kông được chuyển thể từ tiểu thuyết cùng tên của Louis Cha. Phim được phát sóng lần đầu tiên trên TVB ở Hồng Kông vào năm 1985."
            },
            {
                "slug": "hiep-khach-hanh",
                "name": "Hiệp Khách Hành (1989) - TVB Lồng Tiếng",
                "origin_name": "Hap Hak Hang",
                "year": 1989,
                "thumb": "https://phimimg.com/upload/vod/20240613-1/0e50040d6361f0bd5d73118cf3c50f83.jpg",
                "poster": "https://phimimg.com/upload/vod/20240613-1/d313c896e37839dc287fe685b43cc2dd.jpg",
                "content": "Hiệp khách hành năm 1989 của TVB là một trong những phiên bản phim kinh điển, tái hiện thành công tiểu thuyết cùng tên của nhà văn Kim Dung. Có sự góp mặt của Tony Leung Triều Vĩ."
            },
            {
                "slug": "tan-y-thien-do-long-ky",
                "name": "Tân Ỷ Thiên Đồ Long Ký (2019) - TVB Lồng Tiếng",
                "origin_name": "The Heaven Sword And Dragon Saber",
                "year": 2019,
                "thumb": "https://phimimg.com/upload/vod/20240904-1/d626a1057268ff09154b31e44be76b3e.jpg",
                "poster": "https://phimimg.com/upload/vod/20240904-1/0487844ee5878d43db78693df1b5d55d.jpg",
                "content": "Phiên bản chuyển thể lần thứ 8 của tác phẩm đã để lại nhiều đánh giá khác nhau. Các diễn viên của phiên bản như Tăng Thuấn Hy (Trương Vô Kỵ), Trần Ngọc Kỳ (Triệu Mẫn)..."
            },
            {
                "slug": "tan-anh-hung-xa-dieu",
                "name": "Tân Anh Hùng Xạ Điêu (2017)",
                "origin_name": "The Legend Of The Condor Heroes",
                "year": 2017,
                "thumb": "https://phimimg.com/upload/vod/20250513-1/0c0611b696115c5c5a7131b940ac46e5.jpg",
                "poster": "https://phimimg.com/upload/vod/20230911-1/f8b1255856bb47a49b74d79b8e839c1a.jpg",
                "content": "Là một trong những bộ phim làm lại được đánh giá cao nhất, phim giành giải thưởng tại Golden Guduo Media Awards lần II và được phát hành rộng rãi ở nhiều quốc gia châu Á."
            },
            {
                "slug": "tan-than-dieu-dai-hiep",
                "name": "Tân Thần Điêu Đại Hiệp (2014)",
                "origin_name": "The Romance of the Condor Heroes",
                "year": 2014,
                "thumb": "https://phimimg.com/upload/vod/20230911-1/ee0d59458c3ec16ac71fa036faf2f412.jpg",
                "poster": "https://phimimg.com/upload/vod/20230911-1/ee0d59458c3ec16ac71fa036faf2f412.jpg",
                "content": "Bối cảnh của Thần điêu hiệp lữ là vào cuối thời Nam Tống, khi quân Mông Cổ đã lớn mạnh. Câu chuyện xoay quanh mối tình khắc cốt ghi tâm của Dương Quá và Tiểu Long Nữ."
            }
        ]
        
        list_items = []
        for w in wuxia_items:
            u = f"plugin://plugin.video.cloudshare?action=ophim_episodes&title={urllib_parse.quote(w['name'])}&slug={w['slug']}"
            li = xbmcgui.ListItem(label=w['name'])
            
            info = {
                'title': w['name'],
                'plot': w['content'],
                'year': int(w['year']),
                'mediatype': 'tvshow'
            }
            li.setInfo('video', loadlistitem.format_info(info))
            thumb_url = get_image_url(w['thumb'], "https://phimimg.com/", width=300)
            poster_url = get_image_url(w['poster'], "https://phimimg.com/", width=300)
            li.setArt({'thumb': thumb_url, 'icon': thumb_url, 'poster': poster_url})
            li.setProperty('IsPlayable', 'false')
            list_items.append((u, li, True))
            
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=classic_anime_menu' in url:
        anime_items = [
            {
                "slug": "co-be-maruko",
                "name": "Cô Bé Maruko (1990) - Lồng Tiếng",
                "origin_name": "Chibi Maruko-chan",
                "year": 1990,
                "thumb": "https://phimimg.com/upload/vod/20250819-1/fd7790af0f1cd2c3f70b72bc6b0b0233.jpg",
                "poster": "https://phimimg.com/upload/vod/20250819-1/30aed65c3277ccebf79cf8325afb8c08.jpg",
                "content": "\"Chibi Maruko-chan\" xoay quanh cuộc sống thường nhật của cô bé tiểu học tên Maruko (Momoko Sakura) sống cùng gia đình ở thành phố Shimizu, tỉnh Shizuoka (Nhật Bản), vào những năm 1970."
            },
            {
                "slug": "tham-tu-lung-danh-conan",
                "name": "Thám Tử Lừng Danh Conan (1996) - Lồng Tiếng",
                "origin_name": "Detective Conan",
                "year": 1996,
                "thumb": "https://phimimg.com/upload/vod/20240310-1/2a39971cc29c2802259b918eb437a45b.jpg",
                "poster": "https://phimimg.com/upload/vod/20240310-1/025424cf62248b9a7b54279ef5416e26.jpg",
                "content": "Phim hoạt hình Conan bắt đầu sau vụ việc xảy ra tại công viên giải trí nổi tiếng Tropical Land tại khu tàu lượn siêu tốc. Kudo đang điều tra một trong hai người đàn ông có vẻ ngoài khả nghi..."
            },
            {
                "slug": "bien-tau-grimm",
                "name": "Biến Tấu Grimm (2024) - Lồng Tiếng",
                "origin_name": "The Grimm Variations",
                "year": 2024,
                "thumb": "https://phimimg.com/upload/vod/20240418-1/09a1a6f460b0f5c094a940cf7dc5a846.jpg",
                "poster": "https://phimimg.com/upload/vod/20240418-1/4145c1fde0c12e3f50250f9106fc8e08.jpg",
                "content": "Lấy cảm hứng từ những câu chuyện kinh điển của anh em nhà Grimm, hợp tuyển này bao gồm sáu câu chuyện cổ tích có biến tấu đen tối, vạch trần mặt tối trong ham muốn của con người."
            },
            {
                "slug": "truyen-co-hac-am-grimm",
                "name": "Truyện Cổ Hắc Ám Grimm (2021) - Lồng Tiếng",
                "origin_name": "A Tale Dark & Grimm",
                "year": 2021,
                "thumb": "https://phimimg.com/upload/vod/20240615-1/cc2a47f690a35e51a787bc3c74845421.jpg",
                "poster": "https://phimimg.com/upload/vod/20240615-1/b37ac50ec22df746f9f30db65352e561.jpg",
                "content": "Hãy theo chân Hansel và Gretel rời câu chuyện của họ để bước vào câu chuyện hóm hỉnh mà tinh quái và lắt léo, ngập tràn bất ngờ lạ thường và đáng sợ."
            },
            {
                "slug": "dau-an-rong-thieng-ban-1991",
                "name": "Dấu Ấn Rồng Thiêng (1991) - Lồng Tiếng",
                "origin_name": "Dragon Quest: The Adventure Of Dai",
                "year": 1991,
                "thumb": "https://phimimg.com/upload/vod/20260113-1/84439f817d86682ebf2b1602d44e6bf7.jpg",
                "poster": "https://phimimg.com/upload/vod/20260113-1/8e16ca9d4920f2deb462d96b078dde92.jpg",
                "content": "Sau thất bại của Ma vương Hadlar, tất cả quái vật đã được giải phóng khỏi ý chí tà ác của hắn và chuyển đến đảo Delmurin để sống trong hòa bình. Dai là con người duy nhất sinh sống trên hòn đảo này."
            },
            {
                "slug": "vua-tro-choi-2000",
                "name": "Vua Trò Chơi Yu-Gi-Oh! (2000) - Lồng Tiếng",
                "origin_name": "Yu-Gi-Oh! Duel Monsters",
                "year": 2000,
                "thumb": "https://phimimg.com/upload/vod/20241124-1/5b9a1d1216a06bb3244c3fdb1929674a.jpg",
                "poster": "https://phimimg.com/upload/vod/20241124-1/39cae382ef85b1fb744f95ecd2f898e7.jpg",
                "content": "Yu-Gi-Oh! Duel Monsters kể về Muto Yugi, một học sinh trường Domino có tính cách nhút nhát, hiền lành. Cậu giải mã Trò chơi Ngàn năm và đánh thức một nhân cách thứ hai đầy tài năng."
            },
            {
                "slug": "pokemon",
                "name": "Pokémon (1997) - Lồng Tiếng",
                "origin_name": "Pokémon",
                "year": 1997,
                "thumb": "https://phimimg.com/upload/vod/20250526-1/29a133310b54f36022da321e97e46e82.jpg",
                "poster": "https://phimimg.com/upload/vod/20250526-1/44fcb1476d32e4a89e0dd97ea405b100.jpg",
                "content": "Phim xoay quanh cuộc phiêu lưu của nhân vật Satoshi, đi thu nhập những Pokémon đồng hành và mục tiêu trở thành nhà huấn luyện Pokémon tài ba."
            },
            {
                "slug": "thuy-thu-mat-trang-pha-le",
                "name": "Thủy Thủ Mặt Trăng Pha Lê (2014) - Lồng Tiếng",
                "origin_name": "Pretty Guardian Sailor Moon Crystal",
                "year": 2014,
                "thumb": "https://phimimg.com/upload/vod/20250309-1/4f40347c94895d3984f35d55900d1634.jpg",
                "poster": "https://phimimg.com/upload/vod/20250309-1/f0b87658793f47893b6cec3420b9de2c.jpg",
                "content": "Thủy Thủ Mặt Trăng Pha Lê kể về cô bé Tsukino Usagi hoạt bát cởi mở sau khi tình cờ gặp chú mèo đen Luna có hình mặt trăng khuyết trên đầu đã biến hình thành Thủy thủ bảo vệ công lý."
            }
        ]

        list_items = []
        for a in anime_items:
            u = f"plugin://plugin.video.cloudshare?action=ophim_episodes&title={urllib_parse.quote(a['name'])}&slug={a['slug']}"
            li = xbmcgui.ListItem(label=a['name'])
            
            info = {
                'title': a['name'],
                'plot': a['content'],
                'year': int(a['year']),
                'mediatype': 'tvshow'
            }
            li.setInfo('video', loadlistitem.format_info(info))
            thumb_url = get_image_url(a['thumb'], "https://phimimg.com/", width=300)
            poster_url = get_image_url(a['poster'], "https://phimimg.com/", width=300)
            li.setArt({'thumb': thumb_url, 'icon': thumb_url, 'poster': poster_url})
            li.setProperty('IsPlayable', 'false')
            list_items.append((u, li, True))
            
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=fshare_special_decades' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        collection = args.get('collection', [''])[0]
        decades = [
            ("Thập niên 2020", "2020"),
            ("Thập niên 2010", "2010"),
            ("Thập niên 2000", "2000"),
            ("Thập niên 1990", "1990"),
            ("Thập niên 1980 trở về trước", "1980")
        ]
        items = []
        for dec_label, dec_val in decades:
            items.append({
                "label": f"[COLOR yellow]{dec_label}[/COLOR]",
                "is_playable": False,
                "is_folder": True,
                "path": f"plugin://plugin.video.cloudshare?action=fshare_special_list&collection={collection}&decade={dec_val}",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "label2": f"Danh sách phim {collection.upper()} thuộc {dec_label}"
            })
        loadlistitem.list_item_main({"content_type": "", "items": items})
        return

    if 'action=fshare_special_list' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        collection = args.get('collection', [''])[0]
        decade = args.get('decade', [''])[0]
        page = int(args.get('page', ['1'])[0])
        
        from resources import gsheet
        data_le = gsheet.get_aggregated_phimle()
        data_bo = gsheet.get_aggregated_phimbo()
        
        combined_items = data_le.get("items", []) + data_bo.get("items", [])
        seen_paths = set()
        unique_combined = []
        for item in combined_items:
            path = item.get("path", "")
            if path not in seen_paths:
                seen_paths.add(path)
                unique_combined.append(item)
                
        def get_sort_key(x):
            year = x.get("info", {}).get("year", 0)
            return (-year, x.get("label", ""))
            
        unique_combined.sort(key=get_sort_key)
        
        filtered_items = []
        for item in unique_combined:
            label = item.get("label", "")
            info = item.get("info", {})
            
            is_match = False
            if collection == 'tvb':
                is_match = is_item_tvb(label, info)
            elif collection == 'atv':
                is_match = is_item_atv(label, info)
            elif collection == 'anime':
                is_match = is_item_anime(label, info)
                
            if not is_match:
                continue
                
            year = info.get("year", 0)
            if matches_decade(year, decade):
                filtered_items.append(item)
                
        items_per_page = 20
        total_items = len(filtered_items)
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paginated_items = filtered_items[start_idx:end_idx]
        
        web_matched_items = []
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('CloudShare', 'Đang tìm nguồn phim web...')
        
        def process_item(item):
            movie, cdn = find_web_stream_for_item(item)
            if movie:
                return item, movie, cdn
            return item, None, None
            
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, len(paginated_items))) as executor:
            results = list(executor.map(process_item, paginated_items))
            for orig_item, movie, cdn in results:
                if movie:
                    web_matched_items.append((orig_item, movie, cdn))
                    
        pDialog.close()
        
        list_items = []
        
        li_refresh = xbmcgui.ListItem(label="[COLOR springgreen][B]↺ LÀM MỚI DANH SÁCH[/B][/COLOR]")
        ref_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png')
        li_refresh.setArt({'thumb': ref_icon, 'icon': ref_icon, 'poster': ref_icon})
        li_refresh.setInfo('video', {
            'title': "Làm mới danh sách",
            'plot': "Làm mới danh sách phim từ Google Sheets."
        })
        li_refresh.setProperty('IsPlayable', 'false')
        u_refresh = "plugin://plugin.video.cloudshare?action=fshare_refresh&type=phimbo"
        list_items.append((u_refresh, li_refresh, False))
        
        if page > 1:
            li_prev = xbmcgui.ListItem(label="[COLOR yellow][B]<< Trang Trước[/B][/COLOR]")
            prev_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_prev.setArt({'thumb': prev_icon, 'icon': prev_icon, 'poster': prev_icon})
            li_prev.setInfo('video', {
                'title': "Trang trước",
                'plot': "Quay lại trang trước"
            })
            li_prev.setProperty('IsPlayable', 'false')
            u_prev = f"plugin://plugin.video.cloudshare?action=fshare_special_list&collection={collection}&decade={decade}&page={page - 1}"
            list_items.append((u_prev, li_prev, True))
            
        for orig_item, movie, cdn in web_matched_items:
            label = orig_item.get("label", "")
            label = re.sub(r' - \[COLOR gold\]★ \d+\.\d+\[/COLOR\]', '', label)
            slug = movie.get("slug", "")
            
            item_type = movie.get("type") or "single"
            is_series = item_type in ['series', 'tvshows', 'hoathinh_bo', 'grouped_series']
            
            if is_series:
                u = f"plugin://plugin.video.cloudshare?action=ophim_episodes&title={urllib_parse.quote(label)}&slug={slug}"
                is_folder = True
                playable = 'false'
            else:
                u = f"plugin://plugin.video.cloudshare?action=smart_play&title={urllib_parse.quote(label)}&slug={slug}"
                is_folder = False
                playable = 'true'
                
            li = xbmcgui.ListItem(label=label)
            
            plot = orig_item.get("info", {}).get("plot", "")
            if not plot:
                plot = movie.get("content", "") or movie.get("description", "")
                plot = re.sub(r'<[^>]*>', '', plot).strip()
                
            year = movie.get("year") or orig_item.get("info", {}).get("year", 0)
            
            info = {
                'title': label,
                'plot': plot,
                'year': int(year) if year else 0,
                'mediatype': 'movie' if not is_folder else 'tvshow',
            }
            li.setInfo('video', loadlistitem.format_info(info))
            
            thumb = orig_item.get("thumbnail")
            if not thumb and cdn:
                thumb = get_image_url(movie.get("thumb_url", ""), cdn, width=300)
            poster = orig_item.get("art", {}).get("poster")
            if not poster and cdn:
                poster = get_image_url(movie.get("poster_url", ""), cdn, width=300)
            fanart = orig_item.get("art", {}).get("fanart")
            if not fanart and cdn:
                fanart = get_image_url(movie.get("thumb_url", ""), cdn, width=1000)
                
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': poster, 'fanart': fanart})
            li.setProperty('IsPlayable', playable)
            list_items.append((u, li, is_folder))
            
        if end_idx < total_items:
            li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Trang Tiếp Theo >>[/B][/COLOR]")
            next_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_next.setArt({'thumb': next_icon, 'icon': next_icon, 'poster': next_icon})
            li_next.setInfo('video', {
                'title': "Trang tiếp theo",
                'plot': "Đi tới trang tiếp theo"
            })
            li_next.setProperty('IsPlayable', 'false')
            u_next = f"plugin://plugin.video.cloudshare?action=fshare_special_list&collection={collection}&decade={decade}&page={page + 1}"
            list_items.append((u_next, li_next, True))
            
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return



    if 'action=fshare_trending_phimle' in url:
        from resources import gsheet
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        page = int(args.get('page', ['1'])[0])
        
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('CloudShare', 'Đang tải danh sách phim lẻ Fshare...')
        try:
            data = gsheet.get_aggregated_phimle()
            pDialog.close()
            if data and data.get("items"):
                # Paginate items (20 per page)
                items_per_page = 20
                all_items = data["items"]
                total_items = len(all_items)
                
                start_idx = (page - 1) * items_per_page
                end_idx = start_idx + items_per_page
                page_items = all_items[start_idx:end_idx]
                
                # Build paginated items list
                paginated_items = []
                
                # Refresh button
                paginated_items.append({
                    "label": "[COLOR springgreen][B]↺ LÀM MỚI DANH SÁCH[/B][/COLOR]",
                    "is_playable": False,
                    "is_folder": False,
                    "path": "plugin://plugin.video.cloudshare?action=fshare_refresh&type=phimle",
                    "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
                    "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
                    "label2": "Tải lại danh sách phim mới nhất",
                    "info": {"plot": "Làm mới và tải lại danh sách phim từ Google Sheets."}
                })
                
                # Previous Page
                if page > 1:
                    paginated_items.append({
                        "label": "[COLOR yellow][B]<< Trang Trước (Trang %d)[/B][/COLOR]" % (page - 1),
                        "is_playable": False,
                        "is_folder": True,
                        "path": "plugin://plugin.video.cloudshare?action=fshare_trending_phimle&page=%d" % (page - 1),
                        "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "label2": "Quay lại trang %d" % (page - 1),
                        "info": {"plot": "Quay lại trang %d" % (page - 1)}
                    })
                    
                # Movie items
                paginated_items.extend(page_items)
                
                # Next Page
                if end_idx < total_items:
                    paginated_items.append({
                        "label": "[COLOR yellow][B]Trang Tiếp Theo >> (Trang %d)[/B][/COLOR]" % (page + 1),
                        "is_playable": False,
                        "is_folder": True,
                        "path": "plugin://plugin.video.cloudshare?action=fshare_trending_phimle&page=%d" % (page + 1),
                        "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "label2": "Xem tiếp trang %d" % (page + 1),
                        "info": {"plot": "Xem tiếp các phim trang %d" % (page + 1)}
                    })
                    
                loadlistitem.list_item_main({"content_type": "movies", "items": paginated_items})
            else:
                xbmcgui.Dialog().ok("Thông báo", "Không tìm thấy dữ liệu.")
                import xbmcplugin
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception as e:
            pDialog.close()
            xbmcgui.Dialog().ok("Lỗi", str(e))
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'action=fshare_trending_phimbo' in url:
        from resources import gsheet
        split_url = url.split('?', 1)
        args = urllib_parse.parse_qs(split_url[1]) if len(split_url) > 1 else {}
        
        country = args.get('country', [''])[0]
        page = int(args.get('page', ['1'])[0])
        
        if not country:
            # Display menu of countries
            country_icons = {
                "all": "series.png",
                "Hàn Quốc": "genres/korea.png",
                "Trung Quốc": "genres/china.png",
                "Mỹ": "genres/us.png",
                "Thái Lan": "genres/thailand.png",
                "Hồng Kông": "genres/hongkong.png",
                "Nhật Bản": "genres/japan.png",
                "Đài Loan": "genres/taiwan.png"
            }
            countries = ["all", "Hàn Quốc", "Trung Quốc", "Mỹ", "Thái Lan", "Hồng Kông", "Nhật Bản", "Đài Loan"]
            country_labels = {
                "all": "Tất Cả Phim Bộ",
                "Hàn Quốc": "Phim Bộ Hàn Quốc",
                "Trung Quốc": "Phim Bộ Trung Quốc",
                "Mỹ": "Phim Bộ Mỹ (US)",
                "Thái Lan": "Phim Bộ Thái Lan",
                "Hồng Kông": "Phim Bộ Hồng Kông",
                "Nhật Bản": "Phim Bộ Nhật Bản",
                "Đài Loan": "Phim Bộ Đài Loan"
            }
            
            items = []
            for c in countries:
                icon_file = country_icons[c]
                if "/" in icon_file:
                    icon_path = os.path.join(ADDON_PATH, 'resources', 'images', icon_file.replace("/", os.sep))
                else:
                    icon_path = os.path.join(ADDON_PATH, 'resources', 'images', icon_file)
                if not os.path.exists(icon_path):
                    icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'series.png')
                    
                items.append({
                    "label": f"[COLOR gold][B]{country_labels[c]}[/B][/COLOR]",
                    "is_playable": False,
                    "is_folder": True,
                    "path": f"plugin://plugin.video.cloudshare?action=fshare_trending_phimbo&country={urllib_parse.quote(c)}",
                    "thumbnail": icon_path,
                    "icon": icon_path,
                    "label2": country_labels[c]
                })
            loadlistitem.list_item_main({"content_type": "", "items": items})
            return

        pDialog = xbmcgui.DialogProgress()
        pDialog.create('CloudShare', 'Đang tải danh sách phim bộ Fshare...')
        try:
            data = gsheet.get_aggregated_phimbo()
            pDialog.close()
            if data and data.get("items"):
                all_items = data["items"]
                
                # Filter by country if not 'all'
                if country != 'all':
                    import unicodedata
                    filtered_items = []
                    main_countries = ["Hàn Quốc", "Trung Quốc", "Mỹ", "Thái Lan", "Hồng Kông", "Nhật Bản", "Đài Loan"]
                    
                    if country == 'Khác':
                        # Exclude any item containing main countries in their genre
                        for item in all_items:
                            genre = item.get("info", {}).get("genre", "")
                            norm_genre = unicodedata.normalize('NFC', genre).lower()
                            has_main = False
                            for mc in main_countries:
                                if unicodedata.normalize('NFC', mc).lower() in norm_genre:
                                    has_main = True
                                    break
                            if not has_main:
                                filtered_items.append(item)
                    else:
                        norm_target = unicodedata.normalize('NFC', country).lower()
                        for item in all_items:
                            genre = item.get("info", {}).get("genre", "")
                            norm_genre = unicodedata.normalize('NFC', genre).lower()
                            if norm_target in norm_genre:
                                filtered_items.append(item)
                    all_items = filtered_items
                    
                total_items = len(all_items)
                
                # Paginate items (20 per page)
                items_per_page = 20
                start_idx = (page - 1) * items_per_page
                end_idx = start_idx + items_per_page
                page_items = all_items[start_idx:end_idx]
                
                # Build paginated items list
                paginated_items = []
                
                # Refresh button (preserve country)
                paginated_items.append({
                    "label": "[COLOR springgreen][B]↺ LÀM MỚI DANH SÁCH[/B][/COLOR]",
                    "is_playable": False,
                    "is_folder": False,
                    "path": f"plugin://plugin.video.cloudshare?action=fshare_refresh&type=phimbo&country={urllib_parse.quote(country)}",
                    "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
                    "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
                    "label2": "Tải lại danh sách phim mới nhất",
                    "info": {"plot": "Làm mới và tải lại danh sách phim từ Google Sheets."}
                })
                
                # Previous Page (preserve country)
                if page > 1:
                    paginated_items.append({
                        "label": "[COLOR yellow][B]<< Trang Trước (Trang %d)[/B][/COLOR]" % (page - 1),
                        "is_playable": False,
                        "is_folder": True,
                        "path": f"plugin://plugin.video.cloudshare?action=fshare_trending_phimbo&country={urllib_parse.quote(country)}&page={page - 1}",
                        "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "label2": "Quay lại trang %d" % (page - 1),
                        "info": {"plot": "Quay lại trang %d" % (page - 1)}
                    })
                    
                # Movie items
                paginated_items.extend(page_items)
                
                # Next Page (preserve country)
                if end_idx < total_items:
                    paginated_items.append({
                        "label": "[COLOR yellow][B]Trang Tiếp Theo >> (Trang %d)[/B][/COLOR]" % (page + 1),
                        "is_playable": False,
                        "is_folder": True,
                        "path": f"plugin://plugin.video.cloudshare?action=fshare_trending_phimbo&country={urllib_parse.quote(country)}&page={page + 1}",
                        "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                        "label2": "Xem tiếp trang %d" % (page + 1),
                        "info": {"plot": "Xem tiếp các phim trang %d" % (page + 1)}
                    })
                    
                loadlistitem.list_item_main({"content_type": "tvshows", "items": paginated_items})
            else:
                xbmcgui.Dialog().ok("Thông báo", "Không tìm thấy dữ liệu.")
                import xbmcplugin
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception as e:
            pDialog.close()
            xbmcgui.Dialog().ok("Lỗi", str(e))
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'action=fshare_genre_menu' in url:
        try:
            list_items = []
            genre_icons = {
                "Hành Động": "_action.png",
                "Tình Cảm": "romance_.png",
                "Hài Hước": "comedy.png",
                "Cổ Trang": "history_.png",
                "Tâm Lý": "drama_.png",
                "Hình Sự": "crime_.png",
                "Chiến Tranh": "war__politics.png",
                "Võ Thuật": "_action.png",
                "Viễn Tưởng": "sci_fi_.png",
                "Phiêu Lưu": "_adventure_.png",
                "Khoa Học": "documentary_.png",
                "Kinh Dị": "horror_.png",
                "Âm Nhạc": "musical_.png",
                "Thần Thoại": "fantasy_.png",
                "Tài Liệu": "documentary_.png",
                "Gia Đình": "family_.png",
                "Chính Kịch": "drama_.png",
                "Bí Ẩn": "mystery_.png",
                "Học Đường": "comedy.png",
                "Khác (Chưa Phân Loại)": "genres.png"
            }
            
            genres = sorted(list(genre_icons.keys()))
            
            for g in genres:
                li = xbmcgui.ListItem(label=g)
                icon_file = genre_icons.get(g, "genres.png")
                icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'genres', icon_file)
                if not os.path.exists(icon_path):
                    icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
                li.setArt({'thumb': icon_path, 'icon': icon_path, 'poster': icon_path})
                u = f"plugin://plugin.video.cloudshare?action=fshare_genre_list&genre={urllib_parse.quote(g)}"
                list_items.append((u, li, True))
                
            xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception as e:
            xbmcgui.Dialog().ok("Lỗi", str(e))
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'action=fshare_genre_list' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        genre_name = args.get('genre', [''])[0]
        page = int(args.get('page', ['1'])[0])
        
        from resources import gsheet
        data_le = gsheet.get_aggregated_phimle()
        data_bo = gsheet.get_aggregated_phimbo()
        
        combined_items = data_le.get("items", []) + data_bo.get("items", [])
        seen_paths = set()
        unique_combined = []
        for item in combined_items:
            path = item.get("path", "")
            if path not in seen_paths:
                seen_paths.add(path)
                unique_combined.append(item)
                
        def get_sort_key(x):
            year = x.get("info", {}).get("year", 0)
            return (-year, x.get("label", ""))
            
        unique_combined.sort(key=get_sort_key)
                
        filtered_items = []
        is_khac = (genre_name == "Khác (Chưa Phân Loại)")
        import unicodedata
        normalized_target_genre = unicodedata.normalize('NFC', genre_name).lower()
        for item in unique_combined:
            item_genre = item.get("info", {}).get("genre", "")
            if is_khac:
                if not item_genre or item_genre.strip() == "":
                    filtered_items.append(item)
            else:
                normalized_item_genre = unicodedata.normalize('NFC', item_genre).lower()
                if normalized_target_genre in normalized_item_genre:
                    filtered_items.append(item)
                
        total_items = len(filtered_items)
        items_per_page = 20
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        page_items = filtered_items[start_idx:end_idx]
        
        # Build paginated items list
        paginated_items = []
        
        # Refresh button
        paginated_items.append({
            "label": "[COLOR springgreen][B]↺ LÀM MỚI DANH SÁCH[/B][/COLOR]",
            "is_playable": False,
            "is_folder": False,
            "path": "plugin://plugin.video.cloudshare?action=fshare_refresh&type=phimle",
            "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
            "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'refresh.png'),
            "label2": "Tải lại danh sách phim mới nhất",
            "info": {"plot": "Làm mới và tải lại danh sách phim từ Google Sheets."}
        })
        
        # Previous Page
        if page > 1:
            paginated_items.append({
                "label": "[COLOR yellow][B]<< Trang Trước (Trang %d)[/B][/COLOR]" % (page - 1),
                "is_playable": False,
                "is_folder": True,
                "path": f"plugin://plugin.video.cloudshare?action=fshare_genre_list&genre={urllib_parse.quote(genre_name)}&page={page - 1}",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "label2": "Quay lại trang %d" % (page - 1),
                "info": {"plot": "Quay lại trang %d" % (page - 1)}
            })
            
        # Movie items
        paginated_items.extend(page_items)
        
        # Next Page
        if end_idx < total_items:
            paginated_items.append({
                "label": "[COLOR yellow][B]Trang Tiếp Theo >> (Trang %d)[/B][/COLOR]" % (page + 1),
                "is_playable": False,
                "is_folder": True,
                "path": f"plugin://plugin.video.cloudshare?action=fshare_genre_list&genre={urllib_parse.quote(genre_name)}&page={page + 1}",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "label2": "Xem tiếp trang %d" % (page + 1),
                "info": {"plot": "Xem tiếp các phim trang %d" % (page + 1)}
            })
            
        loadlistitem.list_item_main({"content_type": "movies", "items": paginated_items})
        return

    if 'action=web_special_menu' in url:
        items = [
            {
                "label": "[COLOR gold][B]Phim Bộ TVB (Web API)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=web_special_year_menu&file=tvb_matches.json",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Tuyển tập phim bộ truyền hình đài TVB Hồng Kông phân loại theo năm"
            },
            {
                "label": "[COLOR gold][B]Phim Bộ ATV (Web API)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=web_special_year_menu&file=atv_matches.json",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Tuyển tập phim bộ truyền hình đài ATV Hồng Kông phân loại theo năm"
            },
            {
                "label": "[COLOR gold][B]Hoạt Hình - Anime (Web API)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=web_special_json_list&file=anime_matches.json&page=1",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "label2": "Tuyển tập hoạt hình Anime lồng tiếng kinh điển"
            },
            {
                "label": "[COLOR gold][B]Kiếm Hiệp Kim Dung (Web API - TVB)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=web_special_json_list&file=kim_dung_matches.json&page=1",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "label2": "Trọn bộ Kiếm Hiệp Kim Dung do đài TVB sản xuất"
            }
        ]
        loadlistitem.list_item_main({"content_type": "", "items": items})
        return

    if 'action=web_special_year_menu' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        json_file = args.get('file', [''])[0]
        
        json_path = os.path.join(addon_path, 'resources', json_file)
        if not os.path.exists(json_path):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
            
        with open(json_path, 'r', encoding='utf-8') as f:
            matched_items = json.load(f)
            
        groups_present = set()
        for item in matched_items:
            year = int(item.get("year", 0))
            if year >= 2020:
                groups_present.add(str(year))
            elif 2010 <= year <= 2019:
                groups_present.add("2010s")
            elif 2000 <= year <= 2009:
                groups_present.add("2000s")
            elif 1990 <= year <= 1999:
                groups_present.add("1990s")
            elif 1980 <= year <= 1989:
                groups_present.add("1980s")
            elif 0 < year < 1980:
                groups_present.add("pre1980")
                
        all_groups = [
            ("2026", "[COLOR gold][B]Năm 2026[/B][/COLOR]", "Phim phát hành năm 2026"),
            ("2025", "[COLOR gold][B]Năm 2025[/B][/COLOR]", "Phim phát hành năm 2025"),
            ("2024", "[COLOR gold][B]Năm 2024[/B][/COLOR]", "Phim phát hành năm 2024"),
            ("2023", "[COLOR gold][B]Năm 2023[/B][/COLOR]", "Phim phát hành năm 2023"),
            ("2022", "[COLOR gold][B]Năm 2022[/B][/COLOR]", "Phim phát hành năm 2022"),
            ("2021", "[COLOR gold][B]Năm 2021[/B][/COLOR]", "Phim phát hành năm 2021"),
            ("2020", "[COLOR gold][B]Năm 2020[/B][/COLOR]", "Phim phát hành năm 2020"),
            ("2010s", "[COLOR orange][B]Thập niên 2010 (2010 - 2019)[/B][/COLOR]", "Phim phát hành từ năm 2010 đến 2019"),
            ("2000s", "[COLOR orange][B]Thập niên 2000 (2000 - 2009)[/B][/COLOR]", "Phim phát hành từ năm 2000 đến 2009"),
            ("1990s", "[COLOR orange][B]Thập niên 1990 (1990 - 1999)[/B][/COLOR]", "Phim phát hành từ năm 1990 đến 1999"),
            ("1980s", "[COLOR orange][B]Thập niên 1980 (1980 - 1989)[/B][/COLOR]", "Phim phát hành từ năm 1980 đến 1989"),
            ("pre1980", "[COLOR orange][B]Trước năm 1980[/B][/COLOR]", "Phim phát hành trước năm 1980")
        ]
        
        list_items = []
        for g_id, g_label, g_desc in all_groups:
            if g_id in groups_present:
                li = xbmcgui.ListItem(label=g_label)
                li.setInfo('video', {
                    'title': g_label,
                    'plot': g_desc
                })
                icon_path = os.path.join(addon_path, 'resources', 'images', 'series.png')
                li.setArt({'thumb': icon_path, 'icon': icon_path, 'poster': icon_path})
                li.setProperty('IsPlayable', 'false')
                u = f"plugin://plugin.video.cloudshare?action=web_special_json_list&file={json_file}&year_group={g_id}&page=1"
                list_items.append((u, li, True))
                
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=web_special_json_list' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        json_file = args.get('file', [''])[0]
        page = int(args.get('page', ['1'])[0])
        year_group = args.get('year_group', [''])[0]
        
        json_path = os.path.join(addon_path, 'resources', json_file)
        if not os.path.exists(json_path):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
            
        with open(json_path, 'r', encoding='utf-8') as f:
            matched_items = json.load(f)
        try:
            matched_items.sort(key=lambda x: (-int(x.get("year", 0)) if str(x.get("year", "")).isdigit() else 0, x.get("name", "").lower()))
        except Exception:
            pass
            
        if year_group:
            filtered_items = []
            for item in matched_items:
                year = int(item.get("year", 0))
                if year_group.isdigit():
                    if year == int(year_group):
                        filtered_items.append(item)
                elif year_group == "2010s":
                    if 2010 <= year <= 2019:
                        filtered_items.append(item)
                elif year_group == "2000s":
                    if 2000 <= year <= 2009:
                        filtered_items.append(item)
                elif year_group == "1990s":
                    if 1990 <= year <= 1999:
                        filtered_items.append(item)
                elif year_group == "1980s":
                    if 1980 <= year <= 1989:
                        filtered_items.append(item)
                elif year_group == "pre1980":
                    if 0 < year < 1980:
                        filtered_items.append(item)
            matched_items = filtered_items
            
        items_per_page = 20
        total_items = len(matched_items)
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        paginated_items = matched_items[start_idx:end_idx]
        
        list_items = []
        
        if page > 1:
            li_prev = xbmcgui.ListItem(label="[COLOR yellow][B]<< Trang Trước[/B][/COLOR]")
            prev_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_prev.setArt({'thumb': prev_icon, 'icon': prev_icon, 'poster': prev_icon})
            li_prev.setInfo('video', {
                'title': "Trang trước",
                'plot': "Quay lại trang trước"
            })
            li_prev.setProperty('IsPlayable', 'false')
            u_prev = f"plugin://plugin.video.cloudshare?action=web_special_json_list&file={json_file}&year_group={year_group}&page={page - 1}"
            list_items.append((u_prev, li_prev, True))
            
        # Fetch details in parallel to get plot, director, actor, duration, genres, countries, ratings, etc. (Always enabled)
        enriched_details = fetch_movie_detail_parallel(paginated_items)
            
        for item in paginated_items:
            slug = item.get("slug")
            name = item.get("name")
            origin_name = item.get("origin_name", "")
            year = str(item.get("year", ""))
            thumb = item.get("thumb", "")
            poster = item.get("poster", "")
            source = item.get("source", "ophim")
            
            detail = enriched_details.get(slug, {}) if slug else {}
            plot = clean_html_plot(detail.get("content", ""))
            actors = detail.get("actor", [])
            directors = detail.get("director", [])
            duration_str = detail.get("time") or item.get("time", "")
            
            # Parse duration to seconds
            duration_seconds = 0
            if duration_str:
                dur_match = re.search(r'(\d+)', duration_str)
                if dur_match:
                    duration_seconds = int(dur_match.group(1)) * 60
            
            # Genres
            categories = detail.get("category", [])
            genre_names = [cat.get("name", "") for cat in categories if isinstance(cat, dict)]
            genre_str = ", ".join(genre_names)
            
            # Countries
            country_str = ""
            countries = detail.get("country", [])
            if countries:
                country_names = [c.get("name", "") for c in countries if isinstance(c, dict)]
                country_str = ", ".join(country_names)
                
            # Rating
            rating = None
            try:
                rating = detail.get("tmdb", {}).get("vote_average")
                if not rating:
                    rating = detail.get("imdb", {}).get("vote_average")
                if rating:
                    rating = float(rating)
            except:
                rating = None
                
            if not year and detail.get("year"):
                year = str(detail.get("year"))
                
            display_name = f"{name} ({year})" if year else name
            
            plot_desc = plot if plot else name
            
            rating_str = ""
            tmdb_vote = detail.get("tmdb", {}).get("vote_average")
            if tmdb_vote and float(tmdb_vote) > 0:
                rating_str += f"TMDb {tmdb_vote}"
            imdb_vote = detail.get("imdb", {}).get("vote_average")
            if imdb_vote and float(imdb_vote) > 0:
                if rating_str:
                    rating_str += " | "
                rating_str += f"IMDb {imdb_vote}"
                
            info = {
                'title': name,
                'originaltitle': origin_name,
                'year': int(year) if (year and year.isdigit()) else 0,
                'mediatype': 'movie' if source != 'fshare' else 'tvshow',
                'genre': genre_str,
                'plot': plot_desc,
                'rating_str': rating_str
            }
            if rating and rating > 0:
                info['rating'] = rating
            if duration_seconds > 0:
                info['duration'] = duration_seconds
            if directors:
                info['director'] = ", ".join(directors)
            if actors:
                info['cast'] = actors
            if country_str:
                info['country'] = country_str
                
            li = xbmcgui.ListItem(label=display_name)
            li.setInfo('video', loadlistitem.format_info(info))
            img_cdn = 'https://phim.nguonc.com/' if source == 'nguonc' else 'https://phimimg.com/'
            thumb_resolved = get_image_url(thumb, img_cdn, width=300)
            poster_resolved = get_image_url(poster, img_cdn, width=300)
            li.setArt({'thumb': thumb_resolved, 'icon': thumb_resolved, 'poster': poster_resolved, 'fanart': thumb_resolved})
            if source == "fshare":
                u = item.get("path", "")
                is_folder = True
                if "file" in u.lower() and "folder" not in u.lower():
                    is_folder = False
                    li.setProperty('IsPlayable', 'true')
                else:
                    li.setProperty('IsPlayable', 'false')
            else:
                li.setProperty('IsPlayable', 'false')
                u = f"plugin://plugin.video.cloudshare?action=ophim_episodes&title={urllib_parse.quote(name)}&slug={slug}&source={source}"
                is_folder = True
                
            list_items.append((u, li, is_folder))
            
        if end_idx < total_items:
            li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Trang Tiếp Theo >>[/B][/COLOR]")
            next_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li_next.setArt({'thumb': next_icon, 'icon': next_icon, 'poster': next_icon})
            li_next.setInfo('video', {
                'title': "Trang tiếp theo",
                'plot': "Đi tới trang tiếp theo"
            })
            li_next.setProperty('IsPlayable', 'false')
            u_next = f"plugin://plugin.video.cloudshare?action=web_special_json_list&file={json_file}&year_group={year_group}&page={page + 1}"
            list_items.append((u_next, li_next, True))
            
        xbmcplugin.setContent(HANDLE, 'movies')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=web_source_menu' in url:
        items = [
            {
                "label": "[COLOR gold][B]Phim Mới Cập Nhật[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=ophim_danh_sach&url=phim-moi-cap-nhat",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "label2": "Phim mới cập nhật liên tục"
            },
            {
                "label": "[COLOR orange][B]Bộ Sưu Tập Phim Web (API)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=web_special_menu",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'hot_movies_.png'),
                "label2": "Các bộ sưu tập phim TVB, ATV, Anime, Kim Dung nguồn Web"
            },
            {
                "label": "[COLOR gold][B]Phim Chiếu Rạp[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=ophim_danh_sach&url=phim-chieu-rap",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'movies.png'),
                "label2": "Phim chiếu rạp mới nhất"
            },
            {
                "label": "[COLOR gold][B]Phim Lẻ (Theo Thể Loại)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=ophim_genres_le",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png'),
                "label2": "Phim lẻ chia theo thể loại"
            },
            {
                "label": "[COLOR gold][B]Phim Bộ (Theo Quốc Gia)[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=ophim_countries_bo",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'series.png'),
                "label2": "Phim bộ chia theo quốc gia"
            },
            {
                "label": "[COLOR gold][B]Tìm Kiếm Phim Web[/B][/COLOR]",
                "is_playable": False,
                "path": "plugin://plugin.video.cloudshare?action=ophim_search",
                "thumbnail": os.path.join(ADDON_PATH, 'resources', 'images', 'search.png'),
                "icon": os.path.join(ADDON_PATH, 'resources', 'images', 'search.png'),
                "label2": "Tìm kiếm phim nguồn web"
            }
        ]
        loadlistitem.list_item_main({"content_type": "", "items": items})
        return

    if 'action=ophim_genres_le' in url:
        from resources import ophim_api
        genres = ophim_api.get_genres()
        if not genres:
            genres = [
                ("Hành Động", "hanh-dong"),
                ("Tình Cảm", "tinh-cam"),
                ("Hài Hước", "hai-huoc"),
                ("Cổ Trang", "co-trang"),
                ("Tâm Lý", "tam-ly"),
                ("Hình Sự", "hinh-su"),
                ("Chiến Tranh", "chien-tranh"),
                ("Thể Thao", "the-thao"),
                ("Võ Thuật", "vo-thuat"),
                ("Viễn Tưởng", "vien-tuong"),
                ("Phiêu Lưu", "phieu-luu"),
                ("Khoa Học", "khoa-hoc"),
                ("Kinh Dị", "kinh-di"),
                ("Âm Nhạc", "am-nhac"),
                ("Thần Thoại", "than-thoai"),
                ("Tài Liệu", "tai-lieu"),
                ("Gia Đình", "gia-dinh"),
                ("Chính Kịch", "chinh-kich"),
                ("Bí Ẩn", "bi-an"),
                ("Học Đường", "hoc-duong"),
                ("Kinh Điển", "kinh-dien"),
                ("Phim Ngắn", "phim-ngan"),
                ("Anime", "hoat-hinh")
            ]
        else:
            # Ensure "Phim Ngắn" and "Anime" are always present in the genre list
            existing_slugs = [g[1] for g in genres]
            if "phim-ngan" not in existing_slugs:
                genres.append(("Phim Ngắn", "phim-ngan"))
            if "hoat-hinh" not in existing_slugs:
                genres.append(("Anime", "hoat-hinh"))
        list_items = []
        genre_icons = {
            "Hành Động": "_action.png",
            "Tình Cảm": "romance_.png",
            "Hài Hước": "comedy.png",
            "Cổ Trang": "history_.png",
            "Tâm Lý": "drama_.png",
            "Hình Sự": "crime_.png",
            "Chiến Tranh": "war__politics.png",
            "Thể Thao": "_action.png",
            "Võ Thuật": "_action.png",
            "Viễn Tưởng": "sci_fi_.png",
            "Phiêu Lưu": "_adventure_.png",
            "Khoa Học": "documentary_.png",
            "Kinh Dị": "horror_.png",
            "Âm Nhạc": "musical_.png",
            "Thần Thoại": "fantasy_.png",
            "Tài Liệu": "documentary_.png",
            "Gia Đình": "family_.png",
            "Chính Kịch": "drama_.png",
            "Bí Ẩn": "mystery_.png",
            "Học Đường": "comedy.png",
            "Kinh Điển": "history_.png",
            "Phim Ngắn": "reality_tv_.png",
            "Anime": "animation_.png"
        }
        for name, slug in genres:
            li = xbmcgui.ListItem(label=name)
            icon_file = genre_icons.get(name, "genres.png")
            icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'genres', icon_file)
            if not os.path.exists(icon_path):
                icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'genres.png')
            li.setArt({'thumb': icon_path, 'icon': icon_path, 'poster': icon_path})
            
            if slug == "hoat-hinh":
                target_url = "v1/api/danh-sach/hoat-hinh?sort_field=year&sort_type=desc"
                u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={target_url}&type=hoat-hinh"
            elif slug == "phim-ngan":
                target_url = "v1/api/the-loai/phim-ngan?sort_field=year&sort_type=desc"
                u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={target_url}&type=phim-ngan"
            elif "category=" in slug:
                target_url = slug
                u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={target_url}&type=phim-le"
            else:
                target_url = f"v1/api/danh-sach/phim-le?category={slug}&sort_field=year&sort_type=desc"
                u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={target_url}&type=phim-le"
            list_items.append((u, li, True))
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=ophim_countries_bo' in url:
        from resources import ophim_api
        countries = ophim_api.get_countries()
        if not countries:
            countries = [
                ("Trung Quốc", "trung-quoc"),
                ("Hàn Quốc", "han-quoc"),
                ("Âu Mỹ", "au-my"),
                ("Nhật Bản", "nhat-ban"),
                ("Hồng Kông", "hong-kong"),
                ("Đài Loan", "dai-loan"),
                ("Thái Lan", "thai-lan"),
                ("Ấn Độ", "an-do"),
                ("Việt Nam", "viet-nam")
            ]
        list_items = []
        for name, slug in countries:
            li = xbmcgui.ListItem(label=name)
            icon_path = os.path.join(ADDON_PATH, 'resources', 'images', 'series.png')
            li.setArt({'thumb': icon_path, 'icon': icon_path, 'poster': icon_path})
            
            if "country=" in slug:
                target_url = slug
            else:
                target_url = f"v1/api/danh-sach/phim-bo?country={slug}&sort_field=year&sort_type=desc"
                
            u = f"plugin://plugin.video.cloudshare?action=ophim_danh_sach&url={target_url}&type=phim-bo"
            list_items.append((u, li, True))
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=ophim_search' in url:
        keyboard = xbmc.Keyboard("", "Nhập tên phim cần tìm")
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            query = keyboard.getText()
            import urlquick
            import concurrent.futures
            
            # Fetch Ophim and NguonC search results in parallel!
            ophim_items = []
            nguonc_items = []
            
            def fetch_ophim():
                from resources import ophim_api
                items, cdn = ophim_api.search_movies(query, page=1)
                for item in items:
                    item["source"] = "ophim"
                return items, cdn
                
            def fetch_nguonc():
                api_url = f"https://phim.nguonc.com/api/films/search?keyword={urllib_parse.quote(query)}"
                try:
                    try:
                        response = urlquick.get(api_url, max_age=300, timeout=15)
                    except Exception as e:
                        xbmc.log(f"[CloudShare] NguonC API search first try failed: {e}. Retrying...", xbmc.LOGWARN)
                        response = urlquick.get(api_url, max_age=300, timeout=25)
                    if response.status_code == 200:
                        data = response.json()
                        items = data.get("items", [])
                        mapped = []
                        for it in items:
                            mapped.append({
                                "name": f"[COLOR cyan][NguồnC][/COLOR] {it.get('name', '')}",
                                "origin_name": it.get("original_name", ""),
                                "slug": it.get("slug", ""),
                                "poster_url": it.get("poster_url", ""),
                                "thumb_url": it.get("thumb_url", ""),
                                "episode_current": it.get("current_episode", ""),
                                "description": it.get("description", ""),
                                "source": "nguonc",
                                "type": "series" if "Tập" in it.get("current_episode", "") or it.get("total_episodes", 1) > 1 else "single"
                            })
                        return mapped
                except Exception as e:
                    xbmc.log(f"[CloudShare] NguonC Search Error: {e}", xbmc.LOGERROR)
                return []
                
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
                f_ophim = executor.submit(fetch_ophim)
                f_nguonc = executor.submit(fetch_nguonc)
                
                try:
                    oph_res, cdn = f_ophim.result()
                    ophim_items = oph_res
                except Exception as e:
                    xbmc.log(f"[CloudShare] Ophim Search Thread Error: {e}", xbmc.LOGERROR)
                    cdn = "https://phimimg.com/"
                    
                try:
                    nguonc_items = f_nguonc.result()
                except Exception as e:
                    xbmc.log(f"[CloudShare] NguonC Search Thread Error: {e}", xbmc.LOGERROR)
            
            # Tag Ophim items with a label prefix too to distinguish them
            for item in ophim_items:
                item["name"] = f"[COLOR gold][Ophim][/COLOR] {item.get('name', '')}"
                
            # Merge results: show NguonC first then Ophim
            merged_items = nguonc_items + ophim_items
            
            build_ophim_menu(merged_items, cdn, f"v1/api/tim-kiem?keyword={urllib_parse.quote(query)}", 1)
        else:
            notify("Đã hủy tìm kiếm")
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'action=ophim_danh_sach' in url:
        from resources import ophim_api
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        clean_endpoint = args.get('url', [''])[0]
        if clean_endpoint:
            page = int(args.get('page', [1])[0])
            type_filter = args.get('type', [None])[0]
            
            # Override type_filter for hoat-hinh and phim-ngan endpoints to prevent empty lists due to strict filter match
            if "hoat-hinh" in clean_endpoint or "hoathinh" in clean_endpoint or "phim-ngan" in clean_endpoint:
                type_filter = None
            
            is_sorted_endpoint = True
            if "tim-kiem" in clean_endpoint:
                is_sorted_endpoint = False
                
            # Dynamically force sorting parameters on clean_endpoint if it is a category/genre list
            if is_sorted_endpoint and "sort_field=" not in clean_endpoint:
                sep = "&" if "?" in clean_endpoint else "?"
                clean_endpoint += f"{sep}sort_field=year&sort_type=desc"
                
            # Fetch API pages in parallel (10 pages for categories, 3 pages for search/updates)
            import encodings.idna
            import concurrent.futures
            
            batch_size = 3
            start_api_page = (page - 1) * batch_size + 1
            api_pages = list(range(start_api_page, start_api_page + batch_size))
            
            all_items = []
            cdn = "https://phimimg.com/"
            
            def fetch_api_page(p):
                return ophim_api.get_movies_list(endpoint=clean_endpoint, page=p)
                
            with concurrent.futures.ThreadPoolExecutor(max_workers=batch_size) as executor:
                results = list(executor.map(fetch_api_page, api_pages))
                for items_list, cdn_url in results:
                    if items_list:
                        all_items.extend(items_list)
                    if cdn_url:
                        cdn = cdn_url
                        
            # Filter and sort
            filtered_items = []
            seen_ids = set()
            for item in all_items:
                item_id = item.get("_id")
                if not item_id or item_id in seen_ids:
                    continue
                    
                # 1. Filter by type (movie or series)
                if type_filter:
                    item_type = item.get('type')
                    if type_filter == 'phim-le':
                        if item_type not in ['single', 'hoathinh_le', 'movies']:
                            continue
                    elif type_filter == 'phim-bo':
                        if item_type not in ['series', 'tvshows', 'hoathinh_bo']:
                            continue
                    elif type_filter == 'hoat-hinh':
                        if item_type not in ['hoathinh', 'hoathinh_le', 'hoathinh_bo', 'single', 'series']:
                            continue
                    elif type_filter == 'phim-ngan':
                        pass
                            
                # 2. Filter out trailers (check title, origin_name, and episode_current)
                name = item.get("name", "")
                origin_name = item.get("origin_name", "")
                episode_current = item.get("episode_current", "")
                
                name_lower = name.lower()
                origin_name_lower = origin_name.lower()
                episode_current_lower = episode_current.lower()
                
                if "trailer" in episode_current_lower or "trailer" in name_lower or "trailer" in origin_name_lower:
                    continue
                    
                seen_ids.add(item_id)
                filtered_items.append(item)
                
            # 3. Group episodes if enabled in settings
            if ADDON.getSetting('ophim_group_episodes') != 'false':
                grouped_dict = {}
                for item in filtered_items:
                    name = item.get("name", "")
                    base_name, ep_info = extract_base_name(name)
                    norm_base = base_name.lower()
                    if norm_base not in grouped_dict:
                        grouped_dict[norm_base] = {
                            "base_name": base_name,
                            "items": [],
                            "year": item.get("year", 0)
                        }
                    grouped_dict[norm_base]["items"].append(item)
                    try:
                        y = int(item.get("year", 0))
                        if y > int(grouped_dict[norm_base]["year"]):
                            grouped_dict[norm_base]["year"] = y
                    except:
                        pass
                
                final_items = []
                for norm_base, group in grouped_dict.items():
                    items_in_group = group["items"]
                    if len(items_in_group) == 1:
                        final_items.append(items_in_group[0])
                    else:
                        first_item = items_in_group[0]
                        slugs = [it.get("slug", "") for it in items_in_group if it.get("slug")]
                        slugs_str = ",".join(slugs)
                        
                        virtual_item = {
                            "_id": "group_" + norm_base,
                            "name": group["base_name"],
                            "origin_name": first_item.get("origin_name", ""),
                            "slug": f"group_slugs_{slugs_str}",
                            "year": group["year"],
                            "thumb_url": first_item.get("thumb_url"),
                            "poster_url": first_item.get("poster_url"),
                            "type": "grouped_series",
                            "episode_current": f"Gồm {len(items_in_group)} tập",
                            "category": first_item.get("category", []),
                            "is_grouped_folder": True,
                            "group_title": group["base_name"],
                            "group_slugs": slugs_str
                        }
                        final_items.append(virtual_item)
                
                filtered_items = final_items

            # 4. Sort by year descending (only for genres, countries, or lists, NOT for search or new updates)
            if is_sorted_endpoint:
                def get_sort_year(item):
                    try:
                        y = item.get("year", 0)
                        return int(y) if y else 0
                    except:
                        return 0
                filtered_items.sort(key=get_sort_year, reverse=True)
            
            build_ophim_menu(filtered_items, cdn, clean_endpoint, page, type_filter)
        return
        
    if 'action=ophim_show_group' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        title = args.get('title', [''])[0]
        slugs_str = args.get('slugs', [''])[0]
        slugs = slugs_str.split(',') if slugs_str else []
        
        from resources import ophim_api
        import concurrent.futures
        
        items = []
        
        def fetch_one(slug):
            movie, _ = ophim_api.get_movie_detail(slug)
            if movie:
                return {
                    "_id": movie.get("_id"),
                    "name": movie.get("name"),
                    "origin_name": movie.get("origin_name"),
                    "slug": movie.get("slug"),
                    "year": movie.get("year"),
                    "thumb_url": movie.get("thumb_url"),
                    "poster_url": movie.get("poster_url"),
                    "type": movie.get("type", "single"),
                    "episode_current": movie.get("episode_current", "Full"),
                    "category": movie.get("category", [])
                }
            return None
            
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(max(len(slugs), 1), 10)) as executor:
            results = executor.map(fetch_one, slugs)
            for res in results:
                if res:
                    items.append(res)
                    
        # Sort items by episode number so they are in correct order!
        def get_ep_number(item):
            name = item.get("name", "")
            match = re.search(r'(?:Tập|Tap|Ep|Episode|Phần|Phan|P\.?)\s*(\d+)', name, re.IGNORECASE)
            if match:
                return int(match.group(1))
            return 999999
            
        items.sort(key=get_ep_number)
        
        build_ophim_menu(items, "https://phimimg.com/", f"v1/api/group", 1)
        return
        
    if 'action=ophim_episodes' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        title = args.get('title', [''])[0]
        slug = args.get('slug', [''])[0]
        source = args.get('source', ['ophim'])[0]
        
        if source == 'nguonc':
            import urlquick
            api_url = f"https://phim.nguonc.com/api/film/{slug}"
            try:
                try:
                    response = urlquick.get(api_url, max_age=43200, timeout=15)
                except Exception as e:
                    xbmc.log(f"[CloudShare] NguonC API detail first try failed: {e}. Retrying...", xbmc.LOGWARN)
                    response = urlquick.get(api_url, max_age=43200, timeout=25)
                if response.status_code == 200:
                    data = response.json()
                    raw_movie = data.get("movie", {})
                    
                    year = ""
                    category_dict = raw_movie.get("category", {})
                    for cat_id, cat_info in category_dict.items():
                        group_name = cat_info.get("group", {}).get("name", "")
                        if group_name == "Năm":
                            cat_list = cat_info.get("list", [])
                            if cat_list:
                                year = str(cat_list[0].get("name", ""))
                                break
                    
                    movie = {
                        "name": raw_movie.get("name", ""),
                        "origin_name": raw_movie.get("original_name", ""),
                        "year": year,
                        "content": raw_movie.get("description", ""),
                        "thumb_url": raw_movie.get("thumb_url", ""),
                        "poster_url": raw_movie.get("poster_url", "")
                    }
                    
                    raw_episodes = raw_movie.get("episodes", [])
                    episodes = []
                    for srv in raw_episodes:
                        server_name = srv.get("server_name", "Default")
                        server_data = []
                        for item in srv.get("items", []):
                            server_data.append({
                                "name": item.get("name", "1"),
                                "link_m3u8": item.get("m3u8", ""),
                                "embed": item.get("embed", "")
                            })
                        episodes.append({
                            "server_name": server_name,
                            "server_data": server_data
                        })
                else:
                    movie, episodes = {}, []
            except Exception as e:
                xbmc.log(f"[CloudShare] NguonC API Error (get_movie_detail): {e}", xbmc.LOGERROR)
                movie, episodes = {}, []
        else:
            from resources import ophim_api
            movie, episodes = ophim_api.get_movie_detail(slug)
            
        year = str(movie.get("year", ""))
        plot = clean_html_plot(movie.get('content', ''))
        if year:
            plot = f"[COLOR gold][B]NĂM PHÁT HÀNH: {year}[/B][/COLOR]\n\n{plot}"
        thumb = movie.get('thumb_url', '')
        poster = movie.get('poster_url', '')
        
        img_cdn = 'https://phim.nguonc.com/' if source == 'nguonc' else 'https://phimimg.com/'
        thumb_resolved = get_image_url(thumb, img_cdn, width=300)
        poster_resolved = get_image_url(poster, img_cdn, width=300)
        fanart_resolved = get_image_url(thumb, img_cdn, width=1000)
        
        list_items = []
        if episodes:
            for ep in episodes:
                server_name = ep.get("server_name", "").replace("#", "")
                server_data = ep.get("server_data", [])
                for sd in server_data:
                    ep_name = sd.get("name", "1")
                    ep_link = sd.get("link_m3u8", "")
                    ep_embed = sd.get("embed", "")
                    
                    label = f"Tập {ep_name} - {server_name}" if server_name else f"Tập {ep_name}"
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo('video', {
                        'title': f"{title} - {label}", 
                        'mediatype': 'episode',
                        'plot': plot
                    })
                    li.setArt({
                        'thumb': thumb_resolved,
                        'icon': poster_resolved,
                        'poster': poster_resolved,
                        'fanart': fanart_resolved
                    })
                    li.setProperty('IsPlayable', 'true')
                    
                    play_url = f"plugin://plugin.video.cloudshare?action=play_direct&url={urllib_parse.quote(ep_link)}&title={urllib_parse.quote(title)}&embed={urllib_parse.quote(ep_embed)}"
                    list_items.append((play_url, li, False))
            
        xbmcplugin.setContent(HANDLE, 'episodes')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if 'action=play_direct' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        link = args.get('url', [''])[0]
        title = args.get('title', [''])[0]
        embed = args.get('embed', [''])[0]
        if link or embed:
            import urllib.request
            import urllib.error
            import ssl

            def resolve_nguonc_embed_stream(embed_url):
                import base64
                import re
                import json
                ctx = ssl._create_unverified_context()
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
                try:
                    req = urllib.request.Request(embed_url, headers=headers)
                    with urllib.request.urlopen(req, context=ctx, timeout=4.0) as resp:
                        html = resp.read().decode('utf-8')
                    match = re.search(r"data-obf=['\"](.*?)['\"]", html)
                    if not match:
                        return None, None, None
                    obf = match.group(1)
                    decoded = base64.b64decode(obf).decode('utf-8')
                    stream_data = json.loads(decoded)
                    parsed_url = urllib_parse.urlparse(embed_url)
                    domain = parsed_url.netloc
                    m3u8_url = f"https://{domain}/{stream_data['sUb']}.m3u8"
                    kX = stream_data.get('kX', '')
                    return m3u8_url, kX, domain
                except Exception as e:
                    xbmc.log(f"[CloudShare] resolve_nguonc_embed_stream error: {e}", xbmc.LOGERROR)
                    return None, None, None

            def decrypt_nguonc_m3u8(m3u8_url, kX, embed_url, domain):
                import base64
                import binascii
                import os
                import xbmcvfs
                from array import array

                aes_sbox = array('B',
                    binascii.unhexlify('637c777bf26b6fc53001672bfed7ab76'
                    'ca82c97dfa5947f0add4a2af9ca472c0'
                    'b7fd9326363ff7cc34a5e5f171d83115'
                    '04c723c31896059a071280e2eb27b275'
                    '09832c1a1b6e5aa0523bd6b329e32f84'
                    '53d100ed20fcb15b6acbbe394a4c58cf'
                    'd0efaafb434d338545f9027f503c9fa8'
                    '51a3408f929d38f5bcb6da2110fff3d2'
                    'cd0c13ec5f974417c4a77e3d645d1973'
                    '60814fdc222a908846eeb814de5e0bdb'
                    'e0323a0a4906245cc2d3ac629195e479'
                    'e7c8376d8dd54ea96c56f4ea657aae08'
                    'ba78252e1ca6b4c6e8dd741f4bbd8b8a'
                    '703eb5664803f60e613557b986c11d9e'
                    'e1f8981169d98e949b1e87e9ce5528df'
                    '8ca1890dbfe6426841992d0fb054bb16')
                )

                aes_Rcon = array('B',
                    binascii.unhexlify('8d01020408102040801b366cd8ab4d9a'
                    '2f5ebc63c697356ad4b37dfaefc59139'
                    '72e4d3bd61c29f254a943366cc831d3a'
                    '74e8cb8d01020408102040801b366cd8'
                    'ab4d9a2f5ebc63c697356ad4b37dfaef'
                    'c5913972e4d3bd61c29f254a943366cc'
                    '831d3a74e8cb8d01020408102040801b'
                    '366cd8ab4d9a2f5ebc63c697356ad4b3'
                    '7dfaefc5913972e4d3bd61c29f254a94'
                    '3366cc831d3a74e8cb8d010204081020'
                    '40801b366cd8ab4d9a2f5ebc63c69735'
                    '6ad4b37dfaefc5913972e4d3bd61c29f'
                    '254a943366cc831d3a74e8cb8d010204'
                    '08102040801b366cd8ab4d9a2f5ebc63'
                    'c697356ad4b37dfaefc5913972e4d3bd'
                    '61c29f254a943366cc831d3a74e8cb')
                )

                def xtime(a):
                    return ((a << 1) ^ 0x1B) & 0xFF if (a & 0x80) else (a << 1) & 0xFF

                def mul_2(a):
                    return xtime(a)

                def mul_3(a):
                    return xtime(a) ^ a

                class AES256Encrypt:
                    def __init__(self, key):
                        self.key = key
                        self.key_size = len(key)
                        self.rounds = 14
                        self.expand_key()

                    def expand_key(self):
                        exkey = bytearray(self.key)  # 32 bytes
                        rcon_index = 1
                        while len(exkey) < 240:
                            temp = bytearray(exkey[-4:])
                            if len(exkey) % 32 == 0:
                                temp = temp[1:4] + temp[0:1]
                                for j in range(4):
                                    temp[j] = aes_sbox[temp[j]]
                                temp[0] ^= aes_Rcon[rcon_index]
                                rcon_index += 1
                            elif len(exkey) % 32 == 16:
                                for j in range(4):
                                    temp[j] = aes_sbox[temp[j]]
                            for j in range(4):
                                temp[j] ^= exkey[-32 + j]
                            exkey.extend(temp)
                        self.exkey = array('B', exkey)

                    def encrypt_block(self, block):
                        self.add_round_key(block, 0)
                        for r in range(1, 14):
                            self.sub_bytes(block)
                            self.shift_rows(block)
                            self.mix_columns(block)
                            self.add_round_key(block, r)
                        self.sub_bytes(block)
                        self.shift_rows(block)
                        self.add_round_key(block, 14)

                    def add_round_key(self, block, round_num):
                        offset = round_num * 16
                        for i in range(16):
                            block[i] ^= self.exkey[offset + i]

                    def sub_bytes(self, block):
                        for i in range(16):
                            block[i] = aes_sbox[block[i]]

                    def shift_rows(self, b):
                        b[1], b[5], b[9], b[13] = b[5], b[9], b[13], b[1]
                        b[2], b[6], b[10], b[14] = b[10], b[14], b[2], b[6]
                        b[3], b[7], b[11], b[15] = b[15], b[3], b[7], b[11]

                    def mix_columns(self, block):
                        for i in range(4):
                            col = i * 4
                            v0, v1, v2, v3 = block[col], block[col + 1], block[col + 2], block[col + 3]
                            block[col]     = mul_2(v0) ^ mul_3(v1) ^ v2 ^ v3
                            block[col + 1] = v0 ^ mul_2(v1) ^ mul_3(v2) ^ v3
                            block[col + 2] = v0 ^ v1 ^ mul_2(v2) ^ mul_3(v3)
                            block[col + 3] = mul_3(v0) ^ v1 ^ v2 ^ mul_2(v3)

                try:
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Referer': embed_url,
                        'Origin': f"https://{domain}"
                    }
                    ctx = ssl._create_unverified_context()
                    req = urllib.request.Request(m3u8_url, headers=headers)
                    with urllib.request.urlopen(req, context=ctx, timeout=6.0) as resp:
                        m3u8_data = resp.read().decode('utf-8')
                    
                    lines = m3u8_data.splitlines()
                    iv_hex = None
                    ciphertext_b64 = None
                    for line in lines:
                        line = line.strip()
                        if line.startswith("#ENC-AESGCM;iv="):
                            iv_hex = line.split("=")[1]
                        elif line and not line.startswith("#"):
                            ciphertext_b64 = line

                    if not iv_hex or not ciphertext_b64:
                        xbmc.log("[CloudShare] NguonC Decrypt error: missing iv or ciphertext", xbmc.LOGERROR)
                        return None

                    key_bytes = kX.encode('utf-8')
                    iv_bytes = binascii.unhexlify(iv_hex)
                    ciphertext_all_bytes = base64.b64decode(ciphertext_b64)
                    ciphertext_bytes = ciphertext_all_bytes[:-16]

                    aes = AES256Encrypt(key_bytes)
                    counter_base = bytearray(iv_bytes)
                    counter_num = 2
                    plaintext = bytearray()
                    for offset in range(0, len(ciphertext_bytes), 16):
                        block = ciphertext_bytes[offset:offset+16]
                        if not block:
                            break
                        counter_block = bytearray(counter_base)
                        counter_block.extend(counter_num.to_bytes(4, byteorder='big'))
                        keystream_block = array('B', counter_block)
                        aes.encrypt_block(keystream_block)
                        for i in range(len(block)):
                            plaintext.append(block[i] ^ keystream_block[i])
                        counter_num += 1

                    decrypted_text = plaintext.decode('utf-8')
                    port = 8899
                    try:
                        xbmc_temp = xbmcvfs.translatePath('special://temp')
                        port_file = os.path.join(xbmc_temp, 'cloudshare_port.txt')
                        if os.path.exists(port_file):
                            with open(port_file, 'r') as f_port:
                                port = int(f_port.read().strip())
                    except Exception:
                        pass

                    dec_lines = decrypted_text.splitlines()
                    new_lines = []
                    for dl in dec_lines:
                        dl_stripped = dl.strip()
                        if dl_stripped.startswith('http'):
                            proxied_url = f"http://127.0.0.1:{port}/segment?url={urllib_parse.quote(dl_stripped)}&referer={urllib_parse.quote('https://' + domain + '/')}"
                            new_lines.append(proxied_url)
                        else:
                            new_lines.append(dl)

                    xbmc_temp = xbmcvfs.translatePath('special://temp')
                    temp_file = os.path.join(xbmc_temp, 'cloudshare_temp.m3u8')
                    with open(temp_file, 'w', encoding='utf-8') as f_out:
                        f_out.write('\n'.join(new_lines))
                    return temp_file
                except Exception as ex:
                    xbmc.log(f"[CloudShare] NguonC Decrypt exception: {ex}", xbmc.LOGERROR)
                    return None

            resolved_link = None
            kX = None
            embed_domain = None
            if embed:
                m3u8_url, kX, embed_domain = resolve_nguonc_embed_stream(embed)
                if m3u8_url:
                    if kX:
                        resolved_link = decrypt_nguonc_m3u8(m3u8_url, kX, embed, embed_domain)
                    else:
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                        }
                        resolved_link = f"{m3u8_url}|User-Agent={urllib_parse.quote(headers['User-Agent'])}&Referer={urllib_parse.quote(embed)}&Origin=https://{urllib_parse.quote(embed_domain)}"

            check_link = resolved_link if resolved_link else link

            is_alive = True
            try:
                clean_url = check_link.split('|')[0]
                if clean_url.startswith('http'):
                    req = urllib.request.Request(clean_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}, method='GET')
                    if resolved_link and embed and not kX:
                        parsed_embed = urllib_parse.urlparse(embed)
                        req.add_header('Referer', embed)
                        req.add_header('Origin', f"https://{parsed_embed.netloc}")
                    ctx = ssl._create_unverified_context()
                    with urllib.request.urlopen(req, context=ctx, timeout=3.0) as resp:
                        pass
                else:
                    if not os.path.exists(clean_url):
                        is_alive = False
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    is_alive = False
            except Exception as e:
                xbmc.log(f"[CloudShare] play_direct live check failed: {e}", xbmc.LOGERROR)
                is_alive = False

            if not is_alive:
                dialog = xbmcgui.Dialog()
                msg = "Tập phim này trên máy chủ Web bị lỗi (404).\nBạn có muốn tìm kiếm phim bộ này trên Fshare không?"
                if dialog.yesno("Lỗi phát", msg):
                    search_content('fshare', query=title)
                else:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return

            play_link = check_link
            if not play_link.startswith('http') and 'cloudshare_temp.m3u8' in play_link:
                port = 8899
                try:
                    import xbmcvfs
                    xbmc_temp = xbmcvfs.translatePath('special://temp')
                    port_file = os.path.join(xbmc_temp, 'cloudshare_port.txt')
                    if os.path.exists(port_file):
                        with open(port_file, 'r') as f_port:
                            port = int(f_port.read().strip())
                except Exception as e:
                    xbmc.log(f"[CloudShare] Error reading port file: {e}", xbmc.LOGERROR)
                play_link = f"http://127.0.0.1:{port}/cloudshare_temp.m3u8"

            if play_link.startswith('http'):
                if "|" not in play_link:
                    play_link += "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            li = xbmcgui.ListItem(path=play_link)
            li.setPath(play_link)
            li.setMimeType('application/vnd.apple.mpegurl')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            xbmcgui.Dialog().notification("Lỗi", "Không tìm thấy luồng video", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if 'action=smart_play' in url:
        args = urllib_parse.parse_qs(url.split('?', 1)[1])
        title = args.get('title', [''])[0]
        slug = args.get('slug', [''])[0]
        from resources import smart_resolver
        m3u8_link, source = smart_resolver.resolve_api_link(title, slug)
        if m3u8_link:
            if m3u8_link == "fshare_search":
                search_content('fshare', query=title)
                return
            play_link = m3u8_link
            li = xbmcgui.ListItem(path=play_link)
            if source == "ophim":
                if "|" not in play_link:
                    play_link += "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                li.setPath(play_link)
                li.setMimeType('application/vnd.apple.mpegurl')
            else: # source == "fshare"
                li.setMimeType('video/mp4')
                li.setContentLookup(False)
                li.setInfo('video', {
                    'title': title,
                    'mediatype': 'video'
                })
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if '_debug_' in url:
        xbmc.executebuiltin('RunAddon("script.kodi.loguploader")')
        return
    if 'tkFshare' in url:
        ADDON.openSettings()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if '__download__' in url:
        downloadfile(url)
        return
    if '__showdownload__' in url:
        showDownload()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if "_showtkfs_" in url:
        password = ADDON.getSetting("fshare_password")
        if len(password) > 0:
            alert("Mật khẩu của bạn là: [COLOR yellow]%s[/COLOR]" % password)
        else:
            alert("Sau khi nhập thông tin phải nhấn OK để lưu giữ")
        return
    if '__speedtest__' in url:
        speedfs.sppedfs()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if '_resetsetting_' in url:
        if delete_settings_file():
            alert("Đã xoá file setting.xml thành công.")
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'select_source_phimle' in url:
        select_source('phimle_url')
    if 'select_source_phimbo' in url:
        select_source('phimbo_url')

    if '_dellink_' in url:
        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):notify('Bạn chưa có link nào được lưu.')
        else:
            with open(filename, "w") as f:
                lines = f.write('')
                notify('Done')
        return
    if '_number_' in url:

        data = PlayCode()
        loadlistitem.list_item_main(data)
        return
    if '_number1_' in url:

        shorten_host = ADDON.getSetting('shorten_host')
        if not shorten_host:
            alert("Vui lòng thiết lập dịch vụ làm ngắn link trong Addon Setting")
            ADDON.openSettings()
            return

        data = input_code_and_process(shorten_host)
        loadlistitem.list_item_main(data)
        return
    if "__forbiddenZone__" in url:
        lock_icon = xbmcvfs.translatePath(os.path.join(ADDON_PATH, 'resources', 'images', 'lock.png'))
        lock_dir = os.path.join(PROFILE_PATH, 'lock_dir.dat')
        if not os.path.exists(lock_dir):
            notify("Chưa có gì bí mật để giấu")

        items = []
        with open(lock_dir, "r") as f:
            lines = f.readlines()
            t = (len(lines))

            for line in lines:
                item={}

                if "/folder/" in line or "/d/" in line or "browse" in line or "docs.google.com" in line or "episodes" in line:
                    playable = False
                    line = line.replace("url=plugin://plugin.video.cloudshare?action=play&","")

                else: playable = True
                if "thread_id" in line or "node_id" in line:
                    regex = r"(\?action.*)"
                else:
                    regex = r"url=(https?://\S+)"
                match = re.search(regex,link)
                if match:
                    link = match.group(1)
                    link = "?url="+link
                link = link.replace("\n","")
                name = "[COLOR yellow][I]Mục bị khoá[/I][/COLOR]"

                size = ""
                item["label"] = name
                item["is_playable"] = playable

                item["path"] = 'plugin://plugin.video.cloudshare%s' % link
                item["icon"] = "https://i.imgur.com/pHbuVqt.png"
                item["info"] = {'plot': 'Mục lưu trữ cần mật khẩu mở khoá'}
                item["label2"] = ""
                item["thumbnail"] = lock_icon
                item["art"] = {
                    "fanart":lock_icon,
                    "icon"  :lock_icon,
                    "poster":lock_icon,
                    "thumb":lock_icon
                    }
                items += [item]
        data = {"content_type": "episodes", "items": ""}
        data.update({"items": items})
        loadlistitem.list_item_main(data)
        return
    if "__backup__" in url:
        backup()
        exit()
    if "__restore__" in url:
        restore()
        return
    if 'textbox' in url or 'Textbox' in url:
        import requests
        url = url.replace(CLOUDSHARE_HOST + '/?action=textbox&', '')
        url = urllib_parse.unquote_plus(url)
        content = requests.get(url).text
        TextBoxes(ADDON_NAME, content)
        exit()
    if '_banggia_' in url:
        xbmc.executebuiltin(f"ShowPicture({re.search(r'__PIC__(.*)', getadv()['path']).group(1)})")

    if '_hdnhaptkfs_' in url:
        content = '''
        Nếu bạn có tài khoản là [COLOR yellow]tenban@gmail.com[/COLOR] thì bạn chọn "domain" là [COLOR yellow]gmail.com[/COLOR],\nmục "id mail" điền là [COLOR yellow]tenban[/COLOR].\n
        Nếu bạn có tài khoản là [COLOR yellow]tenban@xyz.com[/COLOR], mà không có trong danh sách domain thì bạn điền đủ ở mục "id mail" là [COLOR yellow]tenban@xyz.com[/COLOR],\nkhông cần chọn ở mục domain nữa.
        '''
        TextBoxes(ADDON_NAME, content)

    if '_topsearch100_' in url:
        data = search.top100search()
        loadlistitem.list_item_main(data)

    if 'addon' in url:
        url = url.replace(CLOUDSHARE_HOST + '/?action=addon&', '')
        url = urllib_parse.unquote(url)
        install_repo(url)
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'clearCache' in url:

        try:
            cache_utils.clear_cache_manual()

            xbmc.sleep(2000)
        except Exception as e:
            logError(f"Lỗi khi xóa cache: {str(e)}")
            alert(f"Lỗi khi xóa cache: {str(e)}")
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'action=clean_dead_fshare_links' in url:
        try:
            from resources import gsheet
            gsheet.run_bulk_link_cleanup()
        except Exception as e:
            logError(f"Lỗi khi dọn dẹp link chết: {str(e)}")
            alert(f"Lỗi khi dọn dẹp link chết: {str(e)}")
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if '__exitKodi__' in url:
        os._exit(1)
    if 'viewlog' in url:
        from resources.utils import viewlog
        viewlog()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'action=tienich' in url:
        from resources.utils import display_tienich_menu
        display_tienich_menu()
        return
    if 'action=subtitle_fonts' in url:
        from resources.subtitle_fonts import list_subtitle_fonts
        data = list_subtitle_fonts()
        loadlistitem.list_item_main(data)
        return
    if 'action=install_subtitle_font' in url:
        font = re.search(r'font=(.+?)(?:&|$)', url).group(1)
        from resources.subtitle_fonts import install_font
        install_font(font)

        loadlistitem.list_item_main({"content_type": "", "items": []})
        return
    if 'action=install_arctic_zephyr' in url:
        from resources.skin_installer import install_arctic_zephyr
        install_arctic_zephyr()

        loadlistitem.list_item_main({"content_type": "", "items": []})
        return
    if 'action=show_skin_install_guide' in url:
        from resources.skin_installer import show_skin_install_guide
        show_skin_install_guide()

        loadlistitem.list_item_main({"content_type": "", "items": []})
        return
    if "__history__" in url:
        data = PlayCode()
        loadlistitem.list_item_main(data)
        return
    if "__removeAllHistoryPlayCode__" in url:
            file = os.path.join(PROFILE_PATH, 'history.dat')
            open(file, 'w').close()
            notify("Đã xoá lịch sử nhập code")
            exit()
    if "__removeHistory__" in url:
        link = re.search(r"url=(http.*?)&d", url).group(1)
        file = os.path.join(PROFILE_PATH, 'history.dat')
        filetam = os.path.join(PROFILE_PATH, 'temp.dat')
        if os.path.exists(file):
            with open(file, "r") as input_file, open(filetam, "w") as output_file:
                for line in input_file:
                    if link not in line.strip("\n"):
                        output_file.write(line)
            os.replace(filetam, file)
            alert("Đã xoá xong")
        else:
            alert("Không tìm thấy tệp history.dat")
        if os.path.exists(file):
            file_size = os.path.getsize(file)
            if (int(file_size)) > 0:
                xbmc.executebuiltin("Container.Refresh")
        exit()
    if '__settings__' in url:
        ADDON.openSettings()

        exit()
    if 'addon' in url:
        install_repo(url)
        return
    if "__PIC__" in url:
        image_url = re.search(r"__PIC__(.*)",url).group(1)
        xbmc.executebuiltin('ShowPicture(%s)'%(image_url))
        exit()
    if "__timkiem__" in url:
        timkiemMenu()
        exit()
    if "_timtrenfshare_" in url:

        search_content('fshare')
        exit()

    if "_timtrenfshare1_" in url:
        if not "keyword" in url:
            search_content('fshare')
        else:
            match = re.search(r"keyword=(.*)",url)
            if match:
                query = match.group(1)
                search_content('fshare', query)
                exit()
            else:
                alert("Không lấy được từ khoá tìm kiếm")
                exit()
    if "__TIMFSHARE__" in url:
        HISTORY_FILE = os.path.join(PROFILE_PATH, 'timfshare.dat')
        if "keyword" in url:
            match = re.search(r"keyword=(.*)", url)
            if match:
                query = match.group(1)
        else:
            if not os.path.exists(HISTORY_FILE):
                with open(HISTORY_FILE, "w", encoding="utf-8") as file:
                    pass

            with open(HISTORY_FILE, "r", encoding="utf-8") as file:
                history = file.readlines()
            history = [line.strip() for line in history if line.strip()]

            if not history:
                keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
                keyboard.doModal()
                if keyboard.isConfirmed() and keyboard.getText():
                    query = keyboard.getText()
                else:
                    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                    return
            else:
                options = ["[Nhập từ khóa mới]", "[Xóa lịch sử tìm kiếm]"] + history
                dialog = xbmcgui.Dialog()
                selected = dialog.select("Chọn từ khóa tìm kiếm", options)

                if selected == -1:
                    notify("Đã hủy tìm kiếm")
                    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                    return
                elif selected == 0:
                    keyboard = xbmc.Keyboard("", "Nhập tên phim tiếng Anh")
                    keyboard.doModal()
                    if keyboard.isConfirmed() and keyboard.getText():
                        query = keyboard.getText()
                    else:
                        notify("Đã hủy tìm kiếm")
                        return
                elif selected == 1:
                    confirm = dialog.yesno("Xác nhận", "Bạn có chắc chắn muốn xóa lịch sử tìm kiếm không?")
                    if confirm:
                        with open(HISTORY_FILE, "w", encoding="utf-8") as file:
                            pass
                        notify("Đã xóa lịch sử tìm kiếm")
                        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
                    return
                else:
                    query = options[selected]

        if "ref" in url:
            try:
                data = search.timfshare(query)
                loadlistitem.list_item_main(data)
            except Exception as e:
                notify(f"Lỗi khi tìm kiếm: {str(e)}")
        else:

            if query not in history:
                history.insert(0, query)
                with open(HISTORY_FILE, "w", encoding="utf-8") as file:
                    file.write('\n'.join(history))


            try:
                data = search.timfshare(query)
                loadlistitem.list_item_main(data)
            except Exception as e:
                notify(f"Lỗi khi tìm kiếm: {str(e)}")

    if "__searchTVHD__" in url:

        search_content('tvhd')
        exit()
    if '__TIMTVHD__' in url:
        match = re.search(r"keyword=(.*)",url)
        if match:
            query = match.group(1)
            search_content('tvhd', query)
        else:
            alert("Không lấy được từ khoá tìm kiếm")
        exit()

    if '__search__' in url:
        keyboardHandle = xbmc.Keyboard('', 'CloudShare')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                exit()
            queryText = urllib_parse.quote_plus(queryText)
            url = url.replace('__search__', queryText)
        else:exit()

    if '__searchphongblack__' in url:

        search_content('phongblack')
        exit()

    if '__searchphongblack1__' in url:
        match = re.search(r"search=(.*)&",url)
        if match:
            keyword = match.group(1)
            url = "http://phongblack.online/search.php?author=phongblack&search="+keyword
        else:
            url = searchPhongblack()
    if '__removeAllSearchHistory__' in url:
        delete_search_history()
        xbmc.executebuiltin("Container.Refresh")
        exit()

    if 'getfolderfiles' in url:
        notify("external service")
        current = url.replace('http://cloudshare.net/kodi1.php/?action=getfolderfiles&url=', '')
        url = "http://kodi.s2lsolutions.com/get-folder-files.php?author=cGhvbmdibGFjaw&url=" + current
        url = urllib_parse.unquote(url)
    if '__addtofav__' in url:
        if "fshare.vn" in url:
            regex = r"(https://www.fshare.vn.*)&d"
            match = re.search(regex,url)
            link = match.group(1)
            fshare.add_remove_favourite(link,"1")
            return
        else:
            notify("Đây không phải là link fshare")
            return False
    if '__removeFromfav__' in url:
        if "fshare.vn" in url:
            regex = r"(https://www.fshare.vn.*)&d"
            match = re.search(regex,url)
            link = match.group(1)
            fshare.add_remove_favourite(link,"0")
            return
        else:
            notify("Đây không phải là link Fshare")
            return False
    if '__subtitle__' in url:
        match = re.search(r"file_name=(.+)", url)
        name = match.group(1)
        name = name.replace('.', ' ')
        subtitle_searching(name)
        return
    if '__lock__' in url:
        add_lock_dir(url)
        return
    if '__unlock__' in url:
        remove_lock_dir(url)
        return
    if '__watchedHistoryList__' in url:
        data=watchedHistoryList()
        loadlistitem.list_item_watched_history(data)

        return
    if '__removeAllWatchedHistory__' in url:
        delete_watched_history()
        notify("Đã xoá lịch sử xem phim")
        xbmc.executebuiltin("Container.Refresh")
        exit()
    if '__qrlink__' in url:
        qrlink(url)
        exit()
    if '__mobileScan__' in url:
        mobileScan(url)
        exit()

    if check_lock(url):
        dialog = xbmcgui.Dialog()
        result = dialog.input('Nhập mã khoá', type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if len(result) == 0 or result != get_lock_pin():
            alert('Sai mật mã, vui lòng nhập lại')
            exit()
    if 'account_fshare' in url:
        updateAcc()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        exit()
    if 'action=quick_account_menu' in url:
        quick_account.display_quick_account_menu()
        exit()
    if 'action=quick_account_code' in url:
        if xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('Addon_Settings_Open') == 'true':
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON_ID)
        quick_account.quick_account_code()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        exit()
    if 'action=quick_account_qr' in url:
        if xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty('Addon_Settings_Open') == 'true':
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON_ID)
        quick_account.quick_account_qr()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        exit()


    elif 'add_file' in url:

        keyboardHandle = xbmc.Keyboard('','[COLOR yellow]Nhập link Folder hoặc File Fshare của bạn:[/COLOR] [I]Nhập ID của Fshare[/I]')
        keyboardHandle.doModal()
        if (keyboardHandle.isConfirmed()):
            queryText = keyboardHandle.getText()
            if len(queryText) == 0:
                sys.exit()
        if "fshare.vn" in queryText:
            url_input = queryText.replace("http://", "https://")
            if 'token' in url_input:
                match = re.search(r"(\?.+?\d+)", url_input)
                _token = match.group(1)
                url_input = url_input.replace(_token, '')
            elif len(queryText) == 12 or len(queryText) == 15:

                queryText = queryText.upper()
                url_input = 'https://www.fshare.vn/file/' + queryText
        else:
            url_input = queryText

            url_input = url_input.strip()
            if 'fshare' in url_input:
                if 'folder' in url_input:
                    regex = r"folder\/(.+)"
                else:
                    regex = r"file\/(.+)"
                    match = re.search(regex, url_input)
                    f_id = match.group(1)
            file_type, name, file_size = getlink.check_file_info(url_input)

            if file_type == '0':
                file = 'https://www.fshare.vn/folder/' + f_id
            elif file_type == '1':
                file = 'https://www.fshare.vn/file/' + f_id
            elif file_type == '404':
                alert("File bạn nhập không có thực")
                return
            else:
                file = url_input

                url = 'Size:' + file_size + 'Name:' + urllib_parse.quote_plus(name.encode("utf8")) + 'Link:' + file

                filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
                if not os.path.exists(filename):
                    with open(filename, "w+") as f:
                        f.write(url + '*')
                else:
                    with open(filename, "r+") as f:
                        lines = f.read()
                        f.seek(0, 0)
                        f.write(url.rstrip('\r\n') + '*' + lines)
                        notify('Đã lưu link của bạn.')
                return
    elif 'load_file' in url:

        filename = os.path.join(PROFILE_PATH, 'yourlink.dat')
        if not os.path.exists(filename):
            alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        else:
            with open(filename, "r") as f:
                lines = f.read()
                lines = lines.rstrip('*')
                if str(len(lines)) == '0':
                    alert('Bạn chưa có link lưu trữ. Xin vui lòng thêm link.')
                    import xbmcplugin
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                    return
            lines = lines.split('*')
            t = len(lines)
            items = []
            for i in range(0, t):
                item = {}
                line = (lines[i])
                link = re.search(r"Link:(.+)", line).group(1)
                name = re.search(r"Name:(.+?)Link", line).group(1)
                size = re.search(r"Size:(.+?)Name", line).group(1)
                name = urllib_parse.unquote_plus(name)
                if 'fshare' in link:
                    if 'folder' in link:
                        playable = False
                        link = 'plugin://plugin.video.cloudshare?action=play&url=%s' % link
                    elif 'file' in link:
                        playable = True
                        link = 'plugin://plugin.video.cloudshare?action=play&url=%s' % link
                    else:
                        playable = True
                        link = link

                        item["label"] = size + ' GB - ' + name
                        item["is_playable"] = playable
                        item["path"] = link
                        item["thumbnail"] = ''
                        item["icon"] = ""
                        item["label2"] = ""
                        item["info"] = {'plot': ''}
                        items += [item]
                data = {"content_type": "episodes", "items": ""}
                data.update({"items": items})
                loadlistitem.list_item(data)
    elif 'home_fshare' in url:
        notify("Đang tải home fshare...")
        data = fshare_favourite('https://api.fshare.vn/api/fileops/list?pageIndex=0&dirOnly=0&limit=60')
        data = json.loads(data)
        loadlistitem.list_item_main(data)
        return
    elif 'follow_fshare' in url:
        data = fshare_favourite('https://api.fshare.vn/api/fileops/getListFollow')
        data = json.loads(data)

        loadlistitem.list_item(data)

    elif 'folderxxx' in url:
        data = fshare_favourite('https://api.fshare.vn/api/Fileops/ListFavorite')
        data = json.loads(data)
        loadlistitem.list_item_main(data)
        return
    elif 'TopFollowMovie' in url:
        data = fshare_favourite('https://api.fshare.vn//api/fileops/getTopFollowMovie')
        data = json.loads(data)
        loadlistitem.list_item_main(data)
        return
    elif "top_follow_share" in url:
        data = fshare_top_follow()
        data = json.loads(data)
        loadlistitem.list_item_main(data)
        return
    elif "vtvgo" in url:
        regex = r"url=(.+)"
        match = re.search(regex, url)
        link = match.group(1)
        subtitle = ''
        data = {"url": "", "subtitle": ""}
        data.update({"url": link, "subtitle": subtitle})
        play(data)
    elif 'fshare.vn/file/' in url or 'ok.ru' in url or 'drive.google.com' in url:
        regex = r"url=(.+)"
        match = re.search(regex, url)
        links = match.group(1)
        if match:
            subtitle = ''
            links = links.split('[]')
            if len(links) == 2:
                subtitle = links[1]
            link = links[0]
            link = re.sub(r'[&?]v=[a-zA-Z0-9.]+$', '', link)
            data = {"url": "", "subtitle": ""}
            data.update({"url": link, "subtitle": subtitle})
            play(data)
        else:
            alert("Lỗi không xác định được link 01. Báo dev xử lí :-((")
            exit()

    elif 'fshare' in url and 'folder' in url:
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write(f"[default.py] Fshare folder matched in go(). URL: {url}\n")
        except:
            pass
        data = cache_utils.cache_data(url)
        if data is not None:
            try:
                with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                    f_debug.write(f"[default.py] cache_data returned: {len(data.get('items', []))} items\n")
            except:
                pass
            loadlistitem.list_item_main(data)
        else:
            try:
                with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                    f_debug.write("[default.py] cache_data returned None!\n")
            except:
                pass
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return


    elif "docs.google.com" in url:
        handle_google_docs_url(url)
        return
    elif "showWindow" in url:
        show_window("https://i.imgur.com/ytoQpHG.png")
        return
    elif ('VMF' in url or 'CLOUDSHARE' in url) and not 'action=fetch_espisode' in url:
        url = urllib_parse.unquote_plus(url)
        url = url.replace('VMF-', '').replace('CLOUDSHARE-', '')
        regex = r"url=(.+)"
        match = re.search(regex, url)
        links = match.group(1)
        data = list_link(links)
        loadlistitem.list_item(data)
        return

    def process_url(url, site_name, receive_function, setting_key):
        addon = xbmcaddon.Addon()
        setting = f'fsharesite_{setting_key}'

        xbmc.log(f"[CloudShare] Processing URL: {url} for site {site_name}", xbmc.LOGINFO)

        if addon.getSetting(setting) == 'false':
            dialog = xbmcgui.Dialog()
            confirmed = dialog.yesno("Cảnh báo", f"Đây là nội dung được lấy từ web [COLOR yellow]{site_name}[/COLOR]. Lưu ý rằng Addon không chịu trách nhiệm tính chính xác hoặc hợp pháp của nội dung từ [COLOR yellow]{site_name}[/COLOR].\nNhấn YES/ĐỒNG Ý để tiếp tục hoặc NO/KHÔNG để hủy bỏ.")

            if confirmed:
                addon.setSetting(setting, 'true')
                match = re.search(r"url=(.*)", url)
                if match:
                    url = match.group(1)
                xbmc.log(f"[CloudShare] Extracted URL: {url}", xbmc.LOGINFO)
                data = receive_function(url)
                loadlistitem.list_item_main(data)
                return
            else:
                exit()
        else:
            match = re.search(r"url=(.*)", url)
            if match:
                url = match.group(1)
            xbmc.log(f"[CloudShare] Extracted URL: {url}", xbmc.LOGINFO)
            data = receive_function(url)
            loadlistitem.list_item_main(data)
            return
    def handle_url(url):
        plugin_url = f"plugin://plugin.video.cloudshare?action=browse&url={url}"

        try:
            if "hdvietnam" in url:
                xbmcgui.Dialog().ok("Thông báo", "Nguồn trang web này đã ngừng hoạt động. Vui lòng sử dụng các nguồn khác.")
            elif "docs.google.com" in url:
                handle_google_docs_url(plugin_url)
        except Exception as e:
            xbmcgui.Dialog().notification("Lỗi", "Có lỗi xảy ra, vui lòng chọn nguồn khác.", xbmcgui.NOTIFICATION_ERROR)
            xbmc.log(f"Error handling URL {url}: {str(e)}", xbmc.LOGERROR)

    if "hdvietnam" in url:
        xbmcgui.Dialog().ok("Thông báo", "Nguồn trang web này đã ngừng hoạt động. Vui lòng sử dụng các nguồn khác.")
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if 'show_input_form' in url:
        server.show_input_form()
        return
    if '_urlinput_' in url:
        try:
            server_url.show_input_form()
        except Exception as e:
            notify("Đã xảy ra lỗi:", str(e))
            import xbmcplugin
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            exit()
    if 'advanced_settings_menu' in url:
        advanced_settings_menu.display_advanced_settings_menu()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'optimize_cache' in url:
        advanced_settings_menu.optimize_cache()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'optimize_network' in url:
        advanced_settings_menu.optimize_network()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'manage_advanced_settings' in url:
        advanced_settings_menu.manage_advanced_settings()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'view_advancedsettings' in url:
        advanced_settings_menu.view_advancedsettings()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'reset_advancedsettings' in url:
        advanced_settings_menu.reset_advancedsettings()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'auto_vietnamese_subtitle' in url:
        advanced_settings_menu.auto_vietnamese_subtitle()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'external_player_settings' in url:
        advanced_settings_menu.external_player_settings()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'set_external_player' in url:
        advanced_settings_menu.set_external_player()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'reset_to_default_player' in url:
        advanced_settings_menu.reset_to_default_player()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if '_resetdownload_' in url:
        reset_code = ADDON.getSetting('reset_code')
        resetfs.checkvalid(reset_code)
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()
    if 'reset_kodi' in url:
        from resources.kodi_cleaner import show_menu
        show_menu()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()

    if 'install_vmf_source' in url or 'install_cloudshare_source' in url:
        source_installer.install_cloudshare_source()
        import xbmcplugin
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        exit()

    if 'm3uhttp' in url:
        data = iptv.receive(url)
        loadlistitem.list_item_main(data)
        return

    if '__phimle__' in url:

        phim_setting = ADDON.getSetting('phimle_url')
        if not phim_setting:
            data = phim_list("https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=0&headers=1")
            choices = [item[0] for item in data]
            selected = xbmcgui.Dialog().select('Chọn một nguồn phim', choices)
            if selected != -1:
                phimle_url = data[selected][1]
                ADDON.setSetting('phimle_url', phimle_url)
                handle_url(phimle_url)

            else:
                xbmcgui.Dialog().ok('Thông báo', 'Bạn cần phải chọn một nguồn phim lẻ.')
                xbmc.executebuiltin('Addon.Close()')
        else:
            phimle_url = ADDON.getSetting('phimle_url')
            handle_url(phimle_url)


    if '__phimbo__' in url:

        phim_setting = ADDON.getSetting('phimbo_url')
        if not phim_setting:
            data = phim_list("https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=1057024371&headers=1")
            choices = [item[0] for item in data]
            selected = xbmcgui.Dialog().select('Chọn một nguồn phim', choices)
            if selected != -1:
                phimbo_url = data[selected][1]
                ADDON.setSetting('phimbo_url', phimbo_url)
                handle_url(phimbo_url)

            else:

                xbmcgui.Dialog().ok('Thông báo', 'Bạn cần phải chọn một nguồn phim lẻ.')
                xbmc.executebuiltin('Addon.Close()')
        else:
            phimbo_url = ADDON.getSetting('phimbo_url')
            handle_url(phimbo_url)



    data = fetch_data_default(url)

    if not data:

        exit()
    if data.get('error'):
        alert(data['error'])
        sys.exit()
    if data.get("url"):
        alert(str(data.get))
        play(data)
        sys.exit()
    if not data.get("items"):return

    loadlistitem.list_item_main(data)



def main():
    check_and_clear_cache()

    args = urllib.parse.parse_qs(sys.argv[2][1:])
    action = args.get('action', None)
    url = args.get('url', [''])[0]

    go()

    # Reset focus to top of list if this is a new paginated listing request (avoiding reset on back navigation)
    page_param = args.get('page', [''])[0]
    if page_param:
        try:
            import xbmcgui
            window = xbmcgui.Window(10000)
            current_url = sys.argv[0] + sys.argv[2]
            last_url = window.getProperty('CloudShare_LastPageUrl')
            if current_url != last_url:
                window.setProperty('CloudShare_LastPageUrl', current_url)
                xbmc.sleep(300)
                for cid in range(50, 56):
                    xbmc.executebuiltin(f"Control.SetFocus({cid}, 0)")
        except Exception:
            pass

if __name__ == '__main__':
    main()



