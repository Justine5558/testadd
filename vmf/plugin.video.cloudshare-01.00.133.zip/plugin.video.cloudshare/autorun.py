import xbmc, xbmcaddon, xbmcvfs
import os
import sys
import threading
import urllib.parse
import urllib.request
import ssl
from http.server import SimpleHTTPRequestHandler, HTTPServer

# Add bundled library path to sys.path
addon_dir = os.path.dirname(os.path.abspath(__file__))
lib_dir = os.path.join(addon_dir, "resources", "lib")
if lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)

import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Global connection sessions cache
sessions = {}
sessions_lock = threading.Lock()

def get_session(domain):
    with sessions_lock:
        if domain not in sessions:
            session = requests.Session()
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=10,
                pool_maxsize=20,
                max_retries=2
            )
            session.mount('http://', adapter)
            session.mount('https://', adapter)
            sessions[domain] = session
        return sessions[domain]

def autoruncloudshare():
    try:
        if xbmcaddon.Addon().getSetting('chaycloudshare') == 'true':
            xbmc.executebuiltin("RunAddon(plugin.video.cloudshare)")
    except Exception as e:
        xbmc.log(f"[CloudShare-Service] autoruncloudshare error: {e}", xbmc.LOGERROR)

class CacheFileHandler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        # Change LOGDEBUG to LOGINFO to see request logs in standard kodi.log
        xbmc.log(f"[CloudShare-Server] Request: {format % args}", xbmc.LOGINFO)

    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        filename = os.path.basename(parsed_path.path)
        
        if filename == 'cloudshare_temp.m3u8':
            xbmc_temp = xbmcvfs.translatePath('special://temp')
            file_path = os.path.join(xbmc_temp, filename)
            if os.path.exists(file_path):
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Access-Control-Allow-Origin', '*')
                try:
                    stat = os.stat(file_path)
                    self.send_header('Content-Length', str(stat.st_size))
                except Exception:
                    pass
                self.end_headers()
                try:
                    with open(file_path, 'rb') as f:
                        self.wfile.write(f.read())
                except Exception as e:
                    xbmc.log(f"[CloudShare-Server] Error sending file: {e}", xbmc.LOGERROR)
                return
            else:
                self.send_error(404, "File not found")
                return
        elif parsed_path.path == '/segment':
            query = urllib.parse.parse_qs(parsed_path.query)
            target_url = query.get('url', [None])[0]
            referer = query.get('referer', [None])[0]
            
            if target_url:
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                }
                if referer:
                    headers['Referer'] = referer
                    parsed_ref = urllib.parse.urlparse(referer)
                    headers['Origin'] = f"https://{parsed_ref.netloc}"
                
                parsed_target = urllib.parse.urlparse(target_url)
                domain = parsed_target.netloc
                session = get_session(domain)
                
                try:
                    resp = session.get(target_url, headers=headers, stream=True, timeout=10.0, verify=False)
                    self.send_response(resp.status_code)
                    for h_key, h_val in resp.headers.items():
                        if h_key.lower() not in ['transfer-encoding', 'connection', 'content-encoding']:
                            self.send_header(h_key, h_val)
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    
                    for chunk in resp.iter_content(chunk_size=64 * 1024):
                        if chunk:
                            self.wfile.write(chunk)
                    return
                except Exception as e:
                    xbmc.log(f"[CloudShare-Server] Error proxying segment: {e}", xbmc.LOGERROR)
                    self.send_error(500, str(e))
                    return
        
        self.send_error(403, "Access denied")

def run_server():
    port = 8899
    httpd = None
    for p in range(8899, 8920):
        try:
            server_address = ('127.0.0.1', p)
            httpd = HTTPServer(server_address, CacheFileHandler)
            port = p
            break
        except Exception as e:
            xbmc.log(f"[CloudShare-Server] Port {p} is busy: {e}", xbmc.LOGWARN)
            
    if httpd:
        xbmc.log(f"[CloudShare-Server] Started local HTTP server on port {port}", xbmc.LOGINFO)
        try:
            xbmc_temp = xbmcvfs.translatePath('special://temp')
            port_file = os.path.join(xbmc_temp, 'cloudshare_port.txt')
            with open(port_file, 'w') as f:
                f.write(str(port))
        except Exception as e:
            xbmc.log(f"[CloudShare-Server] Failed to write port file: {e}", xbmc.LOGERROR)
            
        server_thread = threading.Thread(target=httpd.serve_forever)
        server_thread.daemon = True
        server_thread.start()
        
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            if monitor.waitForAbort(5):
                break
        
        xbmc.log("[CloudShare-Server] Shutting down HTTP server", xbmc.LOGINFO)
        httpd.shutdown()
        httpd.server_close()
    else:
        xbmc.log("[CloudShare-Server] Failed to bind to any port in range 8899-8919", xbmc.LOGERROR)

if __name__ == '__main__':
    # Start the HTTP server in a separate background thread
    srv_thread = threading.Thread(target=run_server)
    srv_thread.daemon = True
    srv_thread.start()
    
    # Run the original autorun function
    autoruncloudshare()
    
    # Keep the main service thread alive
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    xbmc.log("[CloudShare-Service] Service thread ending", xbmc.LOGINFO)