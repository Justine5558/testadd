import sys,re
import os, time, json
import remove_accents
import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
from resources.addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, LOG, PROFILE, get_view_xxx, get_view_mode, VERSION
from config import CLOUDSHARE_HOST
from resources import fshare
import urllib.parse


ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE_PATH = xbmcvfs.translatePath(ADDON_PROFILE)
HANDLE = int(sys.argv[1])
CACHE_TIMEOUT = 300

def debug(text):
    
    filename = os.path.join(PROFILE_PATH, 'list.dat')
    if not os.path.exists(filename):
        with open(filename, "w+", encoding="utf-8") as f:
            f.write(text)
    else:
        with open(filename, "wb") as f:
            f.write(text.encode("UTF-8"))
            

def check_lock(item_path):

    filename = os.path.join(PROFILE_PATH, 'lock_dir.dat')
    if not os.path.exists(filename):
        return False
    with open(filename, "r") as f:
        lines = f.readlines()
    return (item_path + "\n") in lines

def set_item_art(listItem, item):
    art = {}
    if item.get("art"):
        art.update(item["art"])
    
    if 'thumb' not in art and item.get("thumbnail"):
        art['thumb'] = item["thumbnail"]
    if 'icon' not in art and item.get("icon"):
        art['icon'] = item["icon"]
    if 'poster' not in art and (item.get("icon") or item.get("thumbnail")):
        art['poster'] = item.get("icon") or item.get("thumbnail")
        
    listItem.setArt(art)

def force_view_mode():
    pass

def sanitize_data(data):
    if isinstance(data, str):
        return data.replace('plugin.video.' + 'cloudshare', ADDON_ID).replace('plugin.video.' + 'cloudshare', ADDON_ID)
    elif isinstance(data, list):
        return [sanitize_data(v) for v in data]
    elif isinstance(data, dict):
        return {k: sanitize_data(v) for k, v in data.items()}
    return data

def adjust_info_year_from_label(label, info):
    if info is None:
        return
    
    # Always try to extract a valid year from the label first
    years_found = re.findall(r'\b(19[3-9]\d|20[0-2]\d)\b', label)
    if years_found:
        try:
            y_val = int(years_found[-1]) # use the last year found in label (usually movie year)
            info["year"] = y_val
            return
        except ValueError:
            pass
            
    db_year = info.get("year")
    if db_year:
        try:
            info["year"] = int(db_year)
        except (ValueError, TypeError):
            pass

def format_label_with_year(label, info):
    if not info:
        return label
    year = info.get("year")
    if year:
        try:
            correct_year = int(year)
            correct_year_str = str(correct_year)
        except (ValueError, TypeError):
            return label

        years_found = re.findall(r'\b(19\d{2}|20\d{2})\b', label)
        replaced = False
        for y_str in years_found:
            try:
                y_val = int(y_str)
                if abs(y_val - correct_year) <= 2:
                    label = label.replace(y_str, correct_year_str)
                    replaced = True
            except ValueError:
                pass
        
        if not replaced and correct_year_str not in label:
            return f"{label} ({correct_year_str})"
            
    return label

def parse_series_info_from_label(label):
    status = "ongoing"
    cur_ep = ""
    total_ep = ""
    
    label_lower = label.lower()
    
    if any(kw in label_lower for kw in ["hoàn tất", "hoantat", "trọn bộ", "tron bo", "full"]):
        status = "completed"
        
    match_slash = re.search(r'\b(\d+)\s*/\s*(\d+)\b', label)
    if match_slash:
        cur_ep = match_slash.group(1)
        total_ep = match_slash.group(2)
        if int(cur_ep) >= int(total_ep):
            status = "completed"
        else:
            status = "ongoing"
    else:
        match_tap = re.search(r'\b(\d+)\s*(?:tập|tap|tâp)\b', label, re.IGNORECASE)
        if match_tap:
            cur_ep = match_tap.group(1)
            total_ep = match_tap.group(1)
            if status != "completed":
                status = "completed"
        else:
            match_ep = re.search(r'(?:tập|tap|ep|episode)\s*(\d+)\b', label, re.IGNORECASE)
            if match_ep:
                cur_ep = match_ep.group(1)
                status = "ongoing"
                
    return status, cur_ep, total_ep

def format_label_series_status(label, item, is_tvshow=False):
    # Only format series status tags for folders (series directories),
    # not for playable files (individual episodes).
    is_folder = item.get("is_folder", not item.get("is_playable", False))
    if not is_folder:
        return label

    # Skip formatting for navigation/utility items (like "Trang tiếp", "Trang trước", "Làm mới")
    lbl_clean = re.sub(r'\[/?[^\]]+\]', '', label).lower()
    if any(kw in lbl_clean for kw in ["trang tiếp", "trang trước", "làm mới", "lam moi", "trang tiep", "trang truoc"]):
        return label

    path = item.get("path", "")
    is_series = is_tvshow or "_phimbo_" in path or (item.get("info") and item["info"].get("mediatype") == "tvshow")
    if not is_series:
        return label

    if "Hoàn tất" in label or "Đang chiếu" in label or "Phim Bộ" in label:
        return label
        
    status, cur_ep, total_ep = parse_series_info_from_label(label)
    
    status_text = "Đang chiếu"
    if status == "completed":
        status_text = "Hoàn tất"
        
    status_color = "orange" if status_text == "Đang chiếu" else "springgreen"
    status_labeled = f"[COLOR {status_color}]{status_text}[/COLOR]"
    
    clean_lbl = label
    has_lock = clean_lbl.startswith("*")
    if has_lock:
        clean_lbl = clean_lbl[1:].strip()
        
    clean_lbl = re.sub(r'\b\d+\s*(?:tập|tap|tâp)\b', '', clean_lbl, flags=re.IGNORECASE)
    clean_lbl = re.sub(r'\b\d+\s*/\s*\d+\b', '', clean_lbl)
    clean_lbl = " ".join(clean_lbl.split())
    clean_lbl = clean_lbl.strip(" -–|")
    
    if cur_ep and total_ep and cur_ep != total_ep:
        prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled} ({cur_ep}/{total_ep})"
    elif total_ep:
        prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled} ({total_ep} tập)"
    elif cur_ep:
        prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled} (Tập {cur_ep})"
    else:
        prefix = f"[COLOR lightskyblue]Phim Bộ[/COLOR] - {status_labeled}"
        
    ret = f"[{prefix}] {clean_lbl}"
    if has_lock:
        ret = "*" + ret
        
    return ret

def format_info(info):
    if not info:
        return info
    
    info_copy = dict(info)
    plot = info_copy.get("plot", "")
    rating = info_copy.get("rating", 0.0)
    genre = info_copy.get("genre", "")
    year = info_copy.get("year")
    
    # Extract country from genre
    country = info_copy.get("country", "")
    if not country and genre:
        import unicodedata
        COUNTRIES_TUPLE = (
            "Trung Quốc", "Hàn Quốc", "Hồng Kông", "Mỹ", "Thái Lan", "Nhật Bản", "Ấn Độ", "Đài Loan", 
            "Anh", "Pháp", "Đức", "Nga", "Tây Ban Nha", "Việt Nam", "Ý", "Canada", "Úc", "Thổ Nhĩ Kỳ",
            "Thụy Điển", "Thụy Sĩ", "Hà Lan", "Bỉ", "Đan Mạch", "Na Uy", "Phần Lan", "Brazil", "Argentina",
            "Mexico", "Philippines", "Singapore", "Malaysia", "Indonesia"
        )
        norm_genre = unicodedata.normalize('NFC', genre)
        found_countries = []
        cleaned_genres = []
        
        for g_part in [g.strip() for g in norm_genre.split(',') if g.strip()]:
            g_part_lower = g_part.lower()
            is_country = False
            for c in COUNTRIES_TUPLE:
                norm_c = unicodedata.normalize('NFC', c)
                if norm_c.lower() == g_part_lower:
                    found_countries.append(norm_c)
                    is_country = True
                    break
            if not is_country:
                cleaned_genres.append(g_part)
                
        if found_countries:
            country = ", ".join(found_countries)
            genre = ", ".join(cleaned_genres)
            info_copy["genre"] = genre
            
    # Strip any existing metadata prefixes to prevent duplication
    plot_clean = plot if plot else ""
    if plot_clean:
        import html
        plot_clean = html.unescape(plot_clean)
        # Strip all formatting prefixes that we or previous code might have prepended
        plot_clean = re.sub(r'^\[Điểm:[^\]]+\]\s*\n?', '', plot_clean, flags=re.IGNORECASE | re.MULTILINE)
        plot_clean = re.sub(r'^\[COLOR\s+\w+\]\[B\](?:NĂM PHÁT HÀNH|QUỐC GIA|ĐÁNH GIÁ|ĐẠO DIỄN|NHÀ SẢN XUẤT|DIỄN VIÊN|NĂM|QUỐC GIA|ĐÁNH GIÁ & THỂ LOẠI):.*?\[/B\]\[/COLOR\]\s*\n*', '', plot_clean, flags=re.IGNORECASE | re.MULTILINE)
        plot_clean = plot_clean.strip()
        
    # Get rating string (either custom rating_str or formatted rating float)
    rating_str = info_copy.get("rating_str", "")
    if not rating_str and rating > 0.0:
        rating_str = "★ %.1f/10" % rating
        
    # Rebuild header: (1) Năm, (2) Quốc gia, (3) Đánh giá
    header_parts = []
    if year:
        header_parts.append(f"[COLOR gold][B]Năm:[/B][/COLOR] {year}")
    if country:
        header_parts.append(f"[COLOR lightskyblue][B]Quốc gia:[/B][/COLOR] {country}")
    if rating_str:
        header_parts.append(f"[COLOR lime][B]Đánh giá:[/B][/COLOR] {rating_str}")
        
    header = "  •  ".join(header_parts) if header_parts else ""
    
    # Rebuild suffix/metadata block: (5) Thông tin thêm
    suffix_parts = []
    suffix_parts.append("[COLOR orange]──────────────────────────────────[/COLOR]")
    suffix_parts.append("[COLOR orange][B]THÔNG TIN THÊM:[/B][/COLOR]")
    
    if genre:
        suffix_parts.append(f"• [COLOR gold]Thể loại:[/COLOR] {genre}")
        
    director = info_copy.get("director", "")
    if director:
        suffix_parts.append(f"• [COLOR gold]Đạo diễn:[/COLOR] {director}")
        
    studio = info_copy.get("studio", "")
    if studio:
        suffix_parts.append(f"• [COLOR gold]Nhà sản xuất:[/COLOR] {studio}")
        
    cast = info_copy.get("cast", [])
    if cast:
        if isinstance(cast, list):
            cast_str = ", ".join(cast)
        else:
            cast_str = str(cast)
        suffix_parts.append(f"• [COLOR gold]Diễn viên:[/COLOR] {cast_str}")
        
    suffix = "\n".join(suffix_parts)
    
    # Assemble final plot: Header (1,2,3) + Plot (4) + Suffix (5)
    full_plot = ""
    if header:
        full_plot += header + "\n\n"
    full_plot += plot_clean
    full_plot += "\n\n" + suffix
    
    info_copy["plot"] = full_plot
    return info_copy

def list_item_main(data):
    data = sanitize_data(data)
    debug(str(data))
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
    listitems = list(range(len(data["items"])))
    for i, item in enumerate(data["items"]):
        path = item["path"]
        is_play_action = any(act in path for act in ["action=play", "action=play_direct", "action=smart_play", "action=tvcine_play", "action=thuvienhd_play"])
        if (path.startswith("plugin://plugin.video.cloudshare") or path.startswith("plugin://")) and not is_play_action and "&v=" not in path and "?v=" not in path:
            if "?" in path:
                path += f"&v={VERSION}"
            else:
                path += f"?v={VERSION}"
            item["path"] = path
        lock_url = path.replace("plugin://%s" % ADDON_ID, CLOUDSHARE_HOST)
        lock_url = re.sub('\?', '/?', lock_url)
        label = item["label"]
        filterStr = ["xxx", "sex", "jav", "cap 3", "18+", "20+"]
        if check_lock(lock_url):label = "*" + label
        if item.get("info"):
            adjust_info_year_from_label(label, item["info"])
            label = format_label_with_year(label, item["info"])
        is_tvshow = data.get("content_type") == "tvshows"
        label = format_label_series_status(label, item, is_tvshow)
        if item.get("info"):
            item["info"]["title"] = label
        listItem = xbmcgui.ListItem(label=label, label2=item["label2"])
        if get_view_xxx() == 'false':
            label_ = label.lower()
            if '18+' in label_ or 'xxx' in label_ or 'XXX' in label_ or 'cấp 3' in label or 'jav' in label_ or 'JAV' in label_ or '+' in label_ or 'sex' in label_ or 'SEX' in label_ or 'fuck' in label_ or '20+' in label_:
                # listItem = xbmcgui.ListItem(label='[I]Nội dung cần thiết lập để xem[/I]', label2='', iconImage='', thumbnailImage='')
                listItem = xbmcgui.ListItem(label='[I]Nội dung cần thiết lập để xem[/I]',label2=item["label2"])
                path = 'plugin://plugin.video.cloudshare?action=browse&node_id=75'
                
            else:
                # listItem = xbmcgui.ListItem(label=label, label2=item["label2"], iconimage=item["icon"], thumbnailImage=item["thumbnail"])
                listItem = xbmcgui.ListItem(label=label, label2=item["label2"])
        if get_view_xxx() == 'true':
            listItem = xbmcgui.ListItem(label=label, label2=item["label2"])

        if item.get("info"):
            listItem.setInfo("video", format_info(item["info"]))
        
        set_item_art(listItem, item)
        # context_menu
        menu_context = []
        title = item["label"]
        title = re.sub('\[.*?]', '', title)
        title = re.sub('\s', '-', title)
        title = re.sub('--', '-', title)
        title = re.sub('--', '-', title)
        title = re.sub('[\\\\/*?:"<>|#]', "", title)
        title = remove_accents.remove_accents(title)
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        elif "_phimle_" in path:
            command = 'RunPlugin(%s&d=select_source_phimle)' % item["path"]
            menu_context.append(('Thay đổi nguồn phim', command,))
        elif "_phimbo_" in path:
            command = 'RunPlugin(%s&d=select_source_phimbo)' % item["path"]
            menu_context.append(('Thay đổi nguồn phim', command,))
        elif "fshare.vn" in path:
            command = 'RunPlugin(%s&d=__addtofav__&file_name=%s)' % (item["path"], title)
            menu_context.append(('[COLOR yellow]Thêm vào Yêu Thích Fshare[/COLOR]', command,))
            command = 'RunPlugin(%s&d=__removeFromfav__&file_name=%s)' % (item["path"], title)
            menu_context.append(('[COLOR yellow]Xoá khỏi Yêu Thích Fshare[/COLOR]', command,))
            command = 'RunPlugin(%s&d=__qrlink__)' % item["path"]
            menu_context.append(('[COLOR yellow]Play on Mobile[/COLOR]', command,))
            if "file" in path:
                command = 'RunPlugin(%s&d=__download__)' % item["path"]
                menu_context.append(('[COLOR yellow]Download[/COLOR]', command,))
        command = 'RunPlugin(%s&d=__lock__)' % item["path"]
        menu_context.append(('Khoá mục này', command,))
        command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
        menu_context.append(('Mở khoá mục này', command,))
        command = 'RunPlugin(%s&d=__settings__)' % item["path"]
        menu_context.append(('[COLOR yellow]Addon Setting[/COLOR]', command,))
        
        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        is_folder = item.get("is_folder", not item["is_playable"])
        listitems[i] = (path, listItem, is_folder)
        # listitems[i] = (path, listItem)
    cache_to_disc = data.get("cache_to_disc", True) if isinstance(data, dict) else True
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)
    force_view_mode()

def list_item_main_cache(data):
    #data = json.loads(data)  # Chuyển đổi chuỗi JSON thành danh sách Python
    data = sanitize_data(data)
    
    items = data["items"]
    is_tvshow = data.get("content_type") == "tvshows"
    for item in items:
        label = item["label"]
        if item.get("info"):
            adjust_info_year_from_label(label, item["info"])
            label = format_label_with_year(label, item["info"])
        label = format_label_series_status(label, item, is_tvshow)
        if item.get("info"):
            item["info"]["title"] = label
        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', format_info(item["info"]))
        set_item_art(list_item, item)
        list_item.setProperty('IsPlayable', 'true' if item["is_playable"] else 'false')
        is_folder = item.get("is_folder", not item["is_playable"])
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item["path"], listitem=list_item, isFolder=is_folder)
    
    xbmcplugin.endOfDirectory(HANDLE)
    force_view_mode()

def list_item(data):
    data = sanitize_data(data)
    
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)

    listitems = list(range(len(data["items"])))
    
    for i, item in enumerate(data["items"]):
        path = item["path"]
        is_play_action = any(act in path for act in ["action=play", "action=play_direct", "action=smart_play", "action=tvcine_play", "action=thuvienhd_play"])
        if (path.startswith("plugin://plugin.video.cloudshare") or path.startswith("plugin://")) and not is_play_action and "&v=" not in path and "?v=" not in path:
            if "?" in path:
                path += f"&v={VERSION}"
            else:
                path += f"?v={VERSION}"
            item["path"] = path
        lock_url = path
        lock_url = re.sub('\?', '/?', lock_url)
        label = item["label"]
        
        if "@" in label:label = label.replace("@", "")
        
        if check_lock(lock_url):
            label = "*" + label
        if item.get("info"):
            adjust_info_year_from_label(label, item["info"])
            label = format_label_with_year(label, item["info"])
        is_tvshow = data.get("content_type") == "tvshows"
        label = format_label_series_status(label, item, is_tvshow)
        if item.get("info"):
            item["info"]["title"] = label
        listItem = xbmcgui.ListItem(
            label=label, label2=item["label2"])
        if item.get("info"):
            listItem.setInfo("video", format_info(item["info"]))
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        set_item_art(listItem, item)
        menu_context = []
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        if "fshare" in path:
            command = 'RunPlugin(%s&d=__addtofav__)' % (item["path"])
            menu_context.append(('Thêm vào Yêu Thích Fshare', command,))
            command = 'RunPlugin(%s&d=__removeFromfav__)' % (item["path"])
            menu_context.append(('Xoá Yêu Thích Fshare', command,))
            command = 'RunPlugin(%s&d=__lock__)' % item["path"]
            menu_context.append(('Khoá mục này', command,))
            command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
            menu_context.append(('Mở khoá mục này', command,))
            command = 'RunPlugin(%s&d=__qrlink__)' % item["path"]
            menu_context.append(('[COLOR yellow]QR Link[/COLOR]', command,))
            command = 'RunPlugin(%s&d=__removeHistory__)' % (item["path"])
            menu_context.append(('Xoá lịch sử dòng này', command,))
            command = 'RunPlugin(%s&d=__removeAllHistory__)' % (item["path"])
            menu_context.append(('Xoá tất cả lịch sử', command,))
        else:
            command = 'RunPlugin(%s&d=__removeHistory__)' % (item["path"])
            menu_context.append(('Xoá lịch sử dòng này', command,))
            command = 'RunPlugin(%s&d=__removeAllHistory__)' % (item["path"])
            menu_context.append(('Xoá tất cả lịch sử', command,))
            command = 'RunPlugin(%s&d=__lock__)' % item["path"]
            menu_context.append(('Khoá mục này', command,))
            command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
            menu_context.append(('Mở khoá mục này', command,))
            
        
        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        is_folder = item.get("is_folder", not item["is_playable"])
        listitems[i] = (path, listItem, is_folder)
    
    cache_to_disc = data.get("cache_to_disc", True) if isinstance(data, dict) else True
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)
    force_view_mode()
def list_item_watched_history(data):
    data = sanitize_data(data)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)

    listitems = list(range(len(data["items"])))
    
    for i, item in enumerate(data["items"]):
        lock_url = item["path"]
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]
        
        if "@" in label:label = label.replace("@", "")
        
        if check_lock(lock_url):
            label = "*" + label
        if item.get("info"):
            adjust_info_year_from_label(label, item["info"])
            label = format_label_with_year(label, item["info"])
        is_tvshow = data.get("content_type") == "tvshows"
        label = format_label_series_status(label, item, is_tvshow)
        if item.get("info"):
            item["info"]["title"] = label
        listItem = xbmcgui.ListItem(
            #label=label, label2=item["label2"], iconImage=item["icon"], thumbnailImage=item["thumbnail"])
            label=label, label2=item["label2"])
        if item.get("info"):
            listItem.setInfo("video", format_info(item["info"]))
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        set_item_art(listItem, item)
        menu_context = []
        if item.get("context_menu"):
            listItem.addContextMenuItems(item["context_menu"])
        command = 'RunPlugin(%s&d=__removeAllWatchedHistory__)' % (item["path"])
        menu_context.append(('[COLOR yellow]Xoá lịch sử xem phim[/COLOR]', command,))
        if "fshare" in path:
            command = 'RunPlugin(%s&d=__addtofav__)' % (item["path"])
            menu_context.append(('Thêm vào Yêu Thích Fshare', command,))
            command = 'RunPlugin(%s&d=__removeFromfav__)' % (item["path"])
            menu_context.append(('Xoá Yêu Thích Fshare', command,))
        
        command = 'RunPlugin(%s&d=__lock__)' % item["path"]
        menu_context.append(('Khoá mục này', command,))
        command = 'RunPlugin(%s&d=__unlock__)' % item["path"]
        menu_context.append(('Mở khoá mục này', command,))
        command = 'RunPlugin(%s&d=__qrlink__)' % item["path"]
        menu_context.append(('[COLOR yellow]QR Link[/COLOR]', command,))
        
        
        listItem.addContextMenuItems(menu_context)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        is_folder = item.get("is_folder", not item["is_playable"])
        listitems[i] = (path, listItem, is_folder)
    
    cache_to_disc = data.get("cache_to_disc", True) if isinstance(data, dict) else True
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)
    force_view_mode()
def list_item_search_history(data):
    data = sanitize_data(data)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)

    listitems = list(range(len(data["items"])))
    
    for i, item in enumerate(data["items"]):
        lock_url = item["path"]
        lock_url = re.sub('\?', '/?', lock_url)
        path = item["path"]
        label = item["label"]
        
        if "@" in label:label = label.replace("@", "")
        
        if check_lock(lock_url):
            label = "*" + label
        if item.get("info"):
            adjust_info_year_from_label(label, item["info"])
            label = format_label_with_year(label, item["info"])
        is_tvshow = data.get("content_type") == "tvshows"
        label = format_label_series_status(label, item, is_tvshow)
        if item.get("info"):
            item["info"]["title"] = label
        listItem = xbmcgui.ListItem(
            #label=label, label2=item["label2"], iconImage=item["icon"], thumbnailImage=item["thumbnail"])
            label=label, label2=item["label2"])
        if item.get("info"):
            listItem.setInfo("video", format_info(item["info"]))
        if item.get("stream_info"):
            for type_, values in item["stream_info"].items():
                listItem.addStreamInfo(type_, values)
        set_item_art(listItem, item)
        listItem.setProperty("isPlayable", item["is_playable"] and "true" or "false")
        if item.get("properties"):
            for k, v in item["properties"].items():
                listItem.setProperty(k, v)
        is_folder = item.get("is_folder", not item["is_playable"])
        listitems[i] = (path, listItem, is_folder)
    
    cache_to_disc = data.get("cache_to_disc", True) if isinstance(data, dict) else True
    xbmcplugin.addDirectoryItems(HANDLE, listitems, totalItems=len(listitems))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)