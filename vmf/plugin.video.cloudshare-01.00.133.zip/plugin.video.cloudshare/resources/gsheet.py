
import requests, re, json, os, threading, time
from six.moves import urllib_parse, html_parser
from .addon import alert, notify, TextBoxes, ADDON, ADDON_ID, ADDON_PROFILE, logError, PROFILE, PROFILE_PATH, headers, addon_url
import xbmcvfs
from resources import fshare
from resources.utils import save_fshare_metadata, get_cached_metadata

def getdata(url):
    url = urllib_parse.unquote_plus(url)
    try:
        match = re.search(r"/d\/([a-zA-Z0-9-_]+)", url)
        if not match:
            return {"error": "Đường dẫn Google Sheet không hợp lệ."}
        id_sheet = match.group(1)
        if "gid" in url:
            gid = re.search(r"gid=(\d.*)", url).group(1)
        else:
            gid = 0
        url = "https://docs.google.com/spreadsheets/d/" + id_sheet + "/gviz/tq?gid=" + str(gid) + "&headers=1"
        import urlquick
        r = urlquick.get(url, headers=headers, verify=False, timeout=5, max_age=7200)
        
        if r.status_code == 401 or r.status_code == 403:
            return {"error": "Trang tính này bị giới hạn quyền truy cập (Private). Vui lòng thông báo cho tác giả chia sẻ công khai."}
        if r.status_code == 410 or r.status_code == 404:
            return {"error": "Trang tính này đã bị xóa hoặc không tồn tại."}
        if r.status_code != 200:
            return {"error": f"Lỗi truy cập trang tính (Mã lỗi: {r.status_code})."}
            
        if 'google.visualization.Query.setResponse' not in r.text and '<html' in r.text.lower():
            return {"error": "Trang tính này bị giới hạn quyền truy cập (Private). Vui lòng thông báo cho tác giả."}
            
        start_index = r.text.find('{')
        end_index = r.text.rfind('}') + 1
        if start_index == -1 or end_index == -1:
            return {"error": "Dữ liệu trang tính không đúng định dạng JSON."}
        nd = json.loads(r.text[start_index:end_index])
    except Exception as e:
        return {"error": f"Lỗi kết nối trang tính: {str(e)}"}

    items1 = []
    if nd.get("table", {}).get("cols"):
        name = ''
        link = ''
        thumb = ''
        info = ''
        fanart = ''
        genre = ''
        rating = ''

        if len(nd["table"]["cols"]) > 0:
            name_data = nd["table"]["cols"][0]
            name = name_data.get("label", "")
            if "|" in name:
                name_parts = name.split("|")
                name = name_parts[0].replace("*", "").replace("@", "")
                link = name_parts[1] if len(name_parts) > 1 else ""

        if len(nd["table"]["cols"]) > 1:
            link_data = nd["table"]["cols"][1]
            link = link_data.get("label", "")
            if "token" in link:
                link = re.search(r"(https.+?)\/\?token", link).group(1) if match else ""

        if len(nd["table"]["cols"]) > 2:
            thumb = nd["table"]["cols"][2].get("label", "")

        if len(nd["table"]["cols"]) > 3:
            info = nd["table"]["cols"][3].get("label", "")

        if len(nd["table"]["cols"]) > 4:
            fanart = nd["table"]["cols"][4].get("label", "")

        if len(nd["table"]["cols"]) > 5:
            genre = nd["table"]["cols"][5].get("label", "")

        if len(nd["table"]["cols"]) > 6:
            rating = nd["table"]["cols"][6].get("label", "")

        playable = not ("folder" in link or "menu" in link or "docs.google.com" in link or "m3uhttp" in link)

        if name and any(substring in link for substring in ['http', 'udp', 'rtp', 'plugin', 'acestream']):
            try:
                rating_value = float(rating) if rating and rating.replace('.', '', 1).isdigit() else 0.0
            except:
                rating_value = 0.0

            items1 = [{
                'label': name,
                'is_playable': playable,
                'path': f'{addon_url}action=play&url={link}',
                'thumbnail': thumb,
                'icon': thumb,
                'label2': name,
                'info': {
                    'title': name,
                    'plot': info,
                    'genre': genre,
                    'rating': rating_value,
                    'mediatype': 'movie'
                },
                'art': {
                    "fanart": fanart,
                    "poster": thumb,
                    "thumb": thumb,
                    "icon": thumb
                }
            }]
        else:
            items1 = []

    js = nd.get("table", {}).get("rows", [])
    items = items1 if items1 else []

    for link in js:
        item = {}
        row = link["c"]
        try:
            val = row[0]["v"] if len(row) > 0 and row[0] else None
            if val is None or not str(val).strip():
                name = 'Lỗi tên'
            else:
                name = str(val).replace("||", "|")
        except Exception as e:
            name = 'Lỗi tên'

        # Fallback names for specific known links with empty cells in community sheets
        if name == 'Lỗi tên' and row and len(row) > 1 and row[1]:
            try:
                link_val = str(row[1]["v"]) if row[1]["v"] else ""
                if "S7E59KSZCGZE" in link_val:
                    name = "Phim VTV"
                elif "K4LEVXT2KBO5" in link_val:
                    name = "Phim Việt Nam"
                elif "KWKS3P2W5OO4" in link_val:
                    name = "Phim Việt Nam 4K"
            except Exception:
                pass

        if "|" in name:
            lis = name.split("|")
            name = lis[0].replace("*", "").replace("@", "")
            link = lis[1] if len(lis) > 1 else ""
            thumb = lis[2] if len(lis) > 2 else ""
            info = lis[3] if len(lis) > 3 else ""
            fanart = lis[4] if len(lis) > 4 else ""
        else:
            try:
                link = row[1]["v"]
                if "token" in link:
                    regex = r"(https.+?)\/\?token"
                    match = re.search(regex, link)
                    if match:
                        link = match.group(1)
            except:
                link = ""
            try:
                thumb = row[2]["v"]
            except:
                thumb = ""
            try:
                info = row[3]["v"]
            except:
                info = ""
            try:
                fanart = row[4]["v"]
            except:
                fanart = thumb
            try:
                genre = row[5]["v"]
            except:
                genre = ""
            try:
                rating = row[6]["v"]
            except:
                rating = ""

        playable = not ("folder" in link or "docs.google.com" in link or "pastebin.com" in link or "m3uhttp" in link or "menu" in link)
        if "fshare.vn/folder" in link:
            save_fshare_metadata(link, thumb, info)
        if any(substring in link for substring in ["http", "rtp", "udp", "acestream", "plugin"]):
            # Cập nhật cấu trúc dữ liệu để phù hợp với loadlistitem.py
            item["label"] = name if link else name + " - no link"
            item["is_playable"] = playable
            item["path"] = f'{addon_url}action=play&url={link}'
            item["thumbnail"] = thumb
            item["icon"] = thumb
            item["label2"] = name  # Thêm tên phim vào label2 để hiển thị ở các mục đặc biệt

            # Thông tin chi tiết cho video
            try:
                rating_value = float(rating) if rating and rating.replace('.', '', 1).isdigit() else 0.0
            except:
                rating_value = 0.0

            item["info"] = {
                'title': name,
                'plot': info,
                'genre': genre,
                'rating': rating_value,
                'mediatype': 'movie'
            }

            # Thông tin hình ảnh
            item["art"] = {
                "fanart": fanart,
                "poster": thumb,
                "thumb": thumb,
                "icon": thumb
            }

            items.append(item)

    unique_items = deduplicate_and_sort(items)
    enriched_items = enrich_items(unique_items, limit=0)
    data = {"content_type": "movies", "items": enriched_items}
    return data

def get_image_url(url, cdn, width=None):
    if not url:
        return ""
    if url.startswith("http://") or url.startswith("https://"):
        full_url = url
    else:
        if not cdn:
            cdn = "https://phimimg.com/"
        elif not cdn.endswith("/"):
            cdn += "/"
        if url.startswith("upload/") or url.startswith("uploads/"):
            full_url = cdn + url
        else:
            full_url = cdn + "uploads/movies/" + url
    return full_url


def clean_title(title):
    if not title:
        return ""
    
    # Check if this looks like a JAV / FC2 code
    import re
    
    # Normalize underscores, dots, and spaces to hyphens/spaces for better JAV code matching
    # Strip file extension first
    name_no_ext = re.sub(r'\.(mp4|mkv|avi|ts|m2ts|iso|rar)$', '', title, flags=re.IGNORECASE)
    t_normalized = name_no_ext.replace('_', '-').replace('.', '-').replace(' ', '-')
    
    jav_code = None
    
    # 1. Look for FC2 first
    m_fc2 = re.search(r'\b(fc2(?:-?ppv)?)-?(\d{6,8})\b', t_normalized, re.IGNORECASE)
    if m_fc2:
        jav_code = f"FC2-PPV-{m_fc2.group(2)}"
    else:
        # 2. Check standard or VR JAV code: Prefix starts with letter, contains letters/numbers, followed by digit/letter-digit part
        pattern = r'\b([a-zA-Z][a-zA-Z0-9]{1,7})-(\d{1,5}|[a-zA-Z]\d{1,4})\b'
        matches = re.findall(pattern, t_normalized)
        
        ignore_prefixes = [
            'E', 'PART', 'VOL', 'EP', 'EPISODE', 'S0', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 
            '1080P', '2160P', '4K', 'FHD', 'UHD', 'HD', 'MP4', 'MKV', 'AVI', 'WEB', 'DL', 'HDR', 'FPS',
            'BLACKED', 'TUSHY', 'DEEPER', 'VIXEN', 'CUM4K', 'PRIVATE', 'PASSION', 'SHOWER4K'
        ]
        
        for prefix, num in matches:
            pref_upper = prefix.upper()
            if pref_upper not in ignore_prefixes:
                jav_code = f"{pref_upper}-{num.upper()}"
                break
                
        # 3. Check hyphenless JAV/VR code (e.g. n0232, ipzz117, ssis951)
        if not jav_code:
            m_hl = re.search(r'\b([a-zA-Z]{1,5})(\d{3,4})\b', t_normalized)
            if m_hl:
                prefix, num = m_hl.group(1), m_hl.group(2)
                pref_upper = prefix.upper()
                if pref_upper not in ignore_prefixes:
                    jav_code = f"{pref_upper}-{num}"
                
    if jav_code:
        return jav_code.lower().replace("-", " ")

    # Standard clean title logic for non-JAV movies
    import unicodedata
    title = unicodedata.normalize('NFC', title)
    t = title.lower()
    
    # Strip file extensions
    t = re.sub(r'\.(mkv|mp4|avi|srt|ts|m2ts|iso|3gp|flv|mov|wmv|mpg|mpeg|rar)$', ' ', t)
    
    # Replace special characters and punctuation with spaces
    t = re.sub(r'[^a-z0-9àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ\s]', ' ', t)
    
    # Strip parentheses and brackets contents
    t = re.sub(r'\(.*?\)|\[.*?\]', '', t)
    
    # Strip season indicators
    t = re.sub(r'\b(s\d+|ss\d+|season\s*\d+|phần\s*\d+)(?:\s*-\s*(?:s\d+|ss\d+|season\s*\d+|phần\s*\d+))?\b', '', t)
    t = re.sub(r'\b(s\d+\s*-\s*s\d+)\b', '', t)
    
    # Separate remaining letters and numbers
    t = re.sub(r'([a-zàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]+)(\d+)', r'\1 \2', t)
    t = re.sub(r'(\d+)([a-zàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]+)', r'\1 \2', t)
    
    # Strip explicit resolution/format combos
    t = re.sub(r'\bhd\s*\d*\s*p?\b', '', t)
    t = re.sub(r'\b\d+\s*p\b', '', t)
    t = re.sub(r'\b\d+\s*k\b', '', t)
    t = re.sub(r'\b(fullhd|full\s*hd)\b', '', t)
    
    # Strip release years
    t = re.sub(r'\b(19[3-9]\d|20[0-2]\d)\b', '', t)
    
    # List of noisy tags/keywords to strip
    noisy_words = [
        r'tvb\d*', r'sctv\d*', r'htv\d*', r'vtv\d*', r'mbc\d*', r'kbs\d*', r'sbs\d*', r'jtbc\d*',
        r'uslt', r'sctvlt', r'htvlt', r'ffvnlt', r'lt', r'tm', r'nf', r'netflix', 
        r'\d+\s*tập', r'\d+\s*tap', r'\d+\s*tâp', r'sangyanglt', r'sanyanglt', r'jade', r'web', r'dl', 
        r'tvbjade', r'chieurap', r'vieon', r'dsnp', r'dsnpweb', r'unrated', r'cut', r'director', 
        r'directors', r'remux', r'bluray', r'dts\s*\d*', r'h\s*264', r'x\s*264', r'hevc', r'x\s*265', 
        r'aac\s*\d*', r'ac\s*3', r'dd\s*\d*(\.\d+)?', r'ddp\s*\d*(\.\d+)?', r'atmos', r'kphung', 
        r'bomtan', r'lồng tiếng', r'thuyết minh', r'phụ đề', r'vietsub', r'trọn bộ', r'tập', r'tap', r'tâp',
        r'hdr', r'60\s*fps', r'50\s*fps', r'120\s*fps', r'3\s*d',
        r'tổng hợp', r'tong hop', r'open matte', r'openmatte',
        r'fgt', r'rarbg', r'yts', r'yify', r'sparks', r'amiable', r'wiki', r'chd', r'hdtv', r'web-dl', r'webdl',
        r'dual', r'dualaudio', r'dual-audio', r'dts-hd', r'dtshd', r'truehd', r'multi',
        r'uhd', r'ma', r'bit', r'hdr10', r'hevc', r'aac'
    ]
    noisy_pattern = r'\b(' + '|'.join(noisy_words) + r')\b'
    t = re.sub(noisy_pattern, '', t)
    
    # Strip non-year numbers of 3 or more digits
    t = re.sub(r'\b(?!(19[3-9]\d|20[0-2]\d))\d{3,}\b', '', t)
    
    # Clean special characters again
    t = re.sub(r'[^a-z0-9àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ\s]', ' ', t)
    
    # Split words, only strip single letters from the end
    words = t.split()
    while words and (
        (len(words[-1]) == 1 and words[-1].isalpha())
    ):
        words = words[:-1]
        
    return " ".join(words)


def extract_year(title):
    match = re.search(r'\b(19\d{2}|20\d{2})\b', title)
    if match:
        year = int(match.group(1))
        # Ignore future years that are likely part of the title (e.g. 2037, 2049, 2077)
        if 1930 <= year <= 2028:
            return year
    return 0


def deduplicate_and_sort(items, sort=False):
    seen_links = set()
    unique_items = []
    
    for item in items:
        path = item.get("path", "")
        parsed = urllib_parse.urlparse(path)
        qs = urllib_parse.parse_qs(parsed.query)
        fshare_link = qs.get("url", [""])[0]
        if fshare_link:
            clean_link = fshare_link.split('?')[0].split('[]')[0].rstrip('/').lower()
        else:
            clean_link = path.lower()
            
        if clean_link in seen_links:
            continue
            
        seen_links.add(clean_link)
        
        label = item.get("label", "")
        year = extract_year(label)
        if year > 0:
            if "info" not in item:
                item["info"] = {}
            item["info"]["year"] = year
            
        unique_items.append(item)
        
    if sort:
        def get_sort_key(x):
            year = x.get("info", {}).get("year", 0)
            return (-year, x.get("label", ""))
        unique_items.sort(key=get_sort_key)
        
    return unique_items

def resolve_sheet_items(start_url, recursive=True):
    items = []
    data = getdata(start_url)
    if not data or "error" in data:
        return items
        
    sub_urls = []
    for item in data.get("items", []):
        path = item.get("path", "")
        if "docs.google.com" in path:
            if recursive:
                parsed = urllib_parse.urlparse(path)
                qs = urllib_parse.parse_qs(parsed.query)
                sub_url = qs.get("url", [""])[0]
                if sub_url:
                    sub_urls.append(sub_url)
        else:
            items.append(item)
            
    if sub_urls:
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(sub_urls)) as executor:
            futures = [executor.submit(resolve_sheet_items, url, False) for url in sub_urls]
            for future in concurrent.futures.as_completed(futures):
                try:
                    sub_items = future.result()
                    items.extend(sub_items)
                except Exception:
                    pass
    return items

import hashlib
from resources import ophim_api

def bg_enrich_task(items_info, list_type=None):
    # Wait 1.0 second to allow Kodi to render the directory listing first
    time.sleep(1.0)
    for cache_key, clean_name, label in items_info:
        try:
            from resources import cache_utils
            # Double check if cache was populated in the meantime
            if cache_utils.get_cache(cache_key):
                continue
                
            meta = enrich_single_item_online(clean_name, label)
            if meta:
                cache_utils.set_cache(cache_key, meta)
                
                # Update aggregated cache file in-place if list_type is provided
                if list_type:
                    try:
                        agg_key = f"aggregated_{list_type}"
                        agg_data = cache_utils.get_cache(agg_key)
                        if agg_data and isinstance(agg_data, dict) and "items" in agg_data:
                            updated = False
                            for item in agg_data["items"]:
                                item_label = item.get("label", "")
                                item_label_no_rating = re.sub(r' - \[COLOR gold\]★ \d+\.\d+\[/COLOR\]', '', item_label)
                                item_clean = clean_title(item_label_no_rating)
                                if item_clean == clean_name:
                                    if "info" not in item:
                                        item["info"] = {}
                                    if not meta.get("not_found"):
                                        item["info"]["plot"] = meta.get("plot", "")
                                        item["info"]["rating"] = meta.get("rating", 0.0)
                                        item["info"]["genre"] = meta.get("genre", "")
                                    else:
                                        item["info"]["genre"] = ""
                                    updated = True
                                    break
                            if updated:
                                cache_utils.set_cache(agg_key, agg_data)
                    except Exception as ex:
                        logError(f"[CloudShare] Error updating aggregated cache: {ex}")
            time.sleep(0.5)
        except Exception:
            pass

import sqlite3

class SQLiteMetadataDB(object):
    def __init__(self, db_path, json_path, match_files, resources_dir):
        self.db_path = db_path
        self.json_path = json_path
        self.match_files = match_files
        self.resources_dir = resources_dir
        self.conn = None
        self._check_and_build()

    def _check_and_build(self):
        build_needed = False
        if not os.path.exists(self.db_path):
            build_needed = True
        else:
            db_mtime = os.path.getmtime(self.db_path)
            if os.path.exists(self.json_path) and os.path.getmtime(self.json_path) > db_mtime:
                build_needed = True
            else:
                for match_file in self.match_files:
                    path = os.path.join(self.resources_dir, match_file)
                    if os.path.exists(path) and os.path.getmtime(path) > db_mtime:
                        build_needed = True
                        break
        if build_needed:
            self._build_db()

    def _build_db(self):
        temp_db_path = self.db_path + ".tmp"
        if os.path.exists(temp_db_path):
            try: os.remove(temp_db_path)
            except: pass
        try:
            os.makedirs(os.path.dirname(temp_db_path), exist_ok=True)
            conn = sqlite3.connect(temp_db_path)
            cursor = conn.cursor()
            cursor.execute("CREATE TABLE IF NOT EXISTS metadata (clean_name TEXT PRIMARY KEY, val TEXT)")
            
            merged_db = {}
            if os.path.exists(self.json_path):
                with open(self.json_path, "r", encoding="utf-8") as f:
                    merged_db = json.load(f)
                    
            for match_file in self.match_files:
                path = os.path.join(self.resources_dir, match_file)
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        items = json.load(f)
                        for item in items:
                            name = item.get("name", "")
                            clean_name = clean_title(name)
                            if clean_name:
                                if clean_name not in merged_db:
                                    merged_db[clean_name] = {}
                                entry = merged_db[clean_name]
                                if "plot" not in entry and item.get("plot"):
                                    entry["plot"] = item["plot"]
                                if "plot" not in entry and item.get("content"):
                                    entry["plot"] = item["content"]
                                if "year" not in entry and item.get("year"):
                                    entry["year"] = item["year"]
                                if "poster" not in entry and item.get("poster"):
                                    entry["poster"] = item["poster"]
                                if "thumb" not in entry and item.get("thumb"):
                                    entry["thumb"] = item["thumb"]
                                if "genre" not in entry and item.get("genre"):
                                    entry["genre"] = item["genre"]
                                    
            data = []
            for k, v in merged_db.items():
                data.append((k, json.dumps(v, ensure_ascii=False)))
                
            cursor.executemany("INSERT OR REPLACE INTO metadata VALUES (?, ?)", data)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_clean_name ON metadata (clean_name)")
            conn.commit()
            conn.close()
            
            if os.path.exists(self.db_path):
                os.remove(self.db_path)
            os.rename(temp_db_path, self.db_path)
        except Exception as e:
            logError(f"[CloudShare] Error compiling SQLite DB: {e}")
            if os.path.exists(temp_db_path):
                try: os.remove(temp_db_path)
                except: pass

    def _get_connection(self):
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path, timeout=10.0)
        return self.conn

    def __contains__(self, key):
        if not key: return False
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM metadata WHERE clean_name = ?", (key,))
            return cursor.fetchone() is not None
        except Exception as e:
            logError(f"[CloudShare] SQLite contains error: {e}")
            return False

    def __getitem__(self, key):
        if not key: raise KeyError(key)
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT val FROM metadata WHERE clean_name = ?", (key,))
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
            raise KeyError(key)
        except Exception as e:
            logError(f"[CloudShare] SQLite getitem error: {e}")
            raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

_metadata_db = None

def get_metadata_db():
    global _metadata_db
    if _metadata_db is None:
        try:
            db_path = os.path.join(PROFILE_PATH, "fshare_metadata_db.db")
            json_path = os.path.join(ADDON.getAddonInfo("path"), "resources", "fshare_metadata_db.json")
            resources_dir = os.path.join(ADDON.getAddonInfo("path"), "resources")
            match_files = ["tvb_matches.json", "atv_matches.json", "kim_dung_matches.json", "anime_matches.json"]
            _metadata_db = SQLiteMetadataDB(db_path, json_path, match_files, resources_dir)
        except Exception as e:
            logError(f"[CloudShare] Failed to initialize SQLiteMetadataDB: {e}")
            _metadata_db = {}
    return _metadata_db

def enrich_single_item_online(clean_name, label):
    # Detect JAV code with underscore/dot normalization
    t_normalized = label.replace('_', '-').replace('.', '-')
    jav_code = None
    m = re.search(r'\b([a-zA-Z]{2,6}-\d{3,5})\b', t_normalized)
    if m:
        jav_code = m.group(1).upper()
    else:
        m = re.search(r'\b(fc2(?:-ppv)?-\d{6,8})\b', t_normalized, re.IGNORECASE)
        if m:
            jav_code = m.group(1).upper()
            if 'FC2' in jav_code and 'PPV' not in jav_code:
                jav_code = jav_code.replace('FC2-', 'FC2-PPV-')
        else:
            t_space = t_normalized.replace('-', ' ')
            m = re.search(r'\b([a-zA-Z]{2,6})\s+(\d{3,5})\b', t_space)
            if m:
                jav_code = f"{m.group(1).upper()}-{m.group(2)}"
            else:
                m = re.search(r'\b(fc2)\s+(ppv)?\s*(\d{6,8})\b', t_space, re.IGNORECASE)
                if m:
                    jav_code = f"FC2-PPV-{m.group(3)}"

    if jav_code:
        # Check if matched code is not generic/noisy
        code_prefix = jav_code.split('-')[0].upper()
        if code_prefix in ["GUIDE", "PART", "VOL", "EPISODE", "EP", "S0", "S1", "S2"]:
            jav_code = None
        # Run JAV metadata search & translate
        try:
            from bs4 import BeautifulSoup
            search_query = f"{jav_code}"
            search_url = f"https://search.yahoo.com/search?p={urllib_parse.quote(search_query)}"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8'
            }
            r = requests.get(search_url, headers=headers, timeout=6)
            if r.status_code == 200:
                html_decoded = urllib_parse.unquote(r.text)
                hrefs = re.findall(r'href=["\'](https?://[^"\']+)["\']', html_decoded)
                
                urls = []
                for h in hrefs:
                    if 'r.search.yahoo.com' in h and '/RU=' in h:
                        try:
                            ru_part = h.split('/RU=')[1].split('/RK=')[0]
                            ru = urllib_parse.unquote(ru_part)
                            if ru:
                                urls.append(ru)
                        except Exception:
                            pass
                    elif any(d in h for d in ['javdatabase.com', 'javbangers.com', 'javbus.com', 'twojav.com']):
                        urls.append(h)
                        
                scrape_url = None
                for u in urls:
                    if 'javdatabase.com/movies/' in u:
                        scrape_url = u
                        break
                    elif 'javbangers.com/video/' in u:
                        scrape_url = u
                        break
                        
                if not scrape_url:
                    for u in urls:
                        if any(domain in u for domain in ['javdatabase.com', 'javbangers.com', 'javbus.com', 'twojav.com']):
                            scrape_url = u
                            break
                            
                if scrape_url:
                    rd = requests.get(scrape_url, headers=headers, timeout=6)
                    if rd.status_code == 200:
                        soup = BeautifulSoup(rd.text, 'html.parser')
                        h1 = soup.find('h1')
                        title = h1.text.strip() if h1 else ""
                        if not title:
                            og_title = soup.find('meta', property='og:title')
                            title = og_title.get('content', '') if og_title else ''
                            
                        og_image = soup.find('meta', property='og:image')
                        poster_url = og_image.get('content', '') if og_image else ''
                        if poster_url and poster_url.startswith('//'):
                            poster_url = 'https:' + poster_url
                            
                        # Clean title
                        title_cleaned = title.replace(jav_code, '').replace(jav_code.replace('-', ''), '')
                        title_cleaned = re.sub(r'\|\s*JAVDatabase.*', '', title_cleaned)
                        title_cleaned = re.sub(r'-\s*JavBangers.*', '', title_cleaned)
                        title_cleaned = re.sub(r'^[\s\-_:=|]+|[\s\-_:=|]+$', '', title_cleaned).strip()
                        
                        # Translate
                        translated_title = title_cleaned
                        if title_cleaned:
                            t_url = "https://translate.googleapis.com/translate_a/single"
                            t_params = {
                                "client": "gtx",
                                "sl": "auto",
                                "tl": "vi",
                                "dt": "t",
                                "q": title_cleaned
                            }
                            try:
                                rt = requests.get(t_url, params=t_params, headers=headers, timeout=4)
                                if rt.status_code == 200:
                                    js = rt.json()
                                    translated_sentences = []
                                    for sentence in js[0]:
                                        if sentence[0]:
                                            translated_sentences.append(sentence[0])
                                    translated_title = "".join(translated_sentences)
                            except Exception:
                                pass
                                
                        plot = f"[COLOR yellow]Mã số:[/COLOR] {jav_code}\n[COLOR yellow]Tên phim:[/COLOR] {translated_title}"
                        
                        meta = {
                            "plot": plot,
                            "rating": 0.0,
                            "genre": "Phim Người Lớn, JAV",
                            "year": 0,
                            "poster": poster_url,
                            "thumb": poster_url
                        }
                        return meta
        except Exception:
            pass

    # Split by common title separators: - , | , :
    parts = [p.strip() for p in re.split(r'\s+-\s+|\s+-\s*|\||:', label) if p.strip()]
    search_terms = []
    for part in parts:
        c = clean_title(part)
        if c and len(c) > 2:
            if c not in search_terms:
                search_terms.append(c)
            # Add shortened version as fallback for long titles
            words = c.split()
            if len(words) > 3:
                short_term = " ".join(words[:2]) # first 2 words
                if len(short_term) > 2 and short_term not in search_terms:
                    search_terms.append(short_term)
                short_term_3 = " ".join(words[:3]) # first 3 words
                if len(short_term_3) > 2 and short_term_3 not in search_terms:
                    search_terms.append(short_term_3)
    if clean_name not in search_terms:
        search_terms.append(clean_name)
        words = clean_name.split()
        if len(words) > 3:
            short_term = " ".join(words[:2])
            if len(short_term) > 2 and short_term not in search_terms:
                search_terms.append(short_term)
            short_term_3 = " ".join(words[:3])
            if len(short_term_3) > 2 and short_term_3 not in search_terms:
                search_terms.append(short_term_3)

    try:
        import remove_accents
    except ImportError:
        class MockRemoveAccents:
            @staticmethod
            def remove_accents(s):
                s1 = u'ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠạẢảẤấẦầẨẩẪẫẬậẮắẰằẲẳẴẵẶặẸẹẺẻẼẽẾếỀềỂểỄễỆệỈỉỊịỌọỎỏỐốỒồỔổỖỗỘộỚớỜờỞởỠỡỢợỤụỦủỨứỪừỬửỮữỰựỲỳỴỵỶỷỸỹ'
                s0 = u'AAAAEEEIIOOOOUUYaaaaeeeiioooouuyAaDdIiUuOoUuAaAaAaAaAaAaAaAaAaAaAaAaEeEeEeEeEeEeEeEeIiIiOoOoOoOoOoOoOoOoOoOoOoOoUuUuUuUuUuUuUuYyYyYyYy'
                res = ''
                for char in s:
                    if char in s1:
                        res += s0[s1.index(char)]
                    else:
                        res += char
                return res
        remove_accents = MockRemoveAccents()
    
    def match_title_overlap(clean_original, name_vn, name_en):
        orig_words = set(remove_accents.remove_accents(clean_original.lower()).split())
        stop_words = {'va', 'and', 'the', 'of', 'phan', 'part', 'co', 'cua', 'so', 'u', 'ii', 'i', 'iii', 'iv', 'v'}
        orig_filtered = orig_words - stop_words
        if not orig_filtered:
            return False
            
        for candidate in [name_vn, name_en]:
            if not candidate:
                continue
            cand_words = set(remove_accents.remove_accents(candidate.lower()).split())
            cand_filtered = cand_words - stop_words
            if not cand_filtered:
                continue
                
            intersection = orig_filtered.intersection(cand_filtered)
            if not intersection:
                continue
                
            # If either is a subset of the other, it's a match (ensure at least 1 word matches, or 2 if length is short)
            if orig_filtered.issubset(cand_filtered) or cand_filtered.issubset(orig_filtered):
                if any(len(w) > 2 for w in intersection):
                    return True
                    
            ratio_orig = len(intersection) / len(orig_filtered)
            ratio_cand = len(intersection) / len(cand_filtered)
            
            # If the intersection is high relative to either title
            if ratio_orig >= 0.5 or ratio_cand >= 0.5:
                if len(intersection) >= 2 or any(len(w) > 3 for w in intersection):
                    return True
        return False

    for search_term in search_terms:
        # Search PhimAPI
        try:
            search_url = f"https://phimapi.com/v1/api/tim-kiem?keyword={urllib_parse.quote(search_term)}&limit=5"
            r = requests.get(search_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
            if r.status_code == 200:
                search_res = r.json()
                data = search_res.get('data')
                items = (data.get('items') if data else []) or []
                for item in items:
                    m_title_vn = remove_accents.remove_accents(item.get("name", "").lower())
                    m_title_en = remove_accents.remove_accents(item.get("origin_name", "").lower())
                    if match_title_overlap(clean_name, m_title_vn, m_title_en):
                        slug = item.get("slug")
                        if slug:
                            detail_url = f"https://phimapi.com/phim/{slug}"
                            rd = requests.get(detail_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
                            if rd.status_code == 200:
                                detail_res = rd.json()
                                if detail_res and detail_res.get("movie"):
                                    movie_detail = detail_res["movie"]
                                    
                                    # Genres & countries
                                    genres = []
                                    categories = movie_detail.get("category", [])
                                    if isinstance(categories, list):
                                        for cat in categories:
                                            if isinstance(cat, dict) and cat.get("name"):
                                                genres.append(cat.get("name").strip())
                                                
                                    countries = movie_detail.get("country", [])
                                    if isinstance(countries, list):
                                        for c in countries:
                                            if isinstance(c, dict) and c.get("name"):
                                                cname = c.get("name").strip()
                                                if cname:
                                                    genres.append(cname)
                                                    
                                    plot = movie_detail.get("content", "")
                                    plot = re.sub(r'<[^>]*>', '', plot).strip()
                                    
                                    rating = 0.0
                                    try:
                                        tmdb = movie_detail.get("tmdb")
                                        if isinstance(tmdb, dict):
                                            rating = float(tmdb.get("vote_average", 0.0))
                                    except:
                                        pass
                                        
                                    year = 0
                                    try:
                                        year = int(movie_detail.get("year", 0))
                                    except:
                                        pass
                                        
                                    meta = {
                                        "plot": plot,
                                        "rating": rating,
                                        "genre": ", ".join(genres),
                                        "year": year,
                                        "poster": get_image_url(movie_detail.get("poster_url", ""), "https://img.phimapi.com/", width=300),
                                        "thumb": get_image_url(movie_detail.get("thumb_url", ""), "https://img.phimapi.com/", width=300)
                                    }
                                    return meta
        except Exception:
            pass

        # Search NguonC
        try:
            search_url = f"https://phim.nguonc.com/api/films/search?keyword={urllib_parse.quote(search_term)}"
            r = requests.get(search_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
            if r.status_code == 200:
                search_res = r.json()
                items = search_res.get('items') or []
                for item in items:
                    m_title_vn = remove_accents.remove_accents(item.get("name", "").lower())
                    m_title_en = remove_accents.remove_accents(item.get("origin_name", "").lower())
                    if match_title_overlap(clean_name, m_title_vn, m_title_en):
                        slug = item.get("slug")
                        if slug:
                            detail_url = f"https://phim.nguonc.com/api/film/{slug}"
                            rd = requests.get(detail_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
                            if rd.status_code == 200:
                                detail_res = rd.json()
                                if detail_res and detail_res.get("movie"):
                                    movie_detail = detail_res["movie"]
                                    genres = []
                                    category_data = movie_detail.get("category", {})
                                    if isinstance(category_data, dict):
                                        for group_key, group_val in category_data.items():
                                            group_name = group_val.get("group", {}).get("name", "")
                                            if group_name in ["Thể loại", "Quốc gia"]:
                                                for cat in group_val.get("list", []):
                                                    if cat.get("name"):
                                                        genres.append(cat.get("name").strip())
                                                        
                                    plot = movie_detail.get("description") or ""
                                    plot = re.sub(r'<[^>]*>', '', plot).strip()
                                    
                                    year = 0
                                    try:
                                        year = int(movie_detail.get("year", 0))
                                    except:
                                        pass
                                        
                                    meta = {
                                        "plot": plot,
                                        "rating": 0.0,
                                        "genre": ", ".join(genres),
                                        "year": year,
                                        "poster": get_image_url(movie_detail.get("poster_url", ""), "https://img.phimapi.com/", width=300),
                                        "thumb": get_image_url(movie_detail.get("thumb_url", ""), "https://img.phimapi.com/", width=300)
                                    }
                                    return meta
        except Exception:
            pass

    # Web search fallback using Yahoo & TMDB scraping
    for search_term in search_terms:
        try:
            from bs4 import BeautifulSoup
            search_query = f"{search_term} site:themoviedb.org"
            search_url = f"https://search.yahoo.com/search?p={urllib_parse.quote(search_query)}"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8'
            }
            r = requests.get(search_url, headers=headers, timeout=6)
            if r.status_code == 200:
                html_decoded = urllib_parse.unquote(r.text)
                urls = re.findall(r'https://(?:www\.)?themoviedb\.org/(?:movie|tv)/\d+[^"\'\s&?]*', html_decoded)
                tmdb_url = None
                if urls:
                    match = re.search(r'(https://www\.themoviedb\.org/(?:movie|tv)/\d+[^/?&]*)', urls[0])
                    if match:
                        tmdb_url = match.group(1)
                
                if tmdb_url:
                    rd = requests.get(tmdb_url, headers=headers, timeout=6)
                    if rd.status_code == 200:
                        soup_detail = BeautifulSoup(rd.text, 'html.parser')
                        og_image = soup_detail.find('meta', property='og:image')
                        og_title = soup_detail.find('meta', property='og:title')
                        og_desc = soup_detail.find('meta', property='og:description')
                        
                        poster_url = og_image.get('content', '') if og_image else ''
                        title = og_title.get('content', '') if og_title else ''
                        plot = og_desc.get('content', '') if og_desc else ''
                        
                        year = 0
                        tag_release = soup_detail.find('span', class_='tag release_date')
                        if tag_release:
                            year_match = re.search(r'\(?(\d{4})\)?', tag_release.text)
                            if year_match:
                                year = int(year_match.group(1))
                                
                        if year == 0:
                            for h2 in soup_detail.find_all('h2'):
                                year_match = re.search(r'\((\d{4})\)', h2.text)
                                if year_match:
                                    year = int(year_match.group(1))
                                    break
                                    
                        if year == 0:
                            year_match = re.search(r'class="tag release_date"[^>]*>.*?(\d{4})', rd.text)
                            if year_match:
                                year = int(year_match.group(1))
                                
                        genres = []
                        genres_span = soup_detail.find('span', class_='genres')
                        if genres_span:
                            genres = [g.text.strip() for g in genres_span.find_all('a')]
                            
                        title_cleaned = re.sub(r'\s*—\s*The Movie Database.*', '', title)
                        title_cleaned = re.sub(r'\s*—\s*TMDb.*', '', title_cleaned).strip()
                        
                        meta = {
                            "plot": plot.strip(),
                            "rating": 0.0,
                            "genre": ", ".join(genres) if genres else "Phim",
                            "year": year,
                            "poster": poster_url,
                            "thumb": poster_url
                        }
                        return meta
        except Exception:
            pass

    return {"not_found": True}

def enrich_items(items, limit=40, list_type=None):
    if not items:
        return []
        
    from resources import cache_utils
    import hashlib
    import concurrent.futures
    
    db = get_metadata_db()
    to_query_map = {}
    
    for item in items:
        path = item.get("path", "")
        if "action=play" not in path:
            continue
            
        if not item.get("is_playable"):
            continue
            
        label = item.get("label", "")
        label_no_rating = re.sub(r' - \[COLOR gold\]★ \d+\.\d+\[/COLOR\]', '', label)
        clean_name = clean_title(label_no_rating)
        if not clean_name:
            continue
            
        cache_key = "match_meta_v2_%s" % hashlib.md5(clean_name.encode('utf-8')).hexdigest()
        cached_meta = cache_utils.get_cache(cache_key)
        
        if not cached_meta and db and clean_name in db:
            cached_meta = db[clean_name]
            cache_utils.set_cache(cache_key, cached_meta)
            
        if cached_meta:
            if "info" not in item:
                item["info"] = {}
            if cached_meta.get("not_found"):
                item["info"]["genre"] = ""
                continue
            if cached_meta.get("plot"):
                item["info"]["plot"] = cached_meta["plot"]
            if cached_meta.get("rating"):
                item["info"]["rating"] = cached_meta["rating"]
            item["info"]["genre"] = cached_meta.get("genre", "")
            
            if cached_meta.get("director"):
                item["info"]["director"] = cached_meta["director"]
            if cached_meta.get("cast"):
                item["info"]["cast"] = cached_meta["cast"]
            if cached_meta.get("studio"):
                item["info"]["studio"] = cached_meta["studio"]
                
            if cached_meta.get("year"):
                item["info"]["year"] = int(cached_meta["year"])
            else:
                year = extract_year(label_no_rating)
                if year > 0:
                    item["info"]["year"] = year
                    
            thumb = cached_meta.get("thumb") or cached_meta.get("thumbnail")
            poster = cached_meta.get("poster")
            
            if thumb:
                item["thumbnail"] = thumb
                item["icon"] = thumb
                if "art" not in item:
                    item["art"] = {}
                item["art"]["thumb"] = thumb
                item["art"]["icon"] = thumb
                
            if poster:
                if "art" not in item:
                    item["art"] = {}
                item["art"]["poster"] = poster
                if not item.get("thumbnail"):
                    item["thumbnail"] = poster
                    item["icon"] = poster
        else:
            if cache_key not in to_query_map:
                to_query_map[cache_key] = []
            to_query_map[cache_key].append((item, clean_name, label_no_rating))

    # Perform background online search for unique missing items (max 15 unique queries per folder load)
    # and return immediately with default metadata to avoid freezing the UI thread
    if to_query_map:
        unique_queries = []
        for cache_key, entries in to_query_map.items():
            item, clean_name, label_no_rating = entries[0]
            unique_queries.append((cache_key, clean_name, label_no_rating))
            
        # Limit to 15 unique queries per folder load to prevent server spam
        query_batch = unique_queries[:15]
        
        # Populate default info for missing items to keep UI snappy
        for cache_key in to_query_map:
            for item, clean_name, label_no_rating in to_query_map[cache_key]:
                if "info" not in item:
                    item["info"] = {}
                item["info"]["genre"] = ""
                year = extract_year(label_no_rating)
                if year > 0:
                    item["info"]["year"] = year

        # Run background enrichment asynchronously
        try:
            t = threading.Thread(target=bg_enrich_task, args=(query_batch, list_type))
            t.daemon = True
            t.start()
        except Exception as e:
            logError(f"[CloudShare] Failed to start background enrichment thread: {e}")

    return items


def get_dead_blacklist():
    from resources.lib.constants import CACHE_PATH
    blacklist_path = os.path.join(CACHE_PATH, "dead_fshare_urls.json")
    if not os.path.exists(blacklist_path):
        # Fallback to seed blacklist in resources folder if cache doesn't exist yet
        try:
            from .addon import ADDON_PATH
            seed_path = os.path.join(ADDON_PATH, "resources", "dead_fshare_urls.json")
            if os.path.exists(seed_path):
                with open(seed_path, "r", encoding="utf-8") as f:
                    return set(json.load(f))
        except Exception:
            pass
        return set()
    try:
        with open(blacklist_path, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except Exception:
        return set()

def add_to_dead_blacklist(url):
    from resources.lib.constants import CACHE_PATH
    blacklist_path = os.path.join(CACHE_PATH, "dead_fshare_urls.json")
    try:
        dead_urls = list(get_dead_blacklist())
        if url not in dead_urls:
            dead_urls.append(url)
            with open(blacklist_path, "w", encoding="utf-8") as f:
                json.dump(dead_urls, f, indent=4, ensure_ascii=False)
            
            # Update cache file dynamically so the UI changes immediately
            from resources import cache_utils
            for cache_key in ["aggregated_phimle", "aggregated_phimbo"]:
                data = cache_utils.get_cache(cache_key)
                if data and data.get("items"):
                    filtered = []
                    for item in data["items"]:
                        p = item.get("path", "")
                        if "url=" in p:
                            u = p.split("url=")[1].split("&")[0]
                            if u == url:
                                continue
                        filtered.append(item)
                    data["items"] = filtered
                    cache_utils.set_cache(cache_key, data)
            return True
    except Exception as e:
        logError(f"Error adding {url} to dead blacklist: {e}")
    return False

def filter_dead_links(items):
    dead_urls = get_dead_blacklist()
    if not dead_urls:
        return items
    filtered = []
    for item in items:
        p = item.get("path", "")
        if "url=" in p:
            u = p.split("url=")[1].split("&")[0]
            if u in dead_urls:
                continue
        filtered.append(item)
    return filtered

def get_aggregated_phimle():
    cache_key = "aggregated_phimle"
    from resources import cache_utils
    if cache_utils.check_cache(cache_key, max_age_minutes=720):
        data = cache_utils.get_cache(cache_key)
        if data and data.get("items"):
            data["items"] = filter_dead_links(data["items"])
            data["items"] = enrich_items(data["items"], limit=40, list_type="phimle")
            return data
            
    urls = [
        'https://docs.google.com/spreadsheets/d/1D3UoGVSJwKp11fpZU9TQjIORFMViF1TFu-BQdGqmB3o/gviz/tq?gid=0&headers=1',
        'https://docs.google.com/spreadsheets/d/1MUofoMzCbElPAv0oFmruPzm6IXKoBWWcCwoDaLtLPGo/gviz/tq?gid=0&headers=1'
    ]
    
    all_items = []
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(urls)) as executor:
        futures = [executor.submit(resolve_sheet_items, url, False) for url in urls]
        for future in concurrent.futures.as_completed(futures):
            try:
                all_items.extend(future.result())
            except Exception:
                pass
        
    unique_items = deduplicate_and_sort(all_items)
    # Check cache globally and queue up to 40 uncached items for background crawl
    enriched_items = enrich_items(unique_items, limit=40, list_type="phimle")
    filtered_items = filter_dead_links(enriched_items)
    data = {"content_type": "movies", "items": filtered_items}
    cache_utils.set_cache(cache_key, data)
    return data

def get_aggregated_phimbo():
    cache_key = "aggregated_phimbo"
    from resources import cache_utils
    if cache_utils.check_cache(cache_key, max_age_minutes=720):
        data = cache_utils.get_cache(cache_key)
        if data and data.get("items"):
            data["items"] = filter_dead_links(data["items"])
            data["items"] = enrich_items(data["items"], limit=40, list_type="phimbo")
            return data
            
    urls = [
        'https://docs.google.com/spreadsheets/d/1P4pFV7x260xdMGt81fx_P9d5zUmPWCzhKRLjJgajrtY/gviz/tq?gid=0&headers=1',
        'https://docs.google.com/spreadsheets/d/1s1q4_2j-cG49OyOv6Ql3rQgAcf2kLFNDP-mOoBk8Xlo/gviz/tq?gid=799718870&headers=1',
        'https://docs.google.com/spreadsheets/d/1S6iSi0tWvqKVk5en2NDx9N5XeDquwOWh4GlGKIEezyo/gviz/tq?gid=482627435&headers=1'
    ]
    
    all_items = []
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(urls)) as executor:
        futures = [executor.submit(resolve_sheet_items, url, "kphung" not in url) for url in urls]
        for future in concurrent.futures.as_completed(futures):
            try:
                all_items.extend(future.result())
            except Exception:
                pass
        
    unique_items = deduplicate_and_sort(all_items)
    # Check cache globally and queue up to 40 uncached items for background crawl
    enriched_items = enrich_items(unique_items, limit=40, list_type="phimbo")
    filtered_items = filter_dead_links(enriched_items)
    data = {"content_type": "tvshows", "items": filtered_items}
    cache_utils.set_cache(cache_key, data)
    return data

def get_fshare_genres():
    data_le = get_aggregated_phimle()
    data_bo = get_aggregated_phimbo()
    items = data_le.get("items", []) + data_bo.get("items", [])
    genres = set()
    for item in items:
        genre_str = item.get("info", {}).get("genre", "")
        if genre_str:
            parts = re.split(r'[,/|]', genre_str)
            for p in parts:
                clean_p = p.strip()
                if clean_p:
                    genres.add(clean_p.title())
    return sorted(list(genres))

def run_bulk_link_cleanup():
    import xbmcgui, xbmc
    import concurrent.futures
    import urllib.request
    
    dialog = xbmcgui.Dialog()
    if not dialog.yesno("Quét Link Chết", "Bạn có muốn quét toàn bộ danh sách Fshare để loại bỏ các thư mục/tập tin bị lỗi không?\nQuá trình này chạy đa luồng và mất khoảng 1-2 phút."):
        return
        
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('CloudShare', 'Đang thu thập link Fshare từ cache...')
    
    # 1. Collect unique URLs from local cache
    urls = set()
    from resources import cache_utils
    from resources.lib.constants import CACHE_PATH
    
    for filename in ["aggregated_phimle", "aggregated_phimbo"]:
        data = cache_utils.get_cache(filename)
        if data and data.get("items"):
            for item in data["items"]:
                p = item.get("path", "")
                if "url=" in p:
                    u = p.split("url=")[1].split("&")[0]
                    if "fshare.vn" in u:
                        urls.add(u)
                        
    unique_urls = sorted(list(urls))
    total_urls = len(unique_urls)
    if total_urls == 0:
        pDialog.close()
        dialog.ok("Thông báo", "Không tìm thấy dữ liệu cache Fshare nào để quét. Hãy mở danh sách Phim Fshare trước.")
        return
        
    pDialog.update(0, f"Đang quét 0/{total_urls} links...")
    
    dead_urls = []
    checked_count = 0
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    def check_url_status(url):
        for attempt in range(2):
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=5) as response:
                    html = response.read().decode('utf-8', errors='ignore')
                    
                    dead_markers = [
                        "Thư mục không tồn tại",
                        "Tập tin không tồn tại",
                        "đã bị xóa",
                        "Filenotfound-01.png",
                        "Not Found (#404)",
                        "Thư mục của bạn yêu cầu không tồn tại",
                        "Tập tin của bạn yêu cầu không tồn tại"
                    ]
                    
                    if any(marker in html for marker in dead_markers):
                        return url, False
                    return url, True
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    return url, False
                time.sleep(0.5)
            except Exception:
                time.sleep(0.5)
        return url, True
        
    # We will use ThreadPoolExecutor to check concurrently (limit to 4 workers to prevent IP rate-limiting)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        future_to_url = {executor.submit(check_url_status, url): url for url in unique_urls}
        
        for future in concurrent.futures.as_completed(future_to_url):
            if pDialog.iscanceled():
                break
                
            checked_count += 1
            percent = int((checked_count / total_urls) * 100)
            pDialog.update(percent, f"Đang quét {checked_count}/{total_urls} links...\nĐã tìm thấy {len(dead_urls)} link chết.")
            
            try:
                url, is_live = future.result()
                if not is_live:
                    dead_urls.append(url)
            except Exception:
                pass
                
    pDialog.close()
    
    # Save dead links to blacklist
    if dead_urls:
        blacklist_path = os.path.join(CACHE_PATH, "dead_fshare_urls.json")
        existing_dead = list(get_dead_blacklist())
        updated_dead = list(set(existing_dead + dead_urls))
        
        try:
            with open(blacklist_path, "w", encoding="utf-8") as f:
                json.dump(updated_dead, f, indent=4, ensure_ascii=False)
                
            # Filter the current cache files
            for cache_key in ["aggregated_phimle", "aggregated_phimbo"]:
                data = cache_utils.get_cache(cache_key)
                if data and data.get("items"):
                    filtered = []
                    for item in data["items"]:
                        p = item.get("path", "")
                        if "url=" in p:
                            u = p.split("url=")[1].split("&")[0]
                            if u in updated_dead:
                                continue
                        filtered.append(item)
                    data["items"] = filtered
                    cache_utils.set_cache(cache_key, data)
        except Exception as e:
            dialog.ok("Lỗi", f"Không thể lưu kết quả quét: {e}")
            return
            
    dialog.ok("Hoàn tất", f"Đã hoàn thành quét {checked_count} links.\nĐã phát hiện và dọn dẹp {len(dead_urls)} link chết khỏi danh sách.")
    xbmc.executebuiltin("Container.Refresh")