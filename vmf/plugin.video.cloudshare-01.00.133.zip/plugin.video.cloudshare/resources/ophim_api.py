import json
import urllib.parse
import urlquick
import xbmc

OPHIM_API_BASE = "https://phimapi.com"
OPHIM_IMAGE_CDN = "https://phimimg.com"

def get_movies_list(endpoint="danh-sach/phim-moi-cap-nhat", page=1):
    parts = endpoint.split('?', 1)
    base = parts[0]
    query = f"?{parts[1]}" if len(parts) > 1 else ""

    if base.startswith("v1/api/"):
        pass
    elif base == "phim-moi-cap-nhat":
        base = "danh-sach/phim-moi-cap-nhat"
    elif base in ["phim-bo", "phim-le", "hoat-hinh", "tv-shows", "phim-chieu-rap"]:
        base = f"v1/api/danh-sach/{base}"
    elif base.startswith("the-loai/") or base.startswith("quoc-gia/"):
        base = f"v1/api/{base}"

    endpoint = f"{base}{query}"
    sep = "&" if "?" in endpoint else "?"
    url = f"{OPHIM_API_BASE}/{endpoint}{sep}page={page}"
    try:
        # Cache danh sách phim trong 15 phút (900 giây) để giảm tải và tăng tốc
        response = urlquick.get(url, max_age=900, timeout=3)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == True or data.get("status") == "success":
                if "data" in data and "items" in data["data"]:
                    cdn = data["data"].get("APP_DOMAIN_CDN_IMAGE", OPHIM_IMAGE_CDN)
                    if cdn and not cdn.endswith("/"):
                        cdn += "/"
                    return data["data"]["items"], cdn
                else:
                    cdn = data.get("pathImage", OPHIM_IMAGE_CDN)
                    if cdn and not cdn.endswith("/"):
                        cdn += "/"
                    return data.get("items", []), cdn
    except Exception as e:
        xbmc.log(f"[CloudShare] Ophim API Error (get_movies_list): {e}", xbmc.LOGERROR)
    return [], OPHIM_IMAGE_CDN

def search_movies(keyword, page=1):
    url = f"{OPHIM_API_BASE}/v1/api/tim-kiem?keyword={urllib.parse.quote(keyword)}&page={page}"
    try:
        # Cache kết quả tìm kiếm trong 5 phút (300 giây)
        response = urlquick.get(url, max_age=300, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success" or data.get("status") == True:
                cdn = data.get("data", {}).get("APP_DOMAIN_CDN_IMAGE", OPHIM_IMAGE_CDN)
                if cdn and not cdn.endswith("/"):
                    cdn += "/"
                return data.get("data", {}).get("items", []), cdn
    except Exception as e:
        xbmc.log(f"[CloudShare] Ophim API Error (search_movies): {e}", xbmc.LOGERROR)
        return None, OPHIM_IMAGE_CDN
    return [], OPHIM_IMAGE_CDN

def get_movie_detail(slug):
    url = f"{OPHIM_API_BASE}/phim/{slug}"
    try:
        # Cache chi tiết phim và tập phim trong 12 giờ (43200 giây)
        response = urlquick.get(url, max_age=43200, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get("status"):
                return data.get("movie", {}), data.get("episodes", [])
    except Exception as e:
        xbmc.log(f"[CloudShare] Ophim API Error (get_movie_detail): {e}", xbmc.LOGERROR)
        return None, []
    return {}, []

def get_m3u8_links(slug):
    movie, episodes = get_movie_detail(slug)
    links = []
    if episodes and len(episodes) > 0:
        for ep in episodes:
            server_name = ep.get("server_name", "Default")
            server_data = ep.get("server_data", [])
            for sd in server_data:
                links.append({
                    "name": sd.get("name", "1"),
                    "link": sd.get("link_m3u8", ""),
                    "filename": sd.get("filename", ""),
                    "server": server_name
                })
    return links

def get_genres():
    url = f"{OPHIM_API_BASE}/the-loai"
    try:
        response = urlquick.get(url, max_age=86400, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, dict) and "value" in data:
                return [(item.get("name"), item.get("slug")) for item in data["value"]]
    except Exception as e:
        xbmc.log(f"[CloudShare] Error fetching genres: {e}", xbmc.LOGERROR)
    return []

def get_countries():
    url = f"{OPHIM_API_BASE}/quoc-gia"
    try:
        response = urlquick.get(url, max_age=86400, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, dict) and "value" in data:
                return [(item.get("name"), item.get("slug")) for item in data["value"]]
    except Exception as e:
        xbmc.log(f"[CloudShare] Error fetching countries: {e}", xbmc.LOGERROR)
    return []
