import os
import time
import xbmc
import xbmcaddon
from datetime import datetime, timedelta
from resources.lib.constants import CACHE_PATH

ADDON = xbmcaddon.Addon()

def should_clear_cache():
    """Kiểm tra xem có nên xóa cache hay không dựa trên cài đặt và thời gian"""
    if not ADDON.getSettingBool('auto_clear_cache'):
        return False

    last_cleanup = ADDON.getSetting('last_cache_cleanup')
    if not last_cleanup:
        return True

    try:
        last_cleanup_time = datetime.strptime(last_cleanup, '%Y-%m-%d %H:%M:%S')
        expiry_days = int(ADDON.getSetting('cache_expiry_days'))
        next_cleanup = last_cleanup_time + timedelta(days=expiry_days)
        return datetime.now() >= next_cleanup
    except (ValueError, TypeError):
        return True

def clear_old_cache():
    """Xóa các file cache cũ hơn số ngày được cấu hình"""
    if not os.path.exists(CACHE_PATH):
        return

    try:
        expiry_days = int(ADDON.getSetting('cache_expiry_days'))
        now = time.time()
        cutoff = now - (expiry_days * 86400)  # 86400 giây = 1 ngày
        files_removed = 0
        total_size = 0

        for filename in os.listdir(CACHE_PATH):
            file_path = os.path.join(CACHE_PATH, filename)
            if os.path.isfile(file_path):
                file_mtime = os.path.getmtime(file_path)
                if file_mtime < cutoff:
                    try:
                        file_size = os.path.getsize(file_path)
                        os.remove(file_path)
                        files_removed += 1
                        total_size += file_size
                        xbmc.log(f"[CloudShare] Đã xóa cache: {filename}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[CloudShare] Lỗi khi xóa cache {filename}: {str(e)}", xbmc.LOGERROR)

        # Cập nhật thời gian xóa cache cuối cùng
        ADDON.setSetting('last_cache_cleanup', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

        if files_removed > 0:
            total_size_mb = total_size / (1024 * 1024)  # Chuyển đổi sang MB
            xbmc.log(f"[CloudShare] Đã xóa {files_removed} file cache (tổng {total_size_mb:.2f}MB)", xbmc.LOGINFO)
            xbmc.executebuiltin(f'Notification(CloudShare, Đã xóa {files_removed} file cache cũ ({total_size_mb:.2f}MB), 5000)')

    except Exception as e:
        xbmc.log(f"[CloudShare] Lỗi khi xóa cache: {str(e)}", xbmc.LOGERROR)
        xbmc.executebuiltin('Notification(CloudShare, Lỗi khi xóa cache cũ, 5000)')

def check_and_clear_cache():
    """Kiểm tra và xóa cache nếu cần thiết"""
    # Xóa toàn bộ cache nếu nâng cấp phiên bản addon
    current_version = ADDON.getAddonInfo('version')
    saved_version = ADDON.getSetting('version')
    if current_version != saved_version:
        xbmc.log(f"[CloudShare] Addon updated from {saved_version} to {current_version}. Clearing all cache...", xbmc.LOGINFO)
        from resources.lib.constants import PROFILE_PATH
        # Xóa file sqlite của urlquick
        try:
            p = os.path.join(PROFILE_PATH, ".urlquick.slite3")
            if os.path.exists(p):
                os.remove(p)
                xbmc.log(f"[CloudShare] Deleted cached database: {p}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[CloudShare] Error deleting cached database: {e}", xbmc.LOGERROR)
            
        # Xóa các file cache trong thư mục cache
        if os.path.exists(CACHE_PATH):
            for filename in os.listdir(CACHE_PATH):
                file_path = os.path.join(CACHE_PATH, filename)
                if os.path.isfile(file_path):
                    try:
                        os.remove(file_path)
                    except Exception:
                        pass
        
        # Cập nhật cài đặt phiên bản mới
        ADDON.setSetting('version', current_version)
        xbmc.executebuiltin('Notification(CloudShare, Đã xóa toàn bộ cache nâng cấp phiên bản!, 5000)')

    if should_clear_cache():
        clear_old_cache() 