#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import html
import json
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import urlquick
import sys
import getlink

try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = 0

from resources.addon import ADDON, alert, notify, ADDON_PATH
from resources import fshare
from resources.collection_utils import vfs_join, vfs_mkdirs, vfs_listdir, clean_filename, vfs_open, add_folder_recursive

# Load Cine domain dynamically using the auto-healing domain resolver
from resources import domain_resolver
CINE_HOST = domain_resolver.resolve_domain('thuviencine', 'thuviencine.xyz')
CINE_DOMAIN = f"https://{CINE_HOST}"

# Modern browser User-Agent to avoid issues
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': f'{CINE_DOMAIN}/'
}

def get_tvcine_menu():
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    
    items = [
        {
            "label": "[COLOR gold][B]Phim Mới Cập Nhật[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": f"Các phim mới cập nhật trên {CINE_HOST}"
        },
        {
            "label": "[COLOR yellow][B]Xu Hướng Phim (Trending)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/top/')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim đang thịnh hành và xem nhiều"
        },
        {
            "label": "[COLOR lightskyblue][B]Phim Đề Xuất (Đánh giá cao)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/?order=rating')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Phim có điểm đánh giá cao nhất"
        },
        {
            "label": "[COLOR gold][B]Phim Bộ TVB Hồng Kông[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_tvb_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim truyền hình bộ đài TVB Hồng Kông"
        },
        {
            "label": "[COLOR gold][B]Kiếm Hiệp Kim Dung & TVB Cổ Điển[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_kim_dung",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim kiếm hiệp Kim Dung và TVB cổ điển chọn lọc"
        },
        {
            "label": "[COLOR orchid][B]Phim Lẻ[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_phimle_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Phim lẻ Fshare chất lượng cao"
        },
        {
            "label": "[COLOR springgreen][B]Phim Bộ[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_phimbo_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Phim bộ dài tập Fshare"
        },
        {
            "label": "[COLOR lightskyblue][B]Phân Loại Thể Loại Phim[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_genres_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Phân loại phim theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_years_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Duyệt tìm phim theo năm sản xuất"
        },
        {
            "label": "[COLOR hotpink][B]Tìm Kiếm Phim[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_search",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim trên Thư Viện Cine"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_tvb_menu():
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Bộ TVB Hồng Kông[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/country/hong-kong/')}&filter_type=tvb",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Xem toàn bộ phim bộ truyền hình đài TVB Hồng Kông"
        },
        {
            "label": "[COLOR gold][B]Phim Kiếm Hiệp TVB (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=fshare_special_json_list&file=fshare_kim_dung_matches.json&page=1",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tuyển tập phim kiếm hiệp Kim Dung đài TVB Hồng Kông (Fshare)"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_years_menu&filter_type=tvb",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim bộ TVB Hồng Kông theo năm sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_phimle_menu():
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Lẻ[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/movies/')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Xem toàn bộ phim lẻ Fshare chất lượng cao"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Thể Loại[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_genres_menu&filter_type=phim-le",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim lẻ theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_years_menu&filter_type=phim-le",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim lẻ theo năm sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_phimbo_menu():
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Bộ[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/tv-series/')}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Xem toàn bộ phim bộ dài tập Fshare"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Thể Loại[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_genres_menu&filter_type=series",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim bộ theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_years_menu&filter_type=series",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Tìm phim bộ theo năm sản xuất"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Quốc Gia[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=tvcine_phimbo_countries_menu",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Xem phim bộ phân loại theo các quốc gia sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_phimbo_countries_menu():
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    countries = [
        ("Phim Bộ Hàn Quốc", "south-korea"),
        ("Phim Bộ Mỹ", "united-states"),
        ("Phim Bộ Trung Quốc", "china"),
        ("Phim Bộ Hồng Kông", "hong-kong"),
        ("Phim Bộ Nhật Bản", "japan"),
        ("Phim Bộ Đài Loan", "taiwan"),
        ("Phim Bộ Thái Lan", "thailand"),
        ("Phim Bộ Anh", "united-kingdom"),
        ("Phim Bộ Pháp", "france"),
        ("Phim Bộ Tây Ban Nha", "spain"),
        ("Phim Bộ Thổ Nhĩ Kỳ", "turkey"),
        ("Phim Bộ Canada", "canada"),
        ("Phim Bộ Việt Nam", "vietnam"),
        ("Phim Bộ Ấn Độ", "india")
    ]
    items = []
    for name, slug in countries:
        items.append({
            "label": f"[COLOR gold][B]{name}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/country/' + slug + '/')}&filter_type=series",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": f"Phim bộ {name}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_genres_menu(filter_type=None):
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    genres = [
        ("Phim Hành Động", "phim-hanh-dong"),
        ("Phim Khoa Học Viễn Tưởng", "phim-khoa-hoc-vien-tuong"),
        ("Phim Kinh Dị", "phim-kinh-di"),
        ("Phim Hài Hước", "phim-hai"),
        ("Phim Chiến Tranh", "phim-chien-tranh"),
        ("Phim Chính Kịch", "phim-chinh-kich"),
        ("Phim Gia Đình", "phim-gia-dinh"),
        ("Phim Giả Tượng / Thần Thoại", "phim-gia-tuong"),
        ("Phim Gây Cấn", "phim-gay-can"),
        ("Phim Hình Sự", "phim-hinh-su"),
        ("Phim Hoạt Hình", "phim-hoat-hinh"),
        ("Phim Bí Ẩn / Trinh Thám", "phim-bi-an"),
        ("Phim Lãng Mạn / Tình Cảm", "phim-lang-man"),
        ("Phim Lịch Sử", "phim-lich-su"),
        ("Phim Miền Tây", "phim-mien-tay"),
        ("Phim Nhạc / Ca Nhạc", "phim-nhac"),
        ("Phim Phiêu Lưu", "phim-phieu-luu"),
        ("Phim Tài Liệu", "phim-tai-lieu"),
        ("Chương Trình Truyền Hình", "chuong-trinh-truyen-hinh"),
        ("Tạp Kỹ / Thực Tế", "reality"),
        ("Phim Soap", "soap"),
        ("Thiếu Nhi", "kids")
    ]
    items = []
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    for name, slug in genres:
        items.append({
            "label": f"[COLOR gold][B]{name}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/' + slug + '/')}{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": f"Thể loại {name}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_years_menu(filter_type=None):
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    items = [
        {
            "label": "[COLOR gold][B]Thập niên 2020s (2020 - 2026)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=2020s{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim sản xuất từ năm 2020 đến nay"
        },
        {
            "label": "[COLOR orange][B]Thập niên 2010s (2010 - 2019)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=2010s{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim sản xuất từ năm 2010 đến 2019"
        },
        {
            "label": "[COLOR orange][B]Thập niên 2000s (2000 - 2009)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=2000s{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim sản xuất từ năm 2000 đến 2009"
        },
        {
            "label": "[COLOR orange][B]Thập niên 1990s (1990 - 1999)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=1990s{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim sản xuất từ năm 1990 đến 1999"
        },
        {
            "label": "[COLOR orange][B]Thập niên 1980s (1980 - 1989)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=1980s{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim truyền hình/lẻ sản xuất từ năm 1980 đến 1989"
        },
        {
            "label": "[COLOR orange][B]Trước năm 1980[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_decade_menu&decade=pre1980{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": "Các phim sản xuất trước năm 1980"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_tvcine_decade_menu(decade, filter_type=None):
    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    
    years = []
    if decade == "2020s":
        years = list(range(2026, 2019, -1))
    elif decade == "2010s":
        years = list(range(2019, 2009, -1))
    elif decade == "2000s":
        years = list(range(2009, 1999, -1))
    elif decade == "1990s":
        years = list(range(1999, 1989, -1))
    elif decade == "1980s":
        years = list(range(1989, 1979, -1))
    elif decade == "pre1980":
        years = list(range(1979, 1969, -1))
        
    items = []
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    for y in years:
        items.append({
            "label": f"[COLOR yellow][B]Năm {y}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(CINE_DOMAIN + '/years/' + str(y) + '/')}{filter_query}",
            "thumbnail": tvcn_icon,
            "icon": tvcn_icon,
            "label2": f"Phim sản xuất năm {y}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}


def quote_url(url):
    if not url:
        return ""
    if not url.startswith("http"):
        return url
    try:
        parts = urllib.parse.urlparse(url)
        path = urllib.parse.quote(parts.path)
        quoted = urllib.parse.urlunparse((parts.scheme, parts.netloc, path, parts.params, parts.query, parts.fragment))
        if "thuviencine" in parts.netloc:
            quoted += f"|Referer={CINE_DOMAIN}/&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        return quoted
    except Exception:
        return url

def tvcine_browse(url, page=1, filter_type=None):
    base_url = url
    if "/page/" in url:
        base_url = re.sub(r'/page/\d+/?', '/', url)
        
    items = []
    current_page = page
    max_pages = 5
    has_next = True
    
    while len(items) < 8 and (current_page - page) < max_pages and has_next:
        if current_page > 1:
            if '?' in base_url:
                parts = base_url.split('?', 1)
                target_url = f"{parts[0].rstrip('/')}/page/{current_page}/?{parts[1]}"
            else:
                target_url = f"{base_url.rstrip('/')}/page/{current_page}/"
        else:
            target_url = base_url
            
        try:
            response = urlquick.get(target_url, headers=HEADERS, max_age=3600)
            html_content = response.text
        except Exception as e:
            if items:
                break
            alert(f"Lỗi khi tải trang phim: {str(e)}")
            return {"content_type": "movies", "items": []}
            
        pattern = r'<div id="post-\d+" class="item[^"]*">.*?</a>\s*</div>'
        html_items = re.findall(pattern, html_content, re.DOTALL)
        
        page_matched_items = []
        for html_item in html_items:
            link_match = re.search(r'<a href="([^"]+)"', html_item)
            link = link_match.group(1) if link_match else None
            if not link:
                continue
            if not link.startswith('http'):
                link = CINE_DOMAIN + ('/' if not link.startswith('/') else '') + link
            else:
                parsed = urllib.parse.urlparse(link)
                link = urllib.parse.urlunparse((parsed.scheme, CINE_HOST, parsed.path, parsed.params, parsed.query, parsed.fragment))
                
            title_match = re.search(r'<h2 class="movie-title">([^<]+)</h2>', html_item)
            title = title_match.group(1) if title_match else "Phim không tên"
            title = html.unescape(title).strip()
            
            # Calculate is_series for this item
            is_series = ("item-tv" in html_item or "tvb" in title.lower())
            if not is_series:
                genres = re.findall(r'/genre/([^"]+)"', html_item)
                for g in genres:
                    g_clean = g.strip('/')
                    if 'series' in g_clean or 'phim-bo' in g_clean or 'phi-bo' in g_clean:
                        is_series = True
                        break
            is_movie = not is_series
            
            # Local filtering logic based on filter_type
            if filter_type:
                if filter_type == 'tvb':
                    is_hk = ("tvb" in title.lower() or 
                             "hồng kông" in title.lower() or 
                             "hong kong" in title.lower() or 
                             "/country/hong-kong" in html_item.lower() or
                             "/country/hong-kong" in url.lower())
                    if not (is_hk and is_series):
                        continue
                elif filter_type == 'phim-le':
                    if not is_movie:
                        continue
                elif filter_type == 'series':
                    if not is_series:
                        continue
                        
            poster_match = re.search(r'data-src="([^"]+)"', html_item)
            poster = poster_match.group(1) if poster_match else "DefaultIcon.png"
            if poster and poster.startswith("http"):
                poster = quote_url(poster)
            
            plot_match = re.search(r'<p class="movie-description">([^<]+)</p>', html_item)
            plot = html.unescape(plot_match.group(1)).strip() if plot_match else ""
            
            quality_match = re.search(r'<span class="item-quality[^"]*">([^<]+)</span>', html_item)
            quality = quality_match.group(1).strip() if quality_match else ""
            
            rating_match = re.search(r'<div class="imdb-rating">.*?</i>([^<]+)</div>', html_item)
            rating = rating_match.group(1).strip() if rating_match else "N/A"
            
            year_match = re.search(r'<span class="movie-date">([^<]+)</span>', html_item)
            year_str = year_match.group(1).strip() if year_match else ""
            
            label_parts = []
            if quality:
                label_parts.append(f"[COLOR yellow][{quality}][/COLOR]")
            label_parts.append(title)
            if year_str:
                label_parts.append(f"({year_str})")
            if rating and rating != "N/A":
                label_parts.append(f"[COLOR lime][{rating}⭐][/COLOR]")
                
            label = " ".join(label_parts)
            
            path = f"plugin://plugin.video.cloudshare?action=tvcine_play&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)}&is_series={str(is_series).lower()}"
            
            context_menu = [
                ("Thêm vào Bộ sưu tập cá nhân", f"RunPlugin(plugin://plugin.video.cloudshare?action=tvcine_add_collection&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)})")
            ]
            
            item = {
                "label": label,
                "is_playable": not is_series,
                "path": path,
                "thumbnail": poster,
                "icon": poster,
                "label2": title,
                "info": {
                    "plot": plot,
                    "title": title
                },
                "art": {
                    "thumb": poster,
                    "icon": poster,
                    "poster": poster
                },
                "context_menu": context_menu
            }
            
            if year_str.isdigit():
                item["info"]["year"] = int(year_str)
                
            page_matched_items.append(item)
            
        items.extend(page_matched_items)
        
        # Check if next page exists
        next_page = current_page + 1
        next_page_str = f"/page/{next_page}/"
        if next_page_str in html_content:
            has_next = True
            current_page += 1
        else:
            has_next = False
            
    if has_next:
        next_page = current_page
        filter_query = f"&filter_type={filter_type}" if filter_type else ""
        next_path = f"plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(base_url)}&page={next_page}{filter_query}"
        items.append({
            "label": "[COLOR yellow]Trang tiếp theo >>[/COLOR]",
            "is_playable": False,
            "path": next_path,
            "thumbnail": "DefaultFolder.png",
            "icon": "DefaultFolder.png",
            "label2": "Xem các phim ở trang tiếp theo",
            "info": {"plot": "Nhấn để chuyển sang trang tiếp theo"}
        })
        
    return {"content_type": "movies", "items": items}

def tvcine_search():
    dialog = xbmcgui.Dialog()
    query = dialog.input("Nhập tên phim cần tìm", defaultt="")
    if not query:
        return
        
    query = query.strip()
    search_url = f"{CINE_DOMAIN}/?s={urllib.parse.quote_plus(query)}"
    xbmc.executebuiltin(f"Container.Update(plugin://plugin.video.cloudshare?action=tvcine_browse&url={urllib.parse.quote_plus(search_url)})")

def tvcine_play_or_add(movie_url, action='play', title=None, is_series=False):
    try:
        with open(r"D:\Kodi\debug.txt", "w", encoding="utf-8") as f_debug:
            f_debug.write(f"[thuviencine.py] tvcine_play_or_add started. Action: {action}, URL: {movie_url}\n")
    except:
        pass

    # 1. Fetch movie detail page
    try:
        detail_resp = urlquick.get(movie_url, headers=HEADERS, max_age=86400)
        detail_html = detail_resp.text
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write(f"[thuviencine.py] Detail page fetched. Length: {len(detail_html)}\n")
        except:
            pass
    except Exception as e:
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write(f"[thuviencine.py] Error fetching detail page: {str(e)}\n")
        except:
            pass
        alert(f"Không thể kết nối tới Thư Viện Cine: {str(e)}")
        return False
        
    # 2. Extract download page ID/URL
    download_match = re.search(r'href="([^"]*/download\?id=\d+)"', detail_html)
    if not download_match:
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write("[thuviencine.py] Error: download page link not found!\n")
        except:
            pass
        alert("Không tìm thấy link tải phim trên trang chi tiết.")
        return False
    download_url = download_match.group(1)
    if not download_url.startswith('http'):
        download_url = urllib.parse.urljoin(movie_url, download_url)
        
    # 3. Fetch download page
    try:
        download_resp = urlquick.get(download_url, headers=HEADERS, max_age=86400)
        download_html = download_resp.text
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write(f"[thuviencine.py] Download page fetched. URL: {download_url}, Length: {len(download_html)}\n")
        except:
            pass
    except Exception as e:
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write(f"[thuviencine.py] Error fetching download page: {str(e)}\n")
        except:
            pass
        alert(f"Không thể kết nối tới trang tải phim: {str(e)}")
        return False
        
    # 4. Extract Fshare links
    fshare_links = re.findall(r'href="(https?://(?:www\.)?fshare\.vn/(?:folder|file)/[A-Za-z0-9]+)"', download_html)
    if not fshare_links:
        try:
            with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                f_debug.write("[thuviencine.py] Error: Fshare link not found in download page!\n")
        except:
            pass
        alert("Không tìm thấy link Fshare trên trang tải phim.")
        return False
        
    seen = set()
    fshare_links = [x for x in fshare_links if not (x in seen or seen.add(x))]
    
    if action == 'play' and is_series and len(fshare_links) > 1:
        # Render multiple links directly as playable items in the current directory!
        import loadlistitem
        import xbmcgui
        list_items = []
        for idx, url in enumerate(fshare_links):
            label = url.split('/')[-1]
            if not label:
                label = f"Tập {idx+1}"
            
            if "/folder/" in url:
                is_folder = True
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(url)}"
                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {'title': label, 'mediatype': 'season'})
                li.setProperty('IsPlayable', 'false')
            else:
                is_folder = False
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(url)}"
                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {'title': label, 'mediatype': 'episode'})
                li.setProperty('IsPlayable', 'true')
                
            tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
            li.setArt({'thumb': tvcn_icon, 'icon': tvcn_icon, 'poster': tvcn_icon})
            list_items.append((play_url, li, is_folder))
            
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except Exception:
            pass
        xbmcplugin.setContent(HANDLE, 'episodes')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return True

    if len(fshare_links) == 1:
        fshare_url = fshare_links[0]
    else:
        labels = [f"Nguồn {idx+1}: {link.split('/')[-1]} ({'Thư mục' if '/folder/' in link else 'Tệp tin'})" for idx, link in enumerate(fshare_links)]
        selected = xbmcgui.Dialog().select("Chọn liên kết Fshare", labels)
        if selected == -1:
            return False
        fshare_url = fshare_links[selected]
        
    try:
        with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
            f_debug.write(f"[thuviencine.py] Fshare link resolved: {fshare_url}\n")
    except:
        pass

    # 5. Execute action
    if action == 'play':
        if is_series:
            # We are handling a folder listing request.
            # We must not resolve URL via setResolvedUrl. We must return directory items.
            import loadlistitem
            from resources import cache_utils
            
            if "/folder/" in fshare_url:
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                data = cache_utils.cache_data(fshare_url)
                if data is not None and data.get("items"):
                    loadlistitem.list_item_main(data)
                else:
                    # Fallback: list a single folder item
                    import xbmcgui
                    li = xbmcgui.ListItem(label=title)
                    li.setInfo('video', {'title': title, 'mediatype': 'season'})
                    li.setProperty('IsPlayable', 'false')
                    play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                    xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=True)
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                return True
            else:
                # Fshare URL is a single file. List it directly.
                import xbmcgui
                li = xbmcgui.ListItem(label=title)
                li.setInfo('video', {'title': title, 'mediatype': 'episode'})
                li.setProperty('IsPlayable', 'true')
                tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
                li.setArt({'thumb': tvcn_icon, 'icon': tvcn_icon, 'poster': tvcn_icon})
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                xbmcplugin.setContent(HANDLE, 'episodes')
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                return True
        else:
            # Single-click play action for movies (is_series = False)
            if "/folder/" in fshare_url:
                try:
                    with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                        f_debug.write(f"[thuviencine.py] Folder link. Updating container: {fshare_url}\n")
                except:
                    pass
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                try:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                except Exception:
                    pass
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                xbmc.executebuiltin(f"Container.Update({play_url})")
                return True
            else:
                try:
                    with open(r"D:\Kodi\debug.txt", "a", encoding="utf-8") as f_debug:
                        f_debug.write(f"[thuviencine.py] File link. Resolving stream: {fshare_url}\n")
                except:
                    pass
                resolved_link = getlink.get(fshare_url)
                if resolved_link:
                    item = xbmcgui.ListItem(path=resolved_link)
                    item.setMimeType('video/mp4')
                    item.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(HANDLE, True, item)
                    return True
                else:
                    alert("Không thể giải mã liên kết Fshare để phát.")
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                    return False
    elif action == 'add':
        if not title:
            title_match = re.search(r'<h1[^>]*class="entry-title"[^>]*>([^<]+)</h1>', detail_html)
            title = title_match.group(1) if title_match else "Phim_Tvcine"
        title = html.unescape(title)
        title = re.sub(r'[\\/*?:"<>|#]', "", title)
        tvcine_add_to_collection(fshare_url, title)
        return False

def tvcine_add_to_collection(url_input, name):
    dialog = xbmcgui.Dialog()
    download_path = xbmcvfs.translatePath(ADDON.getSetting("download_path"))
    if not download_path:
        choice = dialog.yesno('Thiết lập đường dẫn', 'Đường dẫn lưu trữ (Download Path) chưa được thiết lập. Bạn có muốn thiết lập ngay bây giờ?')
        if choice:
            download_path = dialog.browse(3, 'Chọn đường dẫn lưu trữ', 'files')
            if download_path:
                ADDON.setSetting("download_path", download_path)
            else:
                return
        else:
            return
            
    collection_dir = vfs_join(download_path, "Phim collection")
    try:
        vfs_mkdirs(collection_dir)
    except Exception as e:
        alert(f"Không thể tạo thư mục Phim collection: {str(e)}")
        return

    subfolders = []
    try:
        dirs, files = vfs_listdir(collection_dir)
        for item in dirs:
            if not item.startswith('.'):
                subfolders.append(item)
    except Exception:
        pass
    subfolders.sort()

    options = ["Lưu vào thư mục gốc của Bộ sưu tập", "+ Tạo thư mục phân loại mới..."] + subfolders
    choice = dialog.select("Chọn nơi lưu trữ trong Bộ sưu tập", options)

    if choice == -1:
        return

    if choice == 0:
        target_parent = collection_dir
    elif choice == 1:
        new_folder = dialog.input("Nhập tên thư mục phân loại mới (VD: Phim Hanh Dong)", defaultt="")
        if not new_folder:
            return
        new_folder = clean_filename(new_folder)
        target_parent = vfs_join(collection_dir, new_folder)
        try:
            vfs_mkdirs(target_parent)
        except Exception as e:
            alert(f"Không thể tạo thư mục phân loại mới: {str(e)}")
            return
    else:
        selected_folder = subfolders[choice - 2]
        target_parent = vfs_join(collection_dir, selected_folder)

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("CloudShare", "Đang xử lý thông tin...")
    pDialog.update(20, "Đang kết nối Fshare...")

    if "folder" in url_input.lower():
        token, session_id = fshare.check_session()
        if not token or not session_id:
            pDialog.close()
            alert("Lỗi đăng nhập Fshare. Vui lòng kiểm tra tài khoản.")
            return

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': fshare.useragent,
            'Cookie': 'session_id=' + session_id
        }

        pDialog.update(40, "Đang lấy danh sách tập tin từ thư mục Fshare...")
        payload = json.dumps({
            "token": token,
            "url": url_input,
            "dirOnly": 0,
            "pageIndex": 0,
            "limit": 100
        })
        try:
            r = requests.post("https://api.fshare.vn/api/fileops/getFolderList", headers=headers, data=payload, verify=False, timeout=10)
            r.raise_for_status()
            f_items = json.loads(r.content)

            if not f_items or not isinstance(f_items, list):
                pDialog.close()
                alert("Thư mục trống hoặc lỗi khi lấy danh sách tập tin.")
                return

            folder_name = clean_filename(name)
            movie_folder = vfs_join(target_parent, folder_name)
            vfs_mkdirs(movie_folder)

            pDialog.update(70, "Đang quét thư mục con và tạo các tệp .strm...")
            created_count = add_folder_recursive(token, session_id, url_input, movie_folder, pDialog, progress=[70])
            pDialog.close()
            notify(f"Đã tạo thư mục '{folder_name}' và {created_count} file .strm thành công!")
        except Exception as e:
            pDialog.close()
            alert(f"Lỗi khi đọc thư mục Fshare: {str(e)}")
    else:
        pDialog.update(60, "Đang tạo tệp .strm...")
        try:
            strm_name = clean_filename(name) + ".strm"
            strm_path = vfs_join(target_parent, strm_name)
            file_code_match = re.search(r"file/([a-zA-Z0-9]+)", url_input)
            if file_code_match:
                linkcode = file_code_match.group(1)
                strm_content = f"plugin://plugin.video.cloudshare?action=play&url=https://www.fshare.vn/file/{linkcode}"
                with vfs_open(strm_path, 'w') as f:
                    f.write(strm_content)
                pDialog.close()
                notify(f"Đã tạo tệp '{strm_name}' thành công!")
            else:
                pDialog.close()
                alert("Không thể trích xuất mã linkcode từ đường dẫn Fshare.")
        except Exception as e:
            pDialog.close()
            alert(f"Lỗi khi tạo tệp .strm: {str(e)}")

def get_tvcine_kim_dung_menu():
    classics = [
        {
            'title': 'Anh Hùng Xạ Điêu (1994) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-anh-hung-xa-dieu-phan-1-the-legend-of-the-condor-heroes-season-1-1994-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/wFc9q0aukqLipT1Oyt1fk4udjyV.jpg',
            'plot': 'Hoàng Dung là con gái của đảo chủ đảo Đào Hoa, Đông Tà Hoàng Dược Sư và Phùng Thị Mai Hương. Nàng mồ côi mẹ từ nhỏ và được cha nuôi nấng, truyền thụ võ nghệ. Tính cách Hoàng Dung khá giống với cha ...',
            'year': 1994,
            'rating': '8.5'
        },
        {
            'title': 'Tuyết Sơn Phi Hồ (1999) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-tuyet-son-phi-ho-phan-1-the-flying-fox-of-the-snowy-mountain-season-1-1999-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/myO9JdskXlGMPtrOlS2kb1RJxdQ.jpg',
            'plot': 'Câu chuyện kể về cuộc đời của anh hùng Hồ Phi. Mục tiêu lớn nhất của cuộc đời Hồ Phi là tìm ra kẻ giết chết cha mẹ mình. Bên cạnh anh lúc nào cũng có một hồng nhan tri kỉ là Miêu Nhược Lan. Thế như...',
            'year': 1999,
            'rating': '7.8'
        },
        {
            'title': 'Bích Huyết Kiếm (1985) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-bich-huyet-kiem-phan-1-the-sword-stained-with-royal-blood-season-1-1985-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/mXNCGdD9Soo1QOsDIR1C8APZk0x.jpg',
            'plot': 'Thanh kiếm nhuộm máu hoàng gia là một bộ phim truyền hình Hồng Kông được chuyển thể từ tiểu thuyết cùng tên của Louis Cha. Phim được phát sóng lần đầu tiên trên TVB ở Hồng Kông vào năm 1985.',
            'year': 1985,
            'rating': '7.6'
        },
        {
            'title': 'Song Hùng Kỳ Hiệp (1988) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-song-hung-ky-hiep-phan-1-two-most-honorable-knights-season-1-1988-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/o4Rtv5fa0swFQrR3p3dGwFRRn9a.jpg',
            'plot': 'Yến Nam Thiên gần như đạt đến danh hiệu "Thiên hạ đệ nhất" với kiếm pháp lẫn thần công của mình. Ông có người huynh đệ kết nghĩa là một anh hùng hảo hán trên giang hồ – Giang Phong. Sự đời trớ trêu...',
            'year': 1988,
            'rating': '8.3'
        },
        {
            'title': 'Long Đình Tranh Bá (1988) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-long-dinh-tranh-ba-phan-1-emperor-and-the-swordsman-season-1-1988-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/jIYE0EqzWr1kGTrzsZaOjgxQaRj.jpg',
            'plot': 'Long Đình Tranh Bá 1988 là bộ phim truyền hình võ thuật kiếm hiệp cổ trang dã sử do TVB sản xuất, có sự tham gia của La Gia Lương, Tăng Hoa Thiên.',
            'year': 1988,
            'rating': '7.2'
        },
        {
            'title': 'Đao Tiên Kiếm Thánh (1986) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-dao-tien-kiem-thanh-phan-1-blood-stained-intrigue-season-1-1986-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/f1cZ5BTdQW7Z18t9ylyEvJHKNpi.jpg',
            'plot': 'Phim mở đầu bằng một vụ án ly kỳ trên giang hồ, nói rõ tánh xấu của con người và những chuyện mờ ám về đấu tranh quyền lực. Bạch Phụng Thiên, Chúc ý Vân bị vu oan giết hại tứ đại chưởng môn của chá...',
            'year': 1986,
            'rating': '7.3'
        },
        {
            'title': 'Thiên Long Bát Bộ (2003) - Thuyết Minh',
            'link': 'https://thuviencine.live/phim-thien-long-bat-bo-phan-1-demi-gods-and-semi-devils-season-1-2003-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/2aw0UE2l3KYc1coF2302QLyHWHo.jpg',
            'plot': 'Thiên Long Bát Bộ hay còn gọi là Lục Mạch Thần Kiếm. Được tái bản lại trên kênh truyền hình Trung Quốc năm 2003 Câu chuyện xoay quanh mối quan hệ phức tạp giữa nhiều nhân vật đến từ nhiều nước và m...',
            'year': 2003,
            'rating': '8.8'
        },
        {
            'title': 'Ỷ Thiên Đồ Long Ký (2003) - Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-y-thien-do-long-ky-phan-1-heavenly-sword-and-dragon-sabre-season-1-2003-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/1u3mRlDQWVbrZB8FtNRpYFYTIBq.jpg',
            'plot': 'Ỷ Thiên Đồ Long Ký (tiếng Hoa: 倚天屠龙记 Yi Tian Tu Long Ji; tiếng Anh: The Heavenly Sword and Dragon Saber) là một bộ phim kiếm hiệp 40 tập được sản xuất năm 2003 bởi Công ty sản xuất âm thanh trung t...',
            'year': 2003,
            'rating': '8.4'
        },
        {
            'title': 'Tiếu Ngạo Giang Hồ (2001) - Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-tieu-ngao-giang-ho-phan-1-laughing-in-the-wind-season-1-2001-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/nJm6vPElycW3ym7IaHQZlTg5rG8.jpg',
            'plot': 'Đau khổ vì bị người yêu Nhạc Linh San phụ bạc, bị đồng môn hiểu lầm và bị trục xuất khỏi sư môn, Lệnh Hồ Xung đã lang thang, phiêu bạt khắp nơi và trải qua biết bao sóng gió. Do may mắn, chàng đã đ...',
            'year': 2001,
            'rating': '8.7'
        },
        {
            'title': 'Dương Quá Và Tiểu Long Nữ (1983) - Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-duong-qua-va-tieu-long-nu-little-dragon-maiden-1983-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/yKyCL1MxcoQU5w6981iEPlBnRzv.jpg',
            'plot': 'Little Dragon Maiden là phiên bản điện ảnh chuyển thể từ tiểu thuyết kiếm hiệp nổi tiếng của Kim Dung, kể về chuyện tình đầy trắc trở giữa Dương Quá và Tiểu Long Nữ giữa chốn giang hồ đầy ân oán. S...',
            'year': 1983,
            'rating': '7.0'
        },
        {
            'title': 'Tứ Đại Tài Tử (2000) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-tu-dai-tai-tu-phan-1-the-legendary-four-aces-season-1-2000-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/vPP4K3Fnah7erbFNrelx6Otz6qL.jpg',
            'plot': 'Chuyện phim xoay quanh bốn chàng hiền sĩ gồm Đường Bá Hổ, Chúc Chi Sơn, Văn Trương Minh và Châu Văn Tân. Bốn chàng trai là đóng vai khác nhau nhưng tài giỏi, tâm tính lương thiện, chính trực nên...',
            'year': 2000,
            'rating': '8.0'
        },
        {
            'title': 'Đắc Kỷ Trụ Vương (2001) - TVB Lồng Tiếng',
            'link': 'https://thuviencine.live/phim-dac-ky-tru-vuong-phan-1-gods-of-honour-season-1-2001-fshare/',
            'poster': 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/AcMwhWciyGtFLk2xW9oAU4FNLIK.jpg',
            'plot': 'Đắc Kỷ Trụ Vương xoay quanh bối cảnh binh biến loạn lạc thời Trụ Vương mà cụ thể hơn là nhà họ Lý. Lý Tịnh và Ân Thập nương là vợ chồng cùng nhau chinh chiến nhưng từ khi Ân thập nương mang thai hơ...',
            'year': 2001,
            'rating': '8.5'
        }
    ]

    tvcn_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvcn.jpeg')
    items = []
    
    # Prepend shortcuts to the massive pre-indexed collections
    items.append({
        "label": "[COLOR lime][B]>> Xem Tuyển Tập 1000+ Phim TVB / ATV / Kim Dung (Fshare)[/B][/COLOR]",
        "is_playable": False,
        "path": "plugin://plugin.video.cloudshare?action=fshare_special_menu",
        "thumbnail": tvcn_icon,
        "icon": tvcn_icon,
        "label2": "Truy cập kho 1022 phim TVB, 31 phim ATV và trọn bộ Kim Dung nguồn Fshare",
        "info": {
            "plot": "Truy cập bộ sưu tập Fshare đặc biệt tích hợp sẵn của addon bao gồm 1022 phim bộ truyền hình đài TVB Hồng Kông và 31 phim đài ATV.",
            "title": "Tuyển Tập TVB/ATV/Kim Dung (Fshare)"
        }
    })
    
    items.append({
        "label": "[COLOR lightskyblue][B]>> Xem Tuyển Tập Phim TVB / ATV / Kim Dung (Web API)[/B][/COLOR]",
        "is_playable": False,
        "path": "plugin://plugin.video.cloudshare?action=web_special_menu",
        "thumbnail": tvcn_icon,
        "icon": tvcn_icon,
        "label2": "Truy cập các phim TVB, ATV và Kim Dung nguồn Web API tốc độ cao",
        "info": {
            "plot": "Truy cập bộ sưu tập phim bộ TVB/ATV từ nguồn Web API được phân loại theo năm.",
            "title": "Tuyển Tập TVB/ATV/Kim Dung (Web API)"
        }
    })

    for c in classics:
        title = c["title"]
        link = c["link"].replace('https://thuviencine.live', CINE_DOMAIN)
        poster = c["poster"]
        plot = c["plot"]
        year = c["year"]
        rating = c.get("rating", "")

        label_parts = []
        label_parts.append(f"[COLOR yellow][{year}][/COLOR]")
        label_parts.append(title)
        if rating:
            label_parts.append(f"[COLOR lime][{rating}⭐][/COLOR]")

        label = " ".join(label_parts)

        path = f"plugin://plugin.video.cloudshare?action=tvcine_play&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)}"

        context_menu = [
            ("Thêm vào Bộ sưu tập cá nhân", f"RunPlugin(plugin://plugin.video.cloudshare?action=tvcine_add_collection&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)})")
        ]

        item = {
            "label": label,
            "is_playable": True,
            "path": path,
            "thumbnail": poster,
            "icon": poster,
            "label2": title,
            "info": {
                "plot": plot,
                "title": title,
                "year": year
            },
            "art": {
                "thumb": poster,
                "icon": poster,
                "poster": poster
            },
            "context_menu": context_menu
        }
        items.append(item)

    return {"content_type": "movies", "items": items}

