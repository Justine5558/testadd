# -*- coding: utf-8 -*-
import os
import re
import urllib.parse
import json
import xbmc
import xbmcgui
import xbmcvfs
import sys
import shutil

# Ensure requests can be imported from local lib
sys.path.insert(0, r'd:/Kodi/plugin.video.cloudshare/resources/lib')
import requests

from resources.addon import ADDON, alert, notify, logError, PROFILE, PROFILE_PATH
from resources import fshare

_virtual_db_cache = None

# --- Kodi Hybrid VFS/Local File Helpers ---

def vfs_join(base, *paths):
    is_network = '://' in base or base.startswith('special://')
    if is_network:
        base = base.replace('\\', '/')
        for p in paths:
            p = p.replace('\\', '/').strip('/')
            if not base.endswith('/'):
                base += '/'
            base += p
    else:
        base = base.replace('/', '\\')
        for p in paths:
            p = p.replace('/', '\\').strip('\\')
            if not base.endswith('\\'):
                base += '\\'
            base += p
    return base

def vfs_basename(path):
    path = path.replace('\\', '/')
    return path.rstrip('/').split('/')[-1]

def vfs_dirname(path):
    path = path.replace('\\', '/').rstrip('/')
    parts = path.split('/')
    if len(parts) > 1:
        return '/'.join(parts[:-1])
    return ''

def vfs_exists(path):
    if '://' in path:
        return xbmcvfs.exists(path)
    else:
        return os.path.exists(path)

def vfs_mkdirs(path):
    if '://' in path:
        return xbmcvfs.mkdirs(path)
    else:
        os.makedirs(path, exist_ok=True)
        return True

def vfs_listdir(path):
    if '://' in path:
        return xbmcvfs.listdir(path)
    else:
        items = os.listdir(path)
        dirs = []
        files = []
        for item in items:
            if os.path.isdir(os.path.join(path, item)):
                dirs.append(item)
            else:
                files.append(item)
        return dirs, files

def vfs_delete(path):
    if '://' in path:
        return xbmcvfs.delete(path)
    else:
        if os.path.exists(path):
            os.remove(path)
        return True

def vfs_rmtree(path):
    if '://' in path:
        try:
            dirs, files = xbmcvfs.listdir(path)
            for f in files:
                xbmcvfs.delete(vfs_join(path, f))
            for d in dirs:
                vfs_rmtree(vfs_join(path, d))
            xbmcvfs.rmdir(path)
        except Exception as e:
            logError(f"[CloudShare] Error in VFS vfs_rmtree on {path}: {str(e)}")
            raise
    else:
        if os.path.exists(path):
            shutil.rmtree(path)
    return True

def vfs_copy_tree(src, dst):
    if '://' in src or '://' in dst:
        xbmcvfs.mkdirs(dst)
        dirs, files = xbmcvfs.listdir(src)
        for f in files:
            xbmcvfs.copy(vfs_join(src, f), vfs_join(dst, f))
        for d in dirs:
            vfs_copy_tree(vfs_join(src, d), vfs_join(dst, d))
    else:
        if os.path.exists(dst):
            shutil.rmtree(dst)
        shutil.copytree(src, dst)

def vfs_move(src, dst):
    if '://' in src or '://' in dst:
        try:
            if xbmcvfs.rename(src, dst):
                return True
        except Exception:
            pass
        
        is_dir = False
        try:
            xbmcvfs.listdir(src)
            is_dir = True
        except Exception:
            pass
            
        if is_dir:
            vfs_copy_tree(src, dst)
            vfs_rmtree(src)
        else:
            xbmcvfs.copy(src, dst)
            xbmcvfs.delete(src)
        return True
    else:
        shutil.move(src, dst)
        return True

class vfs_open(object):
    def __init__(self, path, mode='r'):
        self.path = path
        self.mode = mode
        self.is_network = '://' in path
        self.file_obj = None

    def __enter__(self):
        if self.is_network:
            self.file_obj = xbmcvfs.File(self.path, self.mode)
            # Standard Kodi VFS File doesn't have encoding but we mock standard methods
            return self.file_obj
        else:
            self.file_obj = open(self.path, self.mode, encoding='utf-8' if 'w' in self.mode or 'r' in self.mode else None)
            return self.file_obj

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.file_obj:
            self.file_obj.close()

# --- Addon Logic ---

def clean_filename(filename):
    return re.sub(r'[\\/*?:"<>|]', "", filename).strip()

def add_folder_recursive(token, session_id, folder_url, local_parent_path, pDialog=None, progress=None, current_depth=0, max_depth=3):
    if current_depth > max_depth:
        return 0

    headers = {
        'Content-Type': 'application/json',
        'User-Agent': fshare.useragent,
        'Cookie': 'session_id=' + session_id
    }

    f_items = []
    for page in range(2):
        payload = json.dumps({
            "token": token,
            "url": folder_url,
            "dirOnly": 0,
            "pageIndex": page,
            "limit": 100
        })
        try:
            import time
            time.sleep(0.1)
            r = requests.post("https://api.fshare.vn/api/fileops/getFolderList", headers=headers, data=payload, verify=False, timeout=10)
            r.raise_for_status()
            page_items = json.loads(r.content)
            if not page_items or not isinstance(page_items, list):
                break
            f_items.extend(page_items)
            if len(page_items) < 100:
                break
        except Exception as e:
            logError(f"[CloudShare] Error listing folder {folder_url}: {e}")
            break

    if not f_items:
        return 0

    created_count = 0
    for f_item in f_items:
        f_name = f_item.get("name")
        f_type = str(f_item.get("type"))
        linkcode = f_item.get("linkcode")

        if not f_name or not linkcode:
            continue

        clean_name = clean_filename(f_name)
        if f_type == "0":  # Subfolder
            sub_local_path = vfs_join(local_parent_path, clean_name)
            try:
                vfs_mkdirs(sub_local_path)
            except Exception as e:
                logError(f"[CloudShare] Failed to create subdir {sub_local_path}: {e}")
                continue
            
            sub_folder_url = f"https://www.fshare.vn/folder/{linkcode}"
            if pDialog:
                if progress is None:
                    progress = [70]
                progress[0] = min(95, progress[0] + 1)
                pDialog.update(progress[0], f"Quét thư mục con: {clean_name[:30]}")

            created_count += add_folder_recursive(token, session_id, sub_folder_url, sub_local_path, pDialog, progress, current_depth + 1, max_depth)
        else:  # File
            if f_name.lower().endswith(('.mp4', '.mkv', '.avi', '.ts', '.m2ts', '.m3u8', '.mp3', '.m4a')):
                strm_name = os.path.splitext(clean_name)[0] + ".strm"
                strm_path = vfs_join(local_parent_path, strm_name)
                strm_content = f"plugin://plugin.video.cloudshare?action=play&url=https://www.fshare.vn/file/{linkcode}"
                try:
                    with vfs_open(strm_path, 'w') as f:
                        f.write(strm_content)
                    created_count += 1
                except Exception as e:
                    logError(f"[CloudShare] Failed to write .strm: {e}")

    return created_count

def add_to_collection_dialog():
    global _virtual_db_cache
    _virtual_db_cache = None
    dialog = xbmcgui.Dialog()
    
    download_path = ADDON.getSetting("download_path")
    if not download_path:
        collection_dir = os.path.join(PROFILE_PATH, "Phim collection")
    else:
        download_path = xbmcvfs.translatePath(download_path)
        collection_dir = vfs_join(download_path, "Phim collection")
            
    url_input = dialog.input("Dán link Fshare (File hoặc Folder)", defaultt="")
    if not url_input:
        return
        
    url_input = url_input.strip()
    if not any(kw in url_input.lower() for kw in ["fshare.vn/file/", "fshare.vn/folder/"]):
        alert("Đường dẫn Fshare không hợp lệ. Phải chứa fshare.vn/file/ hoặc fshare.vn/folder/")
        return
        
    token, session_id = fshare.check_session()
    if not token or not session_id:
        alert("Lỗi đăng nhập Fshare. Vui lòng kiểm tra tài khoản.")
        return
    try:
        vfs_mkdirs(collection_dir)
    except Exception as e:
        alert(f"Không thể tạo thư mục Phim collection: {str(e)}")
        return

    subfolders = []
    try:
        dirs, files = vfs_listdir(collection_dir)
        for item in dirs:
            if not item.startswith('.'):
                subfolders.append(item)
    except Exception:
        pass
    subfolders.sort()

    options = ["Lưu vào thư mục gốc của Bộ sưu tập", "+ Tạo thư mục phân loại mới..."] + subfolders
    choice = dialog.select("Chọn nơi lưu trữ trong Bộ sưu tập", options)
    
    if choice == -1:
        return
        
    if choice == 0:
        target_parent = collection_dir
    elif choice == 1:
        new_folder = dialog.input("Nhập tên thư mục phân loại mới (VD: Phim Hanh Dong)", defaultt="")
        if not new_folder:
            return
        new_folder = clean_filename(new_folder)
        target_parent = vfs_join(collection_dir, new_folder)
        try:
            vfs_mkdirs(target_parent)
        except Exception as e:
            alert(f"Không thể tạo thư mục phân loại mới: {str(e)}")
            return
    else:
        selected_folder = subfolders[choice - 2]
        target_parent = vfs_join(collection_dir, selected_folder)

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("CloudShare", "Đang xử lý thông tin...")
    pDialog.update(20, "Đang kết nối Fshare...")

    headers = {
        'Content-Type': 'application/json',
        'User-Agent': fshare.useragent,
        'Cookie': 'session_id=' + session_id
    }

    if "folder" in url_input.lower():
        pDialog.update(40, "Đang lấy danh sách tập tin từ thư mục Fshare...")
        
        payload = json.dumps({
            "token": token,
            "url": url_input,
            "dirOnly": 0,
            "pageIndex": 0,
            "limit": 100
        })
        
        try:
            r = requests.post("https://api.fshare.vn/api/fileops/getFolderList", headers=headers, data=payload, verify=False, timeout=10)
            r.raise_for_status()
            f_items = json.loads(r.content)
            
            if not f_items or not isinstance(f_items, list):
                pDialog.close()
                alert("Thư mục trống hoặc lỗi khi lấy danh sách tập tin.")
                return
                
            path_val = f_items[0].get("path", "")
            folder_name = path_val.strip("/").split("/")[-1] if path_val and path_val != "/" else ""
            
            if not folder_name:
                code_match = re.search(r'folder/([a-zA-Z0-9]+)', url_input)
                folder_name = code_match.group(1) if code_match else "Folder_Fshare"
                
            folder_name = clean_filename(folder_name)
            movie_folder = vfs_join(target_parent, folder_name)
            vfs_mkdirs(movie_folder)
            
            pDialog.update(70, "Đang quét thư mục con và tạo các tệp .strm...")
            created_count = add_folder_recursive(token, session_id, url_input, movie_folder, pDialog, progress=[70])
                    
            pDialog.close()
            notify(f"Đã tạo thư mục '{folder_name}' và {created_count} file .strm thành công!")
            
        except Exception as e:
            pDialog.close()
            logError(f"[CloudShare] Error listing folder files: {str(e)}")
            alert(f"Lỗi khi đọc thư mục Fshare: {str(e)}")
            return
            
    else:
        pDialog.update(40, "Đang lấy thông tin tệp tin từ Fshare...")
        
        data = '{"token" : "%s", "url" : "%s"}' % (token, url_input)
        try:
            r = requests.post('https://api.fshare.vn/api/fileops/get', headers=headers, data=data, verify=False, timeout=10)
            r.raise_for_status()
            jstr = json.loads(r.content)
            
            name = jstr.get('name', '')
            if not name:
                file_code_match = re.search(r"file/([a-zA-Z0-9]+)", url_input)
                name = file_code_match.group(1) if file_code_match else "File_Fshare"
                
            name = clean_filename(name)
            strm_name = os.path.splitext(name)[0] + ".strm"
            strm_path = vfs_join(target_parent, strm_name)
            
            pDialog.update(80, "Đang tạo tệp .strm...")
            
            file_code_match = re.search(r"file/([a-zA-Z0-9]+)", url_input)
            if file_code_match:
                linkcode = file_code_match.group(1)
                strm_content = f"plugin://plugin.video.cloudshare?action=play&url=https://www.fshare.vn/file/{linkcode}"
                
                with vfs_open(strm_path, 'w') as f:
                    f.write(strm_content)
                pDialog.close()
                notify(f"Đã tạo tệp '{strm_name}' thành công!")
            else:
                pDialog.close()
                alert("Không thể trích xuất mã linkcode từ đường dẫn Fshare.")
                
        except Exception as e:
            pDialog.close()
            logError(f"[CloudShare] Error getting file info: {str(e)}")
            alert(f"Lỗi khi lấy thông tin tệp tin: {str(e)}")

def parse_query_safely(url):
    params = {}
    if '?' in url:
        qs = url.split('?', 1)[1]
        for pair in qs.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                params[k] = urllib.parse.unquote(v)
    return params

def browse_collection(url):
    import xbmcplugin
    from resources import gsheet
    
    db = gsheet.get_metadata_db()
    
    params = parse_query_safely(url)
    dir_path = params.get('dir', '')
    
    # Normalize dir_path (relative path)
    dir_path = dir_path.replace('\\', '/').strip('/')
    
    addon_path = ADDON.getAddonInfo("path")
    json_path = xbmcvfs.translatePath(os.path.join(addon_path, "resources", "collection_data.json"))
    
    # 1. Load virtual database if exists (use memory cache if loaded)
    global _virtual_db_cache
    virtual_db = None
    if _virtual_db_cache is not None:
        virtual_db = _virtual_db_cache
    elif os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                virtual_db = json.load(f)
                _virtual_db_cache = virtual_db
        except Exception as e:
            logError(f"[CloudShare] Error loading virtual db: {e}")
            
    # 2. Resolve local collection directory
    download_path = ADDON.getSetting("download_path")
    if not download_path:
        collection_dir = os.path.join(PROFILE_PATH, "Phim collection")
    else:
        collection_dir = vfs_join(xbmcvfs.translatePath(download_path), "Phim collection")
        
    local_target_dir = vfs_join(collection_dir, dir_path) if dir_path else collection_dir
    
    # 3. Retrieve local subdirectories and files
    local_subdirs = []
    local_files = {}  # name -> play_url
    if vfs_exists(local_target_dir):
        try:
            dirs, files = vfs_listdir(local_target_dir)
            exclusions = ['.git', '.idea', '__pycache__', 'temp', 'cache', 'profile', 'dummy']
            local_subdirs = [d for d in dirs if d not in exclusions and not d.startswith('.')]
            local_strm_files = [f for f in files if f.lower().endswith('.strm') and f not in exclusions and not f.startswith('.')]
            
            for file in local_strm_files:
                full_file_path = vfs_join(local_target_dir, file)
                try:
                    with vfs_open(full_file_path, 'r') as f:
                        play_url = f.read().strip()
                    if play_url:
                        local_files[os.path.splitext(file)[0]] = play_url
                except Exception as e:
                    logError(f"[CloudShare] Error reading strm file {full_file_path}: {e}")
        except Exception as e:
            logError(f"[CloudShare] Error listing local directory {local_target_dir}: {e}")
            
    # 4. Retrieve virtual subdirectories and files
    virtual_subdirs = []
    virtual_files = {}  # name -> play_url
    if virtual_db and dir_path in virtual_db:
        folder_data = virtual_db[dir_path]
        virtual_subdirs = folder_data.get("subdirs", [])
        for f_entry in folder_data.get("files", []):
            virtual_files[f_entry["name"]] = f_entry["url"]
            
    # 5. Merge subdirectories and files
    merged_subdirs = sorted(list(set(local_subdirs + virtual_subdirs)))
    
    merged_files_dict = {}
    merged_files_dict.update(virtual_files)
    merged_files_dict.update(local_files)  # Local files overwrite/add to virtual ones
    
    merged_files_names = sorted(list(merged_files_dict.keys()))
    
    directory_items = []
    
    # 6. Add directory items for folders
    for folder in merged_subdirs:
        full_rel_folder = (dir_path + "/" + folder) if dir_path else folder
        list_item = xbmcgui.ListItem(label=f"[COLOR yellow][B] {folder}[/B][/COLOR]")
        folder_icon = vfs_join(addon_path, 'resources', 'images', 'utilities_.png')
        list_item.setArt({"icon": folder_icon, "thumb": folder_icon})
        
        clean_name = gsheet.clean_title(folder)
        meta = db.get(clean_name) if db else None
        if meta:
            poster = meta.get("poster", "")
            if poster:
                list_item.setArt({"icon": poster, "thumb": poster, "poster": poster})
            info_tag = list_item.getVideoInfoTag()
            plot_text = meta.get("plot", "")
            cast_list = meta.get("cast", [])
            if isinstance(cast_list, list) and cast_list:
                cast_str = ", ".join(cast_list)
                plot_text = f"[COLOR gold][B]DIỄN VIÊN:[/B][/COLOR] {cast_str}\n\n{plot_text}"
            info_tag.setPlot(plot_text)
            info_tag.setYear(int(meta.get("year")) if meta.get("year") else 0)
            info_tag.setStudios([meta.get("studio")] if meta.get("studio") else [])
            
        if folder in local_subdirs:
            full_local_path = vfs_join(local_target_dir, folder)
            delete_url = f"plugin://plugin.video.cloudshare?action=delete_from_collection&path={urllib.parse.quote_plus(full_local_path)}"
            move_url = f"plugin://plugin.video.cloudshare?action=move_in_collection&path={urllib.parse.quote_plus(full_local_path)}"
            list_item.addContextMenuItems([
                ('Di chuyển phim', f'RunPlugin({move_url})'),
                ('Xóa khỏi Bộ sưu tập', f'RunPlugin({delete_url})')
            ])
            
        item_path = f"plugin://plugin.video.cloudshare?action=browse_collection&dir={urllib.parse.quote_plus(full_rel_folder)}"
        directory_items.append((item_path, list_item, True))
        
    # 7. Add directory items for files
    for file_name in merged_files_names:
        play_url = merged_files_dict[file_name]
        list_item = xbmcgui.ListItem(label=file_name)
        video_icon = vfs_join(addon_path, 'icon_play.png')
        list_item.setArt({"icon": video_icon, "thumb": video_icon})
        
        clean_name = gsheet.clean_title(file_name)
        meta = db.get(clean_name) if db else None
        if meta:
            poster = meta.get("poster", "")
            if poster:
                list_item.setArt({"icon": poster, "thumb": poster, "poster": poster})
            info_tag = list_item.getVideoInfoTag()
            plot_text = meta.get("plot", "")
            cast_list = meta.get("cast", [])
            if isinstance(cast_list, list) and cast_list:
                cast_str = ", ".join(cast_list)
                plot_text = f"[COLOR gold][B]DIỄN VIÊN:[/B][/COLOR] {cast_str}\n\n{plot_text}"
            info_tag.setPlot(plot_text)
            info_tag.setYear(int(meta.get("year")) if meta.get("year") else 0)
            info_tag.setStudios([meta.get("studio")] if meta.get("studio") else [])
            
        strm_file_name = file_name + ".strm"
        if file_name in local_files:
            full_local_path = vfs_join(local_target_dir, strm_file_name)
            delete_url = f"plugin://plugin.video.cloudshare?action=delete_from_collection&path={urllib.parse.quote_plus(full_local_path)}"
            move_url = f"plugin://plugin.video.cloudshare?action=move_in_collection&path={urllib.parse.quote_plus(full_local_path)}"
            list_item.addContextMenuItems([
                ('Di chuyển phim', f'RunPlugin({move_url})'),
                ('Xóa khỏi Bộ sưu tập', f'RunPlugin({delete_url})')
            ])
            
        list_item.setProperty('IsPlayable', 'true')
        directory_items.append((play_url, list_item, False))
        
    xbmcplugin.addDirectoryItems(int(sys.argv[1]), directory_items, len(directory_items))
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)

def delete_from_collection(url):
    global _virtual_db_cache
    _virtual_db_cache = None
    import xbmcplugin
    
    params = parse_query_safely(url)
    target_path = params.get('path', '')
    
    if not target_path or not vfs_exists(target_path):
        xbmcgui.Dialog().ok("Thông báo", "Đường dẫn không tồn tại hoặc đã bị xóa.")
        return
        
    download_path = ADDON.getSetting("download_path")
    if not download_path:
        collection_dir = os.path.join(PROFILE_PATH, "Phim collection")
    else:
        download_path = xbmcvfs.translatePath(download_path)
        collection_dir = vfs_join(download_path, "Phim collection")
    
    norm_target = target_path.replace('\\', '/').lower()
    norm_collection = collection_dir.replace('\\', '/').lower()
    
    if not norm_target.startswith(norm_collection):
        xbmcgui.Dialog().ok("Thông báo", "Yêu cầu xóa không hợp lệ (nằm ngoài Bộ sưu tập).")
        return
        
    display_name = vfs_basename(target_path)
    
    choice = xbmcgui.Dialog().yesno("Xóa phim", f"Bạn có chắc chắn muốn xóa '{display_name}' khỏi Bộ sưu tập?")
    if choice:
        try:
            is_dir = False
            try:
                vfs_listdir(target_path)
                is_dir = True
            except Exception:
                pass
                
            if is_dir:
                vfs_rmtree(target_path)
            else:
                vfs_delete(target_path)
                
            xbmcgui.Dialog().notification("CloudShare", f"Đã xóa '{display_name}' thành công!", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            logError(f"[CloudShare] Error deleting {target_path}: {str(e)}")
            xbmcgui.Dialog().ok("Lỗi", f"Không thể xóa: {str(e)}")

def move_in_collection(url):
    global _virtual_db_cache
    _virtual_db_cache = None
    params = parse_query_safely(url)
    source_path = params.get('path', '')
    
    if not source_path or not vfs_exists(source_path):
        xbmcgui.Dialog().ok("Thông báo", "Tệp tin hoặc thư mục nguồn không tồn tại.")
        return
        
    download_path = ADDON.getSetting("download_path")
    if not download_path:
        collection_dir = os.path.join(PROFILE_PATH, "Phim collection")
    else:
        download_path = xbmcvfs.translatePath(download_path)
        collection_dir = vfs_join(download_path, "Phim collection")
    
    norm_source = source_path.replace('\\', '/').lower()
    norm_collection = collection_dir.replace('\\', '/').lower()
    
    if not norm_source.startswith(norm_collection):
        xbmcgui.Dialog().ok("Thông báo", "Yêu cầu di chuyển không hợp lệ (nằm ngoài Bộ sưu tập).")
        return
        
    subfolders = []
    try:
        dirs, files = vfs_listdir(collection_dir)
        for item in dirs:
            full_path = vfs_join(collection_dir, item)
            if not item.startswith('.') and full_path.replace('\\', '/').lower() != norm_source:
                subfolders.append(item)
    except Exception:
        pass
    subfolders.sort()
    
    dialog = xbmcgui.Dialog()
    options = ["Thư mục gốc của Bộ sưu tập", "+ Tạo thư mục phân loại mới..."] + subfolders
    choice = dialog.select("Di chuyển đến thư mục...", options)
    
    if choice == -1:
        return
        
    if choice == 0:
        dest_dir = collection_dir
    elif choice == 1:
        new_folder = dialog.input("Nhập tên thư mục phân loại mới (VD: Phim Hanh Dong)", defaultt="")
        if not new_folder:
            return
        new_folder = clean_filename(new_folder)
        dest_dir = vfs_join(collection_dir, new_folder)
        try:
            vfs_mkdirs(dest_dir)
        except Exception as e:
            alert(f"Không thể tạo thư mục: {str(e)}")
            return
    else:
        selected_folder = subfolders[choice - 2]
        dest_dir = vfs_join(collection_dir, selected_folder)
        
    if vfs_dirname(source_path) == dest_dir.replace('\\', '/'):
        xbmcgui.Dialog().ok("Thông báo", "Phim đã nằm trong thư mục này rồi.")
        return
        
    item_name = vfs_basename(source_path)
    dest_path = vfs_join(dest_dir, item_name)
    
    if vfs_exists(dest_path):
        confirm = dialog.yesno("Trùng tên", f"Tại thư mục đích đã tồn tại '{item_name}'. Bạn có muốn ghi đè?")
        if not confirm:
            return
        try:
            is_dir = False
            try:
                vfs_listdir(dest_path)
                is_dir = True
            except Exception:
                pass
                
            if is_dir:
                vfs_rmtree(dest_path)
            else:
                vfs_delete(dest_path)
        except Exception as e:
            xbmcgui.Dialog().ok("Lỗi", f"Không thể xóa tệp trùng tên: {str(e)}")
            return
            
    try:
        vfs_move(source_path, dest_path)
        xbmcgui.Dialog().notification("CloudShare", f"Đã di chuyển '{item_name}' thành công!", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        logError(f"[CloudShare] Error moving {source_path} to {dest_path}: {str(e)}")
        xbmcgui.Dialog().ok("Lỗi", f"Không thể di chuyển: {str(e)}")
