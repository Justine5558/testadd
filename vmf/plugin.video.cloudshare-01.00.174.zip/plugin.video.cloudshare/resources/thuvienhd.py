#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import html
import json
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import urlquick
import sys
import getlink

try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = 0

from resources.addon import ADDON, alert, notify, ADDON_PATH
from resources import fshare
from resources.thuviencine import tvcine_add_to_collection as thuvienhd_add_to_collection

# Load HD domain dynamically using the auto-healing domain resolver
from resources import domain_resolver
HD_HOST = domain_resolver.resolve_domain('thuvienhd', 'thuvienhd.top')
HD_DOMAIN = f"https://{HD_HOST}"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': f'{HD_DOMAIN}/'
}

def get_thuvienhd_menu():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    
    items = [
        {
            "label": "[COLOR gold][B]Phim Mới Cập Nhật[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/recent')}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": f"Các phim mới cập nhật trên {HD_HOST}"
        },
        {
            "label": "[COLOR yellow][B]Xu Hướng Phim (Hot)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/trending')}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim nổi bật và xem nhiều"
        },
        {
            "label": "[COLOR gold][B]Phim Bộ TVB Hồng Kông[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_tvb_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Menu Phim truyền hình bộ đài TVB Hồng Kông"
        },
        {
            "label": "[COLOR orchid][B]Phim Lẻ[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_phimle_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Menu Phim lẻ Fshare chất lượng cao"
        },
        {
            "label": "[COLOR springgreen][B]Phim Bộ[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_phimbo_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Menu Phim bộ dài tập Fshare"
        },
        {
            "label": "[COLOR lightskyblue][B]Phân Loại Thể Loại Phim[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_genres_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Phân loại phim theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_years_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Duyệt tìm phim theo năm sản xuất"
        },
        {
            "label": "[COLOR hotpink][B]Tìm Kiếm Phim[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_search",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim trên Thư Viện HD"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_years_menu(filter_type=None):
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    items = [
        {
            "label": "[COLOR gold][B]Thập niên 2020s (2020 - 2026)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=2020s{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim sản xuất từ năm 2020 đến nay"
        },
        {
            "label": "[COLOR orange][B]Thập niên 2010s (2010 - 2019)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=2010s{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim sản xuất từ năm 2010 đến 2019"
        },
        {
            "label": "[COLOR orange][B]Thập niên 2000s (2000 - 2009)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=2000s{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim sản xuất từ năm 2000 đến 2009"
        },
        {
            "label": "[COLOR orange][B]Thập niên 1990s (1990 - 1999)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=1990s{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim sản xuất từ năm 1990 đến 1999"
        },
        {
            "label": "[COLOR orange][B]Thập niên 1980s (1980 - 1989)[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=1980s{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim truyền hình/lẻ sản xuất từ năm 1980 đến 1989"
        },
        {
            "label": "[COLOR orange][B]Trước năm 1980[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_decade_menu&decade=pre1980{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Các phim sản xuất trước năm 1980"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_decade_menu(decade, filter_type=None):
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    
    years = []
    if decade == "2020s":
        years = list(range(2026, 2019, -1))
    elif decade == "2010s":
        years = list(range(2019, 2009, -1))
    elif decade == "2000s":
        years = list(range(2009, 1999, -1))
    elif decade == "1990s":
        years = list(range(1999, 1989, -1))
    elif decade == "1980s":
        years = list(range(1989, 1979, -1))
    elif decade == "pre1980":
        years = list(range(1979, 1969, -1))
        
    items = []
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    for y in years:
        items.append({
            "label": f"[COLOR yellow][B]Năm {y}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/release/' + str(y) + '/')}{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": f"Phim sản xuất năm {y}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}

def quote_url(url):
    if not url:
        return ""
    if not url.startswith("http"):
        return url
    try:
        parts = urllib.parse.urlparse(url)
        path = urllib.parse.quote(parts.path)
        quoted = urllib.parse.urlunparse((parts.scheme, parts.netloc, path, parts.params, parts.query, parts.fragment))
        if "thuvienhd" in parts.netloc:
            quoted += f"|Referer={HD_DOMAIN}/&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        return quoted
    except Exception:
        return url

def thuvienhd_browse(url, page=1, filter_type=None):
    base_url = url
    if "/page/" in url:
        base_url = re.sub(r'/page/\d+/?', '/', url)
        
    items = []
    current_page = page
    max_pages = 5
    has_next = True
    
    while len(items) < 8 and (current_page - page) < max_pages and has_next:
        if current_page > 1:
            if '?' in base_url:
                parts = base_url.split('?', 1)
                target_url = f"{parts[0].rstrip('/')}/page/{current_page}/?{parts[1]}"
            else:
                target_url = f"{base_url.rstrip('/')}/page/{current_page}/"
        else:
            target_url = base_url
            
        try:
            response = urlquick.get(target_url, headers=HEADERS, max_age=3600)
            html_content = response.text
        except Exception as e:
            if items:
                break
            alert(f"Lỗi khi tải trang phim: {str(e)}")
            return {"content_type": "movies", "items": []}
            
        articles = re.findall(r'<article[^>]*>.*?</article>', html_content, re.DOTALL)
        
        page_matched_items = []
        tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
        
        for art in articles:
            # Match absolute or relative phim links robustly and normalize them to HD_DOMAIN
            link_match = re.search(r'href="([^"]*/phim/[^"]+)"', art)
            link = link_match.group(1) if link_match else None
            if not link:
                continue
            if not link.startswith('http'):
                link = HD_DOMAIN + ('/' if not link.startswith('/') else '') + link
            else:
                parsed = urllib.parse.urlparse(link)
                link = urllib.parse.urlunparse((parsed.scheme, HD_HOST, parsed.path, parsed.params, parsed.query, parsed.fragment))
                
            title_match = re.search(r'<h3>\s*<a href="[^"]+">([^<]+)</a>\s*</h3>', art, re.DOTALL)
            if not title_match:
                title_match = re.search(r'class="title">\s*<a href="[^"]+">([^<]+)</a>', art, re.DOTALL)
            if not title_match:
                title_match = re.search(r'alt="([^"]+)"', art)
            title = html.unescape(title_match.group(1)).strip() if title_match else "Phim không tên"
            
            # Calculate is_series for this item
            is_series = False
            genres = re.findall(r'/genre/([^"]+)"', art)
            for g in genres:
                g_clean = g.strip('/')
                if 'series' in g_clean or 'phim-bo' in g_clean or 'phi-bo' in g_clean:
                    is_series = True
                    break
            if not is_series:
                is_series = 'kbd-series' in art or 'class="kbd-series"' in art
                
            is_movie = not is_series
            
            # Local filtering logic based on filter_type
            if filter_type:
                if filter_type == 'tvb':
                    is_hk = ("/genre/tvb" in art or 
                             "/genre/hongkong-series" in art or 
                             "/genre/hongkong" in art or
                             "/genre/hongkong-series" in url.lower())
                    if not is_hk:
                        is_hk = ("tvb" in title.lower() or 
                                 "hồng kông" in title.lower() or 
                                 "hong kong" in title.lower())
                    if not (is_hk and is_series):
                        continue
                elif filter_type == 'phim-le':
                    if not is_movie:
                        continue
                elif filter_type == 'series':
                    if not is_series:
                        continue
                        
            poster_match = re.search(r'<img[^>]*src="([^"]+)"', art)
            poster = poster_match.group(1) if poster_match else tvhd_icon
            if poster and poster.startswith("http"):
                poster = quote_url(poster)
                
            year_match = re.search(r'class="year"[^>]*>(?:<i[^>]*></i>)?\s*(\d{4})', art)
            if not year_match:
                year_match = re.search(r'</div>\s*<span>(\d{4})', art, re.DOTALL)
            if not year_match:
                year_match = re.search(r'<span>(\d{4})', art)
            year_str = year_match.group(1) if year_match else ""
            
            quality_match = re.search(r'class="quality_slider">([^<]+)</span>', art)
            quality = quality_match.group(1).strip() if quality_match else ""
            
            lang_match = re.search(r'class="kbd-quality">([^<]+)</span>', art)
            lang = lang_match.group(1).strip() if lang_match else ""
            
            series_match = re.search(r'class="kbd-series">([^<]+)</span>', art)
            series = series_match.group(1).strip() if series_match else ""
            
            label_parts = []
            if quality:
                label_parts.append(f"[COLOR yellow][{quality}][/COLOR]")
            if lang:
                label_parts.append(f"[COLOR lime][{lang}][/COLOR]")
            if series:
                label_parts.append(f"[COLOR hotpink][{series}][/COLOR]")
                
            label_parts.append(title)
            if year_str:
                label_parts.append(f"({year_str})")
                
            label = " ".join(label_parts)
            
            plot_match = re.search(r'<div class="animation-1 dtinfo">.*?<div class="texto">([^<]+)</div>', art, re.DOTALL)
            plot = html.unescape(plot_match.group(1)).strip() if plot_match else ""
            
            path = f"plugin://plugin.video.cloudshare?action=thuvienhd_play&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)}&is_series={str(is_series).lower()}"
            
            context_menu = [
                ("Thêm vào Bộ sưu tập cá nhân", f"RunPlugin(plugin://plugin.video.cloudshare?action=thuvienhd_add_collection&url={urllib.parse.quote_plus(link)}&title={urllib.parse.quote_plus(title)})")
            ]
            
            item = {
                "label": label,
                "is_playable": not is_series,
                "path": path,
                "thumbnail": poster,
                "icon": poster,
                "label2": title,
                "info": {
                    "plot": plot,
                    "title": title
                },
                "art": {
                    "thumb": poster,
                    "icon": poster,
                    "poster": poster
                },
                "context_menu": context_menu
            }
            
            if year_str.isdigit():
                item["info"]["year"] = int(year_str)
                
            page_matched_items.append(item)
            
        items.extend(page_matched_items)
        
        # Check next page
        next_page = current_page + 1
        next_page_str = f"/page/{next_page}"
        if next_page_str in html_content:
            has_next = True
            current_page += 1
        else:
            has_next = False
            
    if has_next:
        next_page = current_page
        filter_query = f"&filter_type={filter_type}" if filter_type else ""
        next_path = f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(base_url)}&page={next_page}{filter_query}"
        items.append({
            "label": "[COLOR yellow]Trang tiếp theo >>[/COLOR]",
            "is_playable": False,
            "path": next_path,
            "thumbnail": "DefaultFolder.png",
            "icon": "DefaultFolder.png",
            "label2": "Xem các phim ở trang tiếp theo",
            "info": {"plot": "Nhấn để chuyển sang trang tiếp theo"}
        })
        
    return {"content_type": "movies", "items": items}

def thuvienhd_search():
    dialog = xbmcgui.Dialog()
    query = dialog.input("Nhập tên phim cần tìm (Thư Viện HD)", defaultt="")
    if not query:
        return
        
    query = query.strip()
    search_url = f"{HD_DOMAIN}/?s={urllib.parse.quote_plus(query)}"
    xbmc.executebuiltin(f"Container.Update(plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(search_url)})")

def thuvienhd_play_or_add(movie_url, action='play', title=None, is_series=False):
    # 1. Fetch movie detail page
    try:
        detail_resp = urlquick.get(movie_url, headers=HEADERS, max_age=86400)
        detail_html = detail_resp.text
    except Exception as e:
        alert(f"Không thể kết nối tới Thư Viện HD: {str(e)}")
        if action == 'play':
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False
        
    # 2. Extract Fshare links only from the links_table block to avoid promotional links
    links_block_match = re.search(r'<div[^>]*class="links_table"[^>]*>.*?</div>\s*</div>', detail_html, re.DOTALL)
    links_block = links_block_match.group(0) if links_block_match else detail_html
    
    pattern = r'<a[^>]*href="(https?://(?:www\.)?fshare\.vn/(?:file|folder)/[A-Za-z0-9]+)"[^>]*>(.*?)</a>'
    matches = re.findall(pattern, links_block, re.DOTALL)
    
    if not matches:
        # Fallback to entire html but filter out app link S8F58F57CTR5
        matches = re.findall(pattern, detail_html, re.DOTALL)
        matches = [m for m in matches if "S8F58F57CTR5" not in m[0]]
        
    if not matches:
        alert("Không tìm thấy link Fshare trên trang chi tiết.")
        if action == 'play':
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False
        
    fshare_links = []
    seen = set()
    for url, text in matches:
        clean_url = url.strip()
        if clean_url in seen or "S8F58F57CTR5" in clean_url:
            continue
        seen.add(clean_url)
        clean_text = re.sub(r'<[^>]*>', '', text).strip()
        clean_text = re.sub(r'\s+', ' ', clean_text)
        if not clean_text or clean_text.lower() == "download" or clean_text.lower() == "download --click--":
            clean_text = "Nguồn Fshare"
        fshare_links.append((clean_url, clean_text))
        
    if not fshare_links:
        alert("Không tìm thấy link Fshare hợp lệ.")
        if action == 'play':
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False
        
    if action == 'play' and is_series and len(fshare_links) > 1:
        # Render multiple links directly as playable items in the current directory!
        import loadlistitem
        import xbmcgui
        list_items = []
        for idx, (url, text) in enumerate(fshare_links):
            label = text
            if not label or label.lower() == "nguồn fshare":
                label = f"Tập {idx+1}"
            
            if "/folder/" in url:
                is_folder = True
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(url)}"
                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {'title': label, 'mediatype': 'season'})
                li.setProperty('IsPlayable', 'false')
            else:
                is_folder = False
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(url)}"
                li = xbmcgui.ListItem(label=label)
                li.setInfo('video', {'title': label, 'mediatype': 'episode'})
                li.setProperty('IsPlayable', 'true')
                
            tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
            li.setArt({'thumb': tvhd_icon, 'icon': tvhd_icon, 'poster': tvhd_icon})
            list_items.append((play_url, li, is_folder))
            
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except Exception:
            pass
        xbmcplugin.setContent(HANDLE, 'episodes')
        xbmcplugin.addDirectoryItems(HANDLE, list_items, len(list_items))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return True

    if len(fshare_links) == 1:
        fshare_url = fshare_links[0][0]
    else:
        labels = [f"Nguồn {idx+1}: {text} ({'Thư mục' if '/folder/' in url else 'Tệp tin'})" for idx, (url, text) in enumerate(fshare_links)]
        selected = xbmcgui.Dialog().select("Chọn liên kết Fshare (Thư Viện HD)", labels)
        if selected == -1:
            if action == 'play':
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return False
        fshare_url = fshare_links[selected][0]
        
    # 3. Execute action
    if action == 'play':
        if is_series:
            # We are handling a folder listing request.
            # We must not resolve URL via setResolvedUrl. We must return directory items.
            import loadlistitem
            from resources import cache_utils
            
            if "/folder/" in fshare_url:
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                data = cache_utils.cache_data(fshare_url)
                if data is not None and data.get("items"):
                    loadlistitem.list_item_main(data)
                else:
                    # Fallback: list a single folder item
                    import xbmcgui
                    li = xbmcgui.ListItem(label=title)
                    li.setInfo('video', {'title': title, 'mediatype': 'season'})
                    li.setProperty('IsPlayable', 'false')
                    play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                    xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=True)
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                return True
            else:
                # Fshare URL is a single file. List it directly.
                import xbmcgui
                li = xbmcgui.ListItem(label=title)
                li.setInfo('video', {'title': title, 'mediatype': 'episode'})
                li.setProperty('IsPlayable', 'true')
                tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
                li.setArt({'thumb': tvhd_icon, 'icon': tvhd_icon, 'poster': tvhd_icon})
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                xbmcplugin.setContent(HANDLE, 'episodes')
                xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                return True
        else:
            # Single-click play action for movies (is_series = False)
            if "/folder/" in fshare_url:
                # Cancel resolve if called in play resolve mode, and end directory if called in browse mode
                try:
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                except Exception:
                    pass
                try:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
                except Exception:
                    pass
                play_url = f"plugin://plugin.video.cloudshare?action=play&url={urllib.parse.quote_plus(fshare_url)}"
                xbmc.executebuiltin(f"Container.Update({play_url})")
                return True
            else:
                # Resolve file download link in-stream
                resolved_link = getlink.get(fshare_url)
                if resolved_link:
                    item = xbmcgui.ListItem(path=resolved_link)
                    item.setMimeType('video/mp4')
                    item.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(HANDLE, True, item)
                    return True
                else:
                    alert("Không thể giải mã liên kết Fshare để phát.")
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                    return False

    elif action == 'add':
        if not title:
            title_match = re.search(r'<h1[^>]*class="entry-title"[^>]*>([^<]+)</h1>', detail_html)
            title = title_match.group(1) if title_match else "Phim_Tvhd"
        title = html.unescape(title)
        title = re.sub(r'[\\/*?:"<>|#]', "", title)
        thuvienhd_add_to_collection(fshare_url, title)
        return False

def get_thuvienhd_tvb_menu():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Bộ TVB Hồng Kông[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/genre/hongkong-series/')}&filter_type=tvb",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Xem toàn bộ phim bộ truyền hình đài TVB Hồng Kông"
        },
        {
            "label": "[COLOR gold][B]Phim Kiếm Hiệp TVB (Fshare)[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=fshare_special_json_list&file=fshare_kim_dung_matches.json&page=1",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tuyển tập phim kiếm hiệp Kim Dung đài TVB Hồng Kông (Fshare)"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_years_menu&filter_type=tvb",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim bộ TVB Hồng Kông theo năm sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_phimle_menu():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Lẻ[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/genre/phim-le')}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Xem toàn bộ phim lẻ Fshare chất lượng cao"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Thể Loại[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_genres_menu&filter_type=phim-le",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim lẻ theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_years_menu&filter_type=phim-le",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim lẻ theo năm sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_phimbo_menu():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    items = [
        {
            "label": "[COLOR gold][B]Xem Tất Cả Phim Bộ[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/genre/series')}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Xem toàn bộ phim bộ dài tập Fshare"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Thể Loại[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_genres_menu&filter_type=series",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim bộ theo thể loại"
        },
        {
            "label": "[COLOR gold][B]Duyệt Theo Năm Sản Xuất[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_years_menu&filter_type=series",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Tìm phim bộ theo năm sản xuất"
        },
        {
            "label": "[COLOR gold][B]Phân Loại Theo Quốc Gia[/B][/COLOR]",
            "is_playable": False,
            "path": "plugin://plugin.video.cloudshare?action=thuvienhd_phimbo_countries_menu",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": "Xem phim bộ phân loại theo các quốc gia sản xuất"
        }
    ]
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_phimbo_countries_menu():
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    countries = [
        ("Phim Bộ Hàn Quốc", "korean-series"),
        ("Phim Bộ Mỹ", "us-tv-series"),
        ("Phim Bộ Trung Quốc", "phim-bo-trung-quoc"),
        ("Phim Bộ Hồng Kông", "hongkong-series"),
        ("Phim Bộ Nhật Bản", "phim-bo-nhat-ban"),
        ("Phim Bộ Đài Loan", "phim-bo-dai-loan"),
        ("Phim Bộ Thái Lan", "phim-bo-thai-lan"),
        ("Phim Bộ Ấn Độ", "phim-bo-an-do"),
        ("Phim Bộ Anh", "phim-bo-anh"),
        ("Phim Bộ Pháp", "phim-bo-phap"),
        ("Phim Bộ Tây Ban Nha", "phim-bo-tay-ban-nha"),
        ("Phim Bộ Thổ Nhĩ Kỳ", "phim-bo-tho-nhi-ky"),
        ("Phim Bộ Việt Nam", "phim-bo-viet-nam"),
        ("Phim Bộ Ai Cập", "phim-bo-ai-cap"),
        ("Phim Bộ Ả Rập", "phim-bo-a-rap"),
        ("Phi Bộ Nigeria", "phi-bo-nigeria")
    ]
    items = []
    for name, slug in countries:
        items.append({
            "label": f"[COLOR gold][B]{name}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/genre/' + slug + '/')}&filter_type=series",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": f"Phim bộ {name}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}

def get_thuvienhd_genres_menu(filter_type=None):
    tvhd_icon = os.path.join(ADDON_PATH, 'resources', 'images', 'tvhd.jpeg')
    genres = [
        ("Phim Hành Động", "action"),
        ("Phim Viễn Tưởng", "sci-fi"),
        ("Phim Kinh Dị", "horror"),
        ("Phim Hài Hước", "comedy"),
        ("Phim Cao Bồi", "western"),
        ("Phim Chiến Tranh", "war"),
        ("Phim Chính Kịch", "chinh-kich"),
        ("Phim Cổ Trang", "co-trang-phim"),
        ("Phim Gia Đình", "gia-dinh"),
        ("Phim Giáng Sinh", "giang-sinh"),
        ("Phim Gây Cấn", "gay-can"),
        ("Phim Hình Sự", "crime"),
        ("Phim Hoạt Hình", "animation"),
        ("Phim Huyền Bí / Trinh Thám", "mystery"),
        ("Phim Lãng Mạn / Tình Cảm", "romance"),
        ("Phim Lịch Sử", "history"),
        ("Phim Nhạc Kịch", "nhac-kich"),
        ("Phim Phiêu Lưu", "adventure"),
        ("Phim Tài Liệu", "documentary"),
        ("Phim Rùng Rợn / Gây Cấn", "thriller"),
        ("Phim Tâm Lý", "drama"),
        ("Phim Thần Thoại", "fantasy"),
        ("Phim Thể Thao", "the-thao"),
        ("Phim Thiếu Nhi", "family"),
        ("Phim Võ Thuật", "vo-thuat-phim-2")
    ]
    items = []
    filter_query = f"&filter_type={filter_type}" if filter_type else ""
    for name, slug in genres:
        items.append({
            "label": f"[COLOR gold][B]{name}[/B][/COLOR]",
            "is_playable": False,
            "path": f"plugin://plugin.video.cloudshare?action=thuvienhd_browse&url={urllib.parse.quote_plus(HD_DOMAIN + '/genre/' + slug)}{filter_query}",
            "thumbnail": tvhd_icon,
            "icon": tvhd_icon,
            "label2": f"Thể loại {name}"
        })
    return {"content_type": "", "items": items, "cache_to_disc": False}
