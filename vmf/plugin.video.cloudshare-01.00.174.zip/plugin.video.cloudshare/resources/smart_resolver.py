import concurrent.futures
import re
import urllib.parse
import urllib.request
import urllib.error
from resources import ophim_api
from resources import fshare
import xbmc
import xbmcgui

def clean_title_for_search(raw_title):
    # Dọn dẹp tiêu đề lộn xộn từ Google Sheet để tìm kiếm chính xác
    # VD: "Trò Chơi Con Mực - Squid Game S01-S02 2024 (Lồng tiếng - Phụ đề)" -> "Squid Game"
    
    # Xóa các tag trong ngoặc () hoặc []
    title = re.sub(r'\(.*?\)', '', raw_title)
    title = re.sub(r'\[.*?\]', '', title)
    
    # Tách theo dấu gạch ngang (thường Tiếng Anh đứng sau)
    parts = title.split('-')
    if len(parts) > 1:
        # Lấy phần sau dấu gạch ngang đầu tiên, hy vọng là tên Tiếng Anh hoặc tên sạch hơn
        title = parts[1]
    else:
        title = parts[0]
        
    # Xóa các chữ S01, S02, Tập, Full, Vietsub, Thuyết minh
    remove_words = ['s01', 's02', 's03', 's04', 'tập', 'full', 'vietsub', 'thuyết minh', 'lồng tiếng', 'phụ đề', 'mới nhất']
    for word in remove_words:
        title = re.sub(r'(?i)\b' + word + r'\b.*', '', title)
        
    # Xóa năm (4 chữ số)
    title = re.sub(r'\b\d{4}\b', '', title)
    
    return title.strip()

def resolve_fshare_link(link):
    # Cố gắng lấy link stream từ Fshare
    try:
        token, session_id = fshare.check_session()
        if token and session_id:
            direct_link = fshare.get_download_link(token, session_id, link)
            if direct_link and "http" in direct_link:
                return direct_link
    except Exception as e:
        xbmc.log(f"[CloudShare] Fshare Resolve Error: {e}", xbmc.LOGERROR)
    return None

def resolve_nested_m3u8(url):
    """
    Tự động phân giải danh sách phát m3u8 lồng nhau (variant playlist)
    để lấy liên kết trực tiếp đến luồng phân giải cao nhất.
    Giúp Kodi phát trực tiếp cực nhanh, bỏ qua khởi tạo adaptive player chậm chạp.
    """
    if not url:
        return url
    try:
        clean_url = url.split('|')[0]
        req = urllib.request.Request(clean_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            content = resp.read(4096).decode('utf-8', errors='ignore')
            if "#EXT-X-STREAM-INF" in content:
                lines = content.splitlines()
                best_url = None
                best_bandwidth = -1
                for i, line in enumerate(lines):
                    if line.startswith("#EXT-X-STREAM-INF"):
                        bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                        bw = int(bw_match.group(1)) if bw_match else 0
                        if i + 1 < len(lines):
                            next_line = lines[i+1].strip()
                            if next_line and not next_line.startswith("#"):
                                if bw > best_bandwidth:
                                    best_bandwidth = bw
                                    best_url = next_line
                if best_url:
                    resolved = urllib.parse.urljoin(clean_url, best_url)
                    # Giữ nguyên phần query/headers phía sau (nếu có)
                    if '|' in url:
                        resolved += '|' + url.split('|', 1)[1]
                    xbmc.log(f"[CloudShare] Resolved nested variant playlist: {resolved}", xbmc.LOGINFO)
                    return resolved
    except Exception as e:
        xbmc.log(f"[CloudShare] Error resolving nested variant playlist: {e}", xbmc.LOGERROR)
    return url

def find_ophim_fallback(title):
    clean_name = clean_title_for_search(title)
    xbmc.log(f"[CloudShare] Fallback Search Ophim for: {clean_name}", xbmc.LOGINFO)
    
    items, _ = ophim_api.search_movies(clean_name)
    if items and len(items) > 0:
        # Lấy phim đầu tiên (phù hợp nhất)
        first_movie = items[0]
        slug = first_movie.get('slug')
        if slug:
            links = ophim_api.get_m3u8_links(slug)
            if links and len(links) > 0:
                return resolve_nested_m3u8(links[0]['link']) # Trả về tập 1 hoặc link đầu tiên
    return None

def resolve_community_link(title, fshare_link):
    """
    Thuật toán cho mục Cộng Đồng (Fshare ưu tiên, Ophim dự phòng)
    """
    # Ping Fshare trước
    direct_link = resolve_fshare_link(fshare_link)
    if direct_link:
        return direct_link, "fshare"
        
    # Nếu Fshare lỗi/không có VIP, tìm Ophim
    xbmc.log("[CloudShare] Fshare link failed/dead. Triggering Ophim Fallback.", xbmc.LOGINFO)
    ophim_link = find_ophim_fallback(title)
    if ophim_link:
        return ophim_link, "ophim"
        
    return None, None

def check_link_alive_and_quality(url):
    if not url:
        return False, None
    try:
        clean_url = url.split('|')[0]
        req = urllib.request.Request(clean_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}, method='GET')
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            if resp.status == 200:
                content = resp.read(4096).decode('utf-8', errors='ignore')
                resolutions = re.findall(r'RESOLUTION=(\d+)x(\d+)', content)
                quality = None
                if resolutions:
                    best_res = max(resolutions, key=lambda r: int(r[0]))
                    w, h = int(best_res[0]), int(best_res[1])
                    if w >= 3840:
                        quality = "4k"
                    elif w >= 2560:
                        quality = "1440p"
                    elif w >= 1920:
                        quality = "1080p"
                    elif w >= 1280:
                        quality = "720p"
                    elif w >= 854:
                        quality = "480p"
                    else:
                        quality = f"{h}p"
                else:
                    url_lower = url.lower()
                    for q in ["2160p", "1080p", "720p", "480p", "360p", "4k"]:
                        if q in url_lower:
                            quality = q
                            break
                return True, quality
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False, None
        return True, None
    except:
        return False, None

def extract_quality_tags(filename):
    filename_lower = filename.lower()
    qualities = []
    
    for q in ["2160p", "1080p", "720p", "480p", "360p", "4k"]:
        if q in filename_lower:
            qualities.append(q.upper())
            break
            
    for s in ["bluray", "web-dl", "webdl", "hdtv", "cam", "telesync", "ts"]:
        if s in filename_lower:
            qualities.append(s.upper().replace("WEBDL", "WEB-DL"))
            break
            
    for f in ["hdr", "atmos", "5.1", "dd5.1"]:
        if f in filename_lower:
            qualities.append(f.upper())
            
    if qualities:
        return f"[{' | '.join(qualities)}]"
    return ""

def clean_query_term(term):
    if not term:
        return ""
    term = re.sub(r'[:/\\?*"\']', ' ', term)
    term = re.sub(r'\s+', ' ', term)
    return term.strip()

def check_title_match(filename, movie_name, origin_name, year):
    try:
        import remove_accents
    except ImportError:
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        import remove_accents

    filename_clean = remove_accents.remove_accents(filename).lower()
    
    if year:
        year_str = str(year)
        if year_str not in filename_clean:
            prev_year = str(int(year) - 1)
            next_year = str(int(year) + 1)
            if prev_year not in filename_clean and next_year not in filename_clean:
                return False
                
    def contains_all_keywords(name_str):
        if not name_str:
            return False
        name_no_accents = remove_accents.remove_accents(name_str)
        clean_name = re.sub(r'[^a-zA-Z0-9\s]', ' ', name_no_accents).lower()
        words = [w for w in clean_name.split() if len(w) > 1 or w.isdigit()]
        if not words:
            return False
        for w in words:
            if w not in filename_clean:
                return False
        return True
        
    if contains_all_keywords(movie_name) or contains_all_keywords(origin_name):
        return True
        
    return False

def fetch_fshare_items_for_movie(movie_name, origin_name, year):
    from resources import search
    queries = []
    
    clean_origin = clean_query_term(origin_name)
    clean_vn = clean_query_term(movie_name)
    
    if clean_origin:
        if year:
            queries.append(f"{clean_origin} {year}")
        queries.append(clean_origin)
    if clean_vn and clean_vn != clean_origin:
        if year:
            queries.append(f"{clean_vn} {year}")
        queries.append(clean_vn)
        
    seen = set()
    unique_queries = []
    for q in queries:
        if q not in seen:
            seen.add(q)
            unique_queries.append(q)
            
    unique_queries = unique_queries[:2]
    fshare_results = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(unique_queries)) as executor:
        futures = {executor.submit(search.searchcloudshare, q): q for q in unique_queries}
        for future in concurrent.futures.as_completed(futures):
            try:
                res = future.result()
                if res and "items" in res:
                    fshare_results.extend(res["items"])
            except Exception as e:
                xbmc.log(f"[CloudShare] Fshare search error: {e}", xbmc.LOGERROR)
                
    unique_items = []
    seen_urls = set()
    for item in fshare_results:
        if not item.get("is_playable"):
            continue
            
        path = item.get("path", "")
        if not path:
            continue
            
        fshare_url = ""
        if 'url=' in path:
            fshare_url = path.split('url=')[1].split('&')[0]
        if not fshare_url:
            continue
            
        if fshare_url not in seen_urls:
            seen_urls.add(fshare_url)
            label = item.get("label", "")
            clean_label = re.sub(r'\[COLOR.*?\]|\[/COLOR\]', '', label)
            if check_title_match(clean_label, movie_name, origin_name, year):
                item['fshare_url'] = fshare_url
                item['clean_label'] = clean_label
                unique_items.append(item)
                
    return unique_items

def resolve_api_link(title, ophim_slug):
    """
    Thuật toán cho mục Xu Hướng (Ophim ưu tiên, Fshare là lựa chọn 4K)
    """
    # 1. Fetch movie detail from Ophim API (cached)
    movie, episodes = ophim_api.get_movie_detail(ophim_slug)
    
    movie_name = movie.get("name", title) if movie else title
    origin_name = movie.get("origin_name", "") if movie else ""
    year = str(movie.get("year", "")) if movie else ""
    
    # 2. Extract web m3u8 links
    links = []
    if episodes and len(episodes) > 0:
        for ep in episodes:
            server_name = ep.get("server_name", "Default")
            server_data = ep.get("server_data", [])
            for sd in server_data:
                links.append({
                    "name": sd.get("name", "1"),
                    "link": sd.get("link_m3u8", ""),
                    "filename": sd.get("filename", ""),
                    "server": server_name
                })
                
    import xbmcaddon
    enable_fshare = xbmcaddon.Addon().getSetting('enable_fshare_fallback') != 'false'
    
    dialog_options = []
    
    # Add Web options directly without pinging to load instantly!
    for l in links:
        srv = l.get("server", "Default").replace("#", "")
        name = l.get("name", "Full")
        dialog_options.append(f"[COLOR lightskyblue][WEB SOURCE][/COLOR] {srv} ({name})")
        
    # Add Fshare Search fallback option at the end
    if enable_fshare:
        dialog_options.append("[COLOR gold][FSHARE - TÌM KIẾM BẢN ĐẸP (4K / 1080P)...][/COLOR]")
        
    if not dialog_options:
        # Fallback to Fshare search prompt if no links at all
        dialog = xbmcgui.Dialog()
        if dialog.yesno("Lỗi nguồn phim", "Không tìm thấy luồng phát nào cho phim này.\nBạn có muốn tìm kiếm phim này trên Fshare không?"):
            return "fshare_search", "fshare_search"
        return None, None
        
    # If Fshare fallback is disabled and only 1 Web option, play it directly!
    if not enable_fshare and len(links) == 1:
        return resolve_nested_m3u8(links[0]['link']), "ophim"
        
    # Present dialog for instant server selection
    dialog = xbmcgui.Dialog()
    idx = dialog.select("Chọn Server phát cho: " + title, dialog_options)
    if idx >= 0:
        if enable_fshare and idx == len(links):
            # User selected the Fshare Search option -> run Fshare search now!
            xbmcgui.Dialog().notification("CloudShare", "Đang tìm kiếm bản Fshare...", xbmcgui.NOTIFICATION_INFO, 3000)
            fshare_options = fetch_fshare_items_for_movie(movie_name, origin_name, year)
            if not fshare_options:
                xbmcgui.Dialog().ok("Kết quả", "Không tìm thấy bản Fshare nào cho phim này.")
                # Loop back to select Web source
                return resolve_api_link(title, ophim_slug)
                
            # Show Fshare choices
            fshare_dialog_options = []
            for item in fshare_options:
                label = item.get("clean_label", "")
                q_tag = extract_quality_tags(label)
                q_str = f"[COLOR yellow]{q_tag}[/COLOR] " if q_tag else ""
                size_bytes = item.get("info", {}).get("size")
                size_str = ""
                if size_bytes:
                    try:
                        size_gb = float(size_bytes) / (1024 * 1024 * 1024)
                        size_str = f" - {size_gb:.2f} GB"
                    except:
                        pass
                fshare_dialog_options.append(f"[COLOR gold][FSHARE][/COLOR] {q_str}{label}{size_str}")
                
            fshare_idx = dialog.select("Chọn bản Fshare phát cho: " + title, fshare_dialog_options)
            if fshare_idx >= 0:
                selected_item = fshare_options[fshare_idx]
                fshare_url = selected_item['fshare_url']
                xbmcgui.Dialog().notification("CloudShare", "Đang tải link Fshare...", xbmcgui.NOTIFICATION_INFO, 2000)
                direct_link = resolve_fshare_link(fshare_url)
                if direct_link:
                    return direct_link, "fshare"
                else:
                    xbmcgui.Dialog().ok("Lỗi", "Không thể lấy link Fshare VIP. Vui lòng thử lại hoặc chọn nguồn khác.")
            
            # If Fshare failed or user canceled, show the options again
            return resolve_api_link(title, ophim_slug)
        else:
            # User selected a Web option
            return resolve_nested_m3u8(links[idx]['link']), "ophim"
            
    return None, None
