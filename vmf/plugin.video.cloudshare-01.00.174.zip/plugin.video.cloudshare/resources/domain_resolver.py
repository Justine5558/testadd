#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import urllib.request
import urllib.parse
import urllib.error
import ssl
import xbmc
from resources.addon import ADDON

# Candidate domains in priority order
CANDIDATES = {
    'thuvienhd': [
        'thuvienhd.top',
        'thuvienhd.xyz',
        'thuvienhd.life',
        'thuvienhd.com',
        'thuvienhd.net',
        'thuvienhd.org'
    ],
    'thuviencine': [
        'thuviencine.xyz',
        'thuviencine.com',
        'thuviencine.live',
        'thuviencine.org',
        'thuviencine.net',
        'thuviencine.top'
    ]
}

# Cache to avoid checking repeatedly within the same session
_resolved_cache = {}

def clean_domain(domain):
    if not domain:
        return ""
    return domain.strip().replace('https://', '').replace('http://', '').split('/')[0]

def verify_domain(domain, site_key):
    """
    Verifies if a domain is active and serves the expected website.
    """
    domain = clean_domain(domain)
    if not domain:
        return False
        
    url = f"https://{domain}/"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    # Create TLS bypass context for older devices
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    req = urllib.request.Request(url, headers=headers)
    try:
        xbmc.log(f"[CloudShare] Verifying domain {domain} for {site_key}...", xbmc.LOGINFO)
        with urllib.request.urlopen(req, context=ctx, timeout=3.5) as response:
            code = response.getcode()
            final_url = response.geturl()
            
            # Avoid domain parking pages by checking the final domain
            final_domain = clean_domain(final_url)
            if "ww1." in final_domain or "ww2." in final_domain or "parking" in final_domain:
                xbmc.log(f"[CloudShare] Domain {domain} redirected to a parking domain: {final_url}", xbmc.LOGWARNING)
                return False
                
            if code in [200, 301, 302]:
                html_snippet = response.read(1500).decode('utf-8', errors='ignore').lower()
                
                # Check for signatures in the HTML snippet to verify authenticity
                if site_key == 'thuvienhd':
                    if any(sig in html_snippet for sig in ['thuvienhd', 'item movies', 'article', 'phim']):
                        return True
                elif site_key == 'thuviencine':
                    if any(sig in html_snippet for sig in ['thuviencine', 'movies', 'article', 'phim']):
                        return True
                        
                xbmc.log(f"[CloudShare] Domain {domain} responded but signature check failed.", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[CloudShare] Error verifying domain {domain}: {str(e)}", xbmc.LOGWARNING)
        
    return False

def resolve_domain(site_key, default_domain):
    """
    Resolves the domain dynamically. If the configured domain in settings fails,
    it probes the candidate domains and updates settings if a working one is found.
    """
    global _resolved_cache
    
    # 1. Check runtime cache
    if site_key in _resolved_cache:
        return _resolved_cache[site_key]
        
    # 2. Get domain from settings
    setting_id = f"{site_key}_domain"
    configured_domain = clean_domain(ADDON.getSetting(setting_id))
    
    if not configured_domain:
        configured_domain = clean_domain(default_domain)
        
    xbmc.log(f"[CloudShare] Resolving domain for {site_key}. Configured: {configured_domain}", xbmc.LOGINFO)
    
    # 3. Check if configured domain works
    if verify_domain(configured_domain, site_key):
        _resolved_cache[site_key] = configured_domain
        return configured_domain
        
    xbmc.log(f"[CloudShare] Configured domain {configured_domain} for {site_key} is unreachable. Probing candidates...", xbmc.LOGWARNING)
    
    # 4. Probe candidates
    candidates = CANDIDATES.get(site_key, [])
    for candidate in candidates:
        candidate_clean = clean_domain(candidate)
        if candidate_clean == configured_domain:
            continue
            
        if verify_domain(candidate_clean, site_key):
            xbmc.log(f"[CloudShare] Found working domain for {site_key}: {candidate_clean}. Updating settings.", xbmc.LOGINFO)
            try:
                ADDON.setSetting(setting_id, candidate_clean)
            except Exception as e:
                xbmc.log(f"[CloudShare] Failed to update setting {setting_id}: {str(e)}", xbmc.LOGERROR)
            _resolved_cache[site_key] = candidate_clean
            return candidate_clean
            
    # 5. Fallback to default
    xbmc.log(f"[CloudShare] No working candidates found for {site_key}. Falling back to default: {default_domain}", xbmc.LOGWARNING)
    default_clean = clean_domain(default_domain)
    _resolved_cache[site_key] = default_clean
    return default_clean
