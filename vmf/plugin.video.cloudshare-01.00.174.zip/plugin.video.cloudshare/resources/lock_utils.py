import hashlib
import json
import requests
import time
import xbmc
import xbmcgui
import xbmcaddon
from resources.addon import ADDON, alert, notify, logError

def get_public_ip():
    # Try api.ipify.org
    try:
        r = requests.get('https://api.ipify.org?format=json', timeout=2.0)
        if r.status_code == 200:
            ip = r.json().get('ip')
            if ip:
                ADDON.setSetting('fshare_cached_ip', ip)
                return ip
    except:
        pass

    # Try ipinfo.io as fallback
    try:
        r = requests.get('https://ipinfo.io/ip', timeout=2.0)
        if r.status_code == 200:
            ip = r.text.strip()
            if ip:
                ADDON.setSetting('fshare_cached_ip', ip)
                return ip
    except:
        pass

    # Fallback to cached IP
    cached = ADDON.getSetting('fshare_cached_ip')
    if cached:
        return cached
    return "127.0.0.1"

def get_ntfy_topic(username):
    if not username:
        return None
    md5_hash = hashlib.md5(username.strip().lower().encode('utf-8')).hexdigest()
    return f"cloudshare_lock_{md5_hash}"

def fetch_playing_state(username):
    topic = get_ntfy_topic(username)
    if not topic:
        return None
    try:
        r = requests.get(f"https://ntfy.sh/{topic}/json?poll=1", timeout=3.0)
        if r.status_code == 200:
            lines = r.text.strip().split("\n")
            # Loop from bottom up to find the last valid message event
            for line in reversed(lines):
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                    if obj.get("event") == "message":
                        msg_text = obj.get("message", "")
                        state = json.loads(msg_text)
                        return state
                except:
                    pass
    except Exception as e:
        logError(f"[Anti-IP Lock] Error fetching state: {e}")
    return None

def publish_state(username, state_dict):
    topic = get_ntfy_topic(username)
    if not topic:
        return False
    try:
        # Use headers to disable firebase/ios push alerts and keep it lightweight on ntfy.sh
        headers = {
            "X-Title": "CloudShare Lock State",
            "X-Priority": "1"
        }
        r = requests.post(f"https://ntfy.sh/{topic}", data=json.dumps(state_dict), headers=headers, timeout=3.0)
        return r.status_code == 200
    except Exception as e:
        logError(f"[Anti-IP Lock] Error publishing state: {e}")
        return False

def update_keep_alive(username, ip, title):
    state = {
        "device_name": ADDON.getSetting('anti_ip_lock_device_name') or "Kodi Device",
        "ip": ip,
        "timestamp": int(time.time()),
        "status": "playing",
        "title": title
    }
    publish_state(username, state)

def release_lock(username):
    if not username:
        return
    ip = get_public_ip()
    state = {
        "device_name": ADDON.getSetting('anti_ip_lock_device_name') or "Kodi Device",
        "ip": ip,
        "timestamp": int(time.time()),
        "status": "idle",
        "title": ""
    }
    publish_state(username, state)
    ADDON.setSetting('fshare_active_playing', 'false')

def check_and_acquire_lock(username, title):
    if not username:
        return True
    
    if ADDON.getSetting('anti_ip_lock') != 'true':
        return True

    current_ip = get_public_ip()
    device_name = ADDON.getSetting('anti_ip_lock_device_name') or "Kodi Device"
    now = int(time.time())

    # Fetch last state
    last_state = fetch_playing_state(username)
    if last_state:
        status = last_state.get("status")
        last_ip = last_state.get("ip")
        last_device = last_state.get("device_name", "Thiết bị khác")
        last_title = last_state.get("title", "Video Fshare")
        last_time = last_state.get("timestamp", 0)
        elapsed = now - last_time

        if status == "playing" and elapsed < 10800: # 3 hours
            # Account is being used elsewhere
            if last_ip != current_ip:
                elapsed_min = elapsed // 60
                elapsed_str = f"{elapsed_min} phút" if elapsed_min > 0 else "vài giây"
                
                dialog = xbmcgui.Dialog()
                options = [
                    "[Khuyên dùng] Hủy phát để tránh khóa tài khoản",
                    "Đăng xuất nơi khác (Reset phiên tải)",
                    "[Nguy hiểm] Bỏ qua cảnh báo & Vẫn phát"
                ]
                
                heading = "[COLOR red]Tài khoản Fshare đang bận ở nơi khác![/COLOR]"
                detail = f"Thiết bị: {last_device}\nVideo: {last_title}\nThời gian: {elapsed_str} trước.\n\nNếu xem cùng lúc, Fshare sẽ khóa tài khoản (lỗi 471)!"
                
                choice = dialog.select(f"{heading}\n{detail}", options)
                
                if choice == 0 or choice == -1:
                    return False
                elif choice == 1:
                    reset_code = ADDON.getSetting('reset_code')
                    if reset_code:
                        try:
                            from resources import resetfs
                            resetfs.resetdl(reset_code)
                            dialog.ok("Reset Phiên Tải", "Đã gửi yêu cầu reset phiên tải thành công. Vui lòng đợi 30 giây rồi thử phát lại.")
                        except Exception as e:
                            dialog.ok("Lỗi Reset", f"Lỗi khi reset phiên tải: {str(e)}")
                    else:
                        dialog.ok("Không Thể Reset", "Tài khoản của bạn chưa cấu hình VCODE.\nVui lòng đăng nhập fshare.vn vào phần Bảo mật để xóa phiên tải thủ công.")
                    return False
                elif choice == 2:
                    # Proceed but warn
                    notify("Đang phát đè phiên tải! Có nguy cơ bị khóa IP.")
            else:
                # Same IP, safe to play (NAT)
                pass
        elif status == "idle" or elapsed >= 10800:
            # Safe to play, but check cooldown if IP changed
            cooldown_min = int(ADDON.getSetting('anti_ip_lock_cooldown') or 2)
            cooldown_sec = cooldown_min * 60
            
            if last_ip and last_ip != current_ip and elapsed < cooldown_sec:
                wait_time = int(cooldown_sec - elapsed)
                pDialog = xbmcgui.DialogProgress()
                pDialog.create("Anti-IP Lock", "Đang chờ giải phóng phiên Fshare...")
                for i in range(wait_time):
                    if pDialog.iscanceled():
                        pDialog.close()
                        return False
                    percent = int((i / wait_time) * 100)
                    pDialog.update(percent, f"Đổi mạng IP mới! Chờ Fshare giải phóng phiên IP cũ...\nThời gian còn lại: {wait_time - i} giây")
                    time.sleep(1)
                pDialog.close()

    # Acquire lock
    state = {
        "device_name": device_name,
        "ip": current_ip,
        "timestamp": now,
        "status": "playing",
        "title": title
    }
    
    if publish_state(username, state):
        ADDON.setSetting('fshare_active_playing', 'true')
        ADDON.setSetting('fshare_playing_username', username)
        ADDON.setSetting('fshare_playing_ip', current_ip)
        ADDON.setSetting('fshare_playing_title', title)
        ADDON.setSetting('fshare_playing_start', str(now))
        return True
    else:
        # If pub/sub fails, we proceed anyway but show warning
        notify("Lỗi máy chủ chống khóa IP. Đang phát trực tiếp...")
        return True
