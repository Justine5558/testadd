import urllib.request
import urllib.error
import ssl

urls = [
    "https://rophim1.vip",
    "https://cineviet.live",
    "https://mamphim.site",
    "https://phim4k.xyz",
    "https://cobephim.com",
    "https://rphim.me",
    "https://realmodelist.com",
    "https://rophimz.us",
    "https://vuonphim.net",
    "https://ophim17.cc",
    "https://phim.nguonc.com"
]

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

for url in urls:
    print(f"\n--- Testing: {url} ---")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        response = urllib.request.urlopen(req, context=ctx, timeout=5)
        print(f"Status Code: {response.getcode()}")
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code}")
    except Exception as e:
        print(f"Error: {e}")
