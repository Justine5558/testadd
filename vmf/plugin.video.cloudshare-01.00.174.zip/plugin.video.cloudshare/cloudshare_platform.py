import xbmc
import sys
import os

def get_platform():
    ret = {
        "arch": "x64" if sys.maxsize > 2**32 else "x86",
        "os": "unknown"
    }
    try:
        if xbmc.getCondVisibility("system.platform.android"):
            ret["os"] = "android"
            try:
                if hasattr(os, 'uname') and len(os.uname()) > 4 and "arm" in os.uname()[4]:
                    ret["arch"] = "arm"
            except Exception:
                pass
        elif xbmc.getCondVisibility("system.platform.linux"):
            ret["os"] = "linux"
            try:
                if hasattr(os, 'uname') and len(os.uname()) > 4 and "arm" in os.uname()[4]:
                    ret["arch"] = "arm"
            except Exception:
                pass
        elif xbmc.getCondVisibility("system.platform.xbox"):
            ret["os"] = "xbox"
            ret["arch"] = ""
        elif xbmc.getCondVisibility("system.platform.windows"):
            ret["os"] = "windows"
        elif xbmc.getCondVisibility("system.platform.osx"):
            ret["os"] = "darwin"
        elif xbmc.getCondVisibility("system.platform.ios"):
            ret["os"] = "ios"
            ret["arch"] = "arm"
    except Exception as e:
        xbmc.log("Error in get_platform(): " + str(e), xbmc.LOGERROR)
    return ret

PLATFORM = get_platform()
