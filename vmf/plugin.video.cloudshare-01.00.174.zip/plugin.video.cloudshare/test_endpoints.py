import urllib.request
import urllib.error

urls = [
    "https://thuviencine.com/top/",
    "https://thuviencine.com/theloai/",
    "https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=0&headers=1",
    "https://docs.google.com/spreadsheets/d/1OQkv_XDA4xdI16pedQuWDuEfnHYKgJf_nsi92y3UWLs/gviz/tq?gid=1057024371&headers=1"
]

for url in urls:
    print(f"\nTesting URL: {url}")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        response = urllib.request.urlopen(req, timeout=10)
        print(f"Status Code: {response.getcode()}")
        body = response.read().decode('utf-8')
        print(f"Content Length: {len(body)}")
        print(f"Snippet: {body[:200].strip()}...")
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} - {e.reason}")
    except urllib.error.URLError as e:
        print(f"URL Error: {e.reason}")
    except Exception as e:
        print(f"Error: {e}")
