import re

from conf.common import CommonResolver


class Wolfstream(CommonResolver):

    def find_stream(self):
        stream = re.compile(r'file:\"([^\"]+)\"').findall(self.page_src)[0]
        return [stream]
    