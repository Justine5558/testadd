import re
from urllib.parse import quote
from conf.common import CommonResolver


class Amstaff(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)
        self.ck = ""

    def find_stream(self):
        r1 = self.resolver.cli.get_request(self.resolver.start_url, allow_redirects=False)
        _, u1, ck = re.compile(r"src=\".*?#((http.*?:.*?)\?.*?ck=(.*?))\"").findall(r1.text)[0]
        # print(u1)
        # print(ck)
        self.ck = ck
        return [u1]

    def set_referer(self, url):
        # ref = self.resolver.find_hostname(self.page_url)
        ua = 'Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) QtWebEngine/5.9.7 Chrome/56.0.2924.122 Safari/537.36 Sky_STB_ST412_2018/1.0.0 (Sky, EM150UK,)'
        return "!user-agent=" + ua + "&force_isa=1" + "&isa_b64ck=" + self.ck
