import base64
import re
import time

from conf.common import CommonResolver


class Dlhd(CommonResolver):

    def deHunter(self, encoded):
        _0xce1e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/"

        def duf(d, e, f):
            g = list(_0xce1e)
            h = g[0:e]
            i = g[0:f]
            d = list(d)[::-1]
            j = 0
            for c, b in enumerate(d):
                if b in h:
                    j = j + h.index(b) * e ** c

            k = ""
            while j > 0:
                k = i[j % f] + k
                j = (j - (j % f)) // f

            return int(k) or 0

        def hunter(h, u, n, t, e, r):
            r = ""
            i = 0
            while i < len(h):
                j = 0
                s = ""
                while h[i] is not n[e]:
                    s = ''.join([s, h[i]])
                    i = i + 1

                while j < len(n):
                    s = s.replace(n[j], str(j))
                    j = j + 1

                r = ''.join([r, ''.join(map(chr, [duf(s, e, 10) - t]))])
                i = i + 1

            return r

        code = re.compile(r'}\(("[^"]+.*?)\)').findall(encoded)[0]
        code_list = code.split(',')
        for idx, code in enumerate(code_list):
            if code.isdigit():
                code_list[idx] = int(code)
            else:
                code_list[idx] = code.replace('\"', '')

        result = hunter(*code_list)
        res = re.compile(r"'([^']+)'").findall(result)[0]
        decoded_source = base64.b64decode(res).decode()
        return decoded_source

    def find_page(self):
        return [r'<iframe src="(.*?)" width']

    # def find_stream(self):
    #     limit = 60
    #     while self.page_src == "" and limit > 0:
    #         self.page_src = self.resolver.cli.get_request(self.page_url).text
    #         time.sleep(5)
    #         limit -= 1
    #     matches = re.compile(r'iframe src="(.*?)" width', re.MULTILINE).findall(self.page_src)
    #     if matches:
    #         iframe = self.resolver.cli.get_request(matches[0])
    #         self.resolver.stack.append(iframe.url)
    #         try:
    #             # encoded = re.compile(r"<script>\s.*?(var _.*?)var source", re.MULTILINE | re.DOTALL).findall(
    #             #    iframe.text)
    #
    #             # return [self.deHunter(encoded=encoded[0])]
    #             # encoded = re.compile(r'"([^\"]+)";\s+var source', re.MULTILINE | re.DOTALL).findall(iframe.text)
    #             # return [base64.b64decode(encoded[0]).decode()]
    #             return re.compile(r"source:.*?'([^']+)',", re.MULTILINE | re.DOTALL).findall(iframe.text)
    #         except Exception as e:
    #             print(e)
    #             import traceback
    #             traceback.print_stack()
    #             return []

    def find_stream(self):
        matches = re.compile(r'iframe src="(.*?)" width', re.MULTILINE).findall(self.page_src)
        if matches:
            try:
                iframe = self.resolver.cli.get_request(matches[0])
                self.resolver.stack.append(iframe.url)
                base = self.resolver.find_hostname(iframe.url)
                channel_key = re.compile(r'var channelKey.*?=.*?"([^"]+)"', re.MULTILINE).findall(iframe.text)[0]
                fetch_url = '/server_lookup.php?channel_id=' + channel_key
                fetch = self.resolver.cli.get_request(base + fetch_url)
                server_key = fetch.json()["server_key"]

                auth = re.compile(r'var (.*?) = atob\("([^"]+)"\)', re.MULTILINE).findall(iframe.text)

                auth_dict = {}

                for key, value in auth:
                    decoded_value = base64.b64decode(value).decode('utf-8')
                    auth_dict[key] = decoded_value

                auth_url = auth_dict["__a"] + auth_dict["__b"] + "?channel_id=" + channel_key + "&ts=" + auth_dict["__c"] + "&rnd=" + auth_dict["__d"] + "&sig=" + auth_dict["__e"]

                self.resolver.cli.get_request(auth_url)

                url = "https://top1.newkso.ru/top1/cdn/" + channel_key + "/mono.m3u8" if server_key == "top1/cdn" else "https://" + server_key + "new.newkso.ru/" + server_key + "/" + channel_key + "/mono.m3u8"

                return [url]

            except Exception as e:
                print(e)
                import traceback
                traceback.print_stack()
                return []
        return []

    def set_referer(self, url):
        ref = self.resolver.find_hostname(self.resolver.stack[0])
        ua = self.resolver.cli.headers["user-agent"]
        return "!Referer=" + ref + "/" + "&Origin=" + ref + "&Keep-Alive=true" + "&" + "&User-Agent=" + ua + "&force_isaf=1"
