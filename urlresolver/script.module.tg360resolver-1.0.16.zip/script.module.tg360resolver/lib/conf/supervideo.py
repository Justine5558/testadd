import re

from conf.common import CommonResolver
from jsbeautifier.unpackers import packer


class Supervideo(CommonResolver):

    def find_stream(self):
        packed_src = re.compile(r'(eval\(function.*?)</script', re.MULTILINE | re.DOTALL).findall(self.page_src)[0]
        unpacked_src = packer.unpack(packed_src)
        stream = re.compile(r'file:"(.*?)"').findall(unpacked_src)[0]

        return [stream]
