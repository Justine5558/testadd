from conf.common import CommonResolver
import re


class Mediafire(CommonResolver):

    def find_stream(self):
        matches = re.compile(r'<a class=\"input.*?href=\"([^\"]+)\".*?id=\"downloadButton\"', re.DOTALL).findall(
            self.page_src)
        return matches
